--
-- PostgreSQL database dump
--

-- Dumped from database version 10.9 (Ubuntu 10.9-0ubuntu0.18.10.1)
-- Dumped by pg_dump version 12.2 (Ubuntu 12.2-4)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

--
-- Name: bad_amtrak; Type: TABLE; Schema: public; Owner: cleaning
--

CREATE TABLE public.bad_amtrak (
    "Code" text,
    "StationName" character(20),
    "City" text,
    "State" text,
    "Visitors" smallint
);


ALTER TABLE public.bad_amtrak OWNER TO cleaning;

--
-- Name: dask_sample; Type: TABLE; Schema: public; Owner: cleaning
--

CREATE TABLE public.dask_sample (
    index integer,
    "timestamp" timestamp without time zone,
    id smallint,
    name character(10),
    x numeric(6,3),
    y real
);


ALTER TABLE public.dask_sample OWNER TO cleaning;

--
-- Name: missing; Type: TABLE; Schema: public; Owner: cleaning
--

CREATE TABLE public.missing (
    a real,
    b character(10)
);


ALTER TABLE public.missing OWNER TO cleaning;

--
-- Name: test; Type: TABLE; Schema: public; Owner: cleaning
--

CREATE TABLE public.test (
    c1 smallint,
    c2 integer
);


ALTER TABLE public.test OWNER TO cleaning;

--
-- Data for Name: bad_amtrak; Type: TABLE DATA; Schema: public; Owner: cleaning
--

COPY public.bad_amtrak ("Code", "StationName", "City", "State", "Visitors") FROM stdin;
ABB	Abbotsford-Colby    	Colby	WI	18631
ABE	Aberdeen            	Aberdeen	MD	12286
ABN	Absecon             	Absecon	NJ	5031
ABQ	Albuquerque         	Albuquerque	NM	14285
ACA	Antioch-Pittsburg   	Antioch	CA	16282
ACY	Atlantic City       	Atlantic City	NJ	27825
ADA	ADA Seat Removal    	\N	\N	32767
ADM	Ardmore             	Ardmore	OK	4734
AGM	Augusta             	Augusta	ME	22312
AHL	Ashland             	Ashland	OR	19424
AKY	Ashland             	Ashland	KY	18512
ALB	Albany-Rensselaer   	Rensselaer	NY	32767
ALC	Alliance            	Alliance	OH	8701
ALD	Alderson            	Alderson	WV	32767
ALI	Albion              	Albion	MI	20682
ALM	Alpena              	Alpena	MI	32767
ALN	Alton               	Alton	IL	30164
ALP	Alpine              	Alpine	TX	31130
ALT	Altoona             	Altoona	PA	19415
ALX	Alexandria          	Alexandria	VA	9410
ALY	Albany              	Albany	OR	15371
AMM	Amherst             	Amherst	MA	29944
AMS	Amsterdam           	Amsterdam	NY	6122
ANA	Anaheim             	Anaheim	CA	14034
APP	Appleton            	Appleton	WI	23912
ARB	Ann Arbor           	Ann Arbor	MI	17465
ARC	Arcata              	Arcata	CA	22369
ARD	Ardmore             	Ardmore	PA	2785
ARI	Astoria (Shell Stati	Astoria	OR	27872
ARK	Arkadelphia         	Arkadelphia	AR	29529
ARN	Auburn              	Auburn	CA	15231
ART	Astoria (Transit Cen	Astoria	OR	22116
ASD	Ashland             	Ashland	VA	17922
AST	Aldershot           	Aldershot	ON	19843
ATA	Atascadero          	Atascadero	CA	9721
ATI	Athol               	Athol	ID	23019
ATL	Atlanta             	Atlanta	GA	31168
ATN	Anniston            	Anniston	AL	1976
ATO	Atco                	Atco	NJ	2083
AUS	Austin              	Austin	TX	24430
BAG	Baggage             	\N	\N	13178
BAK	Baker City          	Baker City	OR	13942
BAL	Baltimore (Penn Stat	Baltimore	MD	19953
BAM	Bangor              	Bangor	MI	1761
BAN	Bangor              	Bangor	ME	23578
BAR	Barstow (Amtrak)    	Barstow	CA	12868
BAT	Bath                	Bath	ME	26110
BAV	Barnesville         	Barnesville	MD	28038
BBS	Barstow (Bus)       	Barstow	CA	32478
BBY	Boston (Back Bay)   	Boston	MA	23346
BCA	Baltimore (Camden St	Baltimore	MD	32767
BCV	Burke Centre        	Burke	VA	32767
BCY	Bay City            	Bay City	MI	8922
BDR	Bend (Riverhouse)   	Bend	OR	32767
BDT	Bradenton           	Bradenton	FL	32767
BED	Bend (Bus Station)  	Bend	OR	2612
BEL	Bellingham          	Bellingham	WA	10150
BEN	Benson              	Benson	AZ	14836
BER	Berlin              	Kensington	CT	6564
BET	South Beloit        	South Beloit	IL	27309
BFD	Bakersfield         	Bakersfield	CA	7619
BFT	Belfast             	Belfast	ME	5599
BFX	Buffalo (Exchange St	Buffalo	NY	30657
BGP	Big Rapids          	Big Rapids	MI	21999
BHM	Birmingham          	Birmingham	AL	14263
BIN	Berlin              	Berlin	NH	9669
BKO	Brookings           	Brookings	OR	2659
BKY	Berkeley            	Berkeley	CA	21319
BLF	Bellows Falls       	Bellows Falls	VT	29763
BMM	Birmingham          	Birmingham	MI	5437
BMT	Beaumont            	Beaumont	TX	15468
BNC	Burlington          	Burlington	NC	32767
BND	Bend (Hawthorne Inte	Bend	OR	27923
BNF	Branford            	Branford	CT	9340
BNG	Bingen-White Salmon 	Bingen	WA	31455
BNL	Bloomington-Normal  	Normal	IL	8714
BNS	Burns               	Burns	OR	24949
BOI	Boise               	Boise	ID	7591
BON	Boston (North Statio	Boston	MA	32767
BOS	Boston (South Statio	Boston	MA	2631
BRA	Brattleboro         	Brattleboro	VT	966
BRH	Brookhaven          	Brookhaven	MS	30985
BRK	Brunswick           	Brunswick	ME	27182
BRL	Burlington          	Burlington	IA	10432
BRO	Browning            	Browning	MT	4325
BRP	Bridgeport          	Bridgeport	CT	16715
BTL	Battle Creek        	Battle Creek	MI	25135
BTR	Baton Rouge         	Baton Rouge	LA	10022
BUF	Buffalo-Depew       	Depew	NY	20188
BUL	Buellton            	Buellton	CA	5389
BUR	Burbank (Airport)   	Burbank	CA	19789
BVD	Beaver Dam          	Beaver Dam	WI	1194
BWC	Brunswick (Bowdoin C	Brunswick	ME	10063
BWE	Bowie State         	Bowie	MD	12946
BWI	BWI Thurgood Marshal	BWI Airport	MD	25822
BWK	Brunswick           	Brunswick	MD	5538
BWW	Brewster            	Brewster	WA	13570
BYD	Boyds               	Boyds	MD	15159
BYF	Boyne Falls         	Boyne Falls	MI	11133
BYN	Bryan               	Bryan	OH	18249
CAL	California Rail Pass	\N	\N	29539
CAM	Camden              	Camden	SC	25206
CAY	Conway              	Conway	NH	25779
CBN	Canadian Border New 	\N	\N	26358
CBO	Cannon Beach        	Cannon Beach	OR	10286
CBR	Cleburne            	Cleburne	TX	23448
CBS	Columbus            	Columbus	WI	20987
CBY	Coos Bay            	Coos Bay	OR	17409
CBZ	Cabazon             	Cabazon	CA	22600
CDE	Cambridge           	Cambridge	MD	21648
CDL	Carbondale          	Carbondale	IL	28595
CDN	Camden/Rockport     	Rockport	ME	23897
CEN	Centralia           	Centralia	IL	26983
CER	Coeur d'Alene       	Coeur d'Alene	ID	31099
CFX	Colfax              	Colfax	WA	27696
CHG	Charge              	\N	\N	17121
CHI	Chicago (Union Stati	Chicago	IL	15783
CHM	Champaign-Urbana    	Champaign	IL	28944
CHP	Chippewa Falls      	Chippewa Falls	WI	12284
CHS	Charleston          	North Charleston	SC	26029
CHW	Charleston          	Charleston	WV	30047
CIC	Chico               	Chico	CA	2228
CIN	Cincinnati          	Cincinnati	OH	7926
CLA	Claremont           	Claremont	NH	16893
CLB	Columbia            	Columbia	SC	32767
CLC	Cadillac            	Cadillac	MI	20747
CLE	Cleveland           	Cleveland	OH	22858
CLF	Clifton Forge       	Clifton Forge	VA	20894
CLK	Crater Lake         	Crater Lake	OR	19690
CLM	Claremont           	Claremont	CA	9474
CLN	Clinton             	Clinton	CT	28700
CLP	Culpeper            	Culpeper	VA	8674
CLT	Charlotte           	Charlotte	NC	13557
CLV	Cloverdale          	Cloverdale	CA	32523
CML	Camarillo           	Camarillo	CA	31980
CMO	Chemult             	Chemult	OR	32767
CNH	Concord             	Concord	NH	24513
CNL	Colonel Allensworth 	Earlimart	CA	17879
CNV	Castleton           	Castleton	VT	1054
COC	Corcoran            	Corcoran	CA	4684
COI	Connersville        	Connersville	IN	7701
COS	Colorado Springs    	Colorado Springs	CO	11449
COT	Coatesville         	Coatesville	PA	24523
COV	Connellsville       	Connellsville	PA	3856
COX	Colfax              	Colfax	CA	32767
CPK	College Park        	College Park	MD	4699
CPN	Carpinteria         	Carpinteria	CA	6031
CRC	Crescent City       	Crescent City	CA	9294
CRF	Crawfordsville      	Crawfordsville	IN	22024
CRH	Cherry Hill         	Cherry Hill	NJ	20382
CRM	Carmel              	Carmel	CA	29064
CRN	Creston             	Creston	IA	31542
CRT	Croton Harmon       	Croton-on-Hudson	NY	15463
CRV	Carlinville         	Carlinville	IL	2277
CRY	Carry-on Charge     	\N	\N	7279
CSN	Clemson             	Clemson	SC	18420
CTL	Centralia           	Centralia	WA	30129
CUA	Cumberland (Allegany	Cumberland	MD	23388
CUM	Cumberland (Amtrak S	Cumberland	MD	3906
CUT	Cut Bank            	Cut Bank	MT	11876
CVD	Camp Verde          	Camp Verde	AZ	2851
CVI	Corvallis           	Corvallis	OR	15066
CVJ	Cave Junction       	Cave Junction	OR	19727
CVL	Colville            	Colville	WA	10253
CVS	Charlottesville     	Charlottesville	VA	20787
CWH	Cornwells Heights   	Cornwells Heights	PA	12116
CWL	Chewelah            	Chewelah	WA	32767
CWT	Chatsworth          	Chatsworth	CA	1359
CYN	Cary                	Cary	NC	20333
DAL	Dallas              	Dallas	TX	26170
DAM	Damariscotta        	Damariscotta	ME	22703
DAN	Danville            	Danville	VA	13716
DAV	Davis               	Davis	CA	25631
DBP	Dublin-Pleasanton   	Pleasanton	CA	23323
DDE	Dade City           	Dade City	FL	32767
DDG	Dodge City          	Dodge City	KS	12315
DEB	Denver (Bus Station)	Denver	CO	5844
DEM	Deming              	Deming	NM	23150
DEN	Denver              	Denver	CO	19599
DER	Dearborn            	Dearborn	MI	29608
DET	Detroit             	Detroit	MI	31991
DFB	Deerfield Beach     	Deerfield Beach	FL	20965
DHM	Durham              	Durham	NH	856
DIL	Dillon              	Dillon	SC	26292
DKS	Dickerson           	Dickerson	MD	2949
DLB	Delray Beach        	Delray Beach	FL	23409
DLD	Deland              	Deland	FL	20816
DLK	Detroit Lakes       	Detroit Lakes	MN	25971
DNC	Durham              	Durham	NC	17091
DNK	Denmark             	Denmark	SC	5028
DOA	Dowagiac            	Dowagiac	MI	24503
DOV	Dover               	Dover	NH	6622
DOW	Downingtown         	Downingtown	PA	32067
DPK	Deer Park           	Deer Park	WA	21932
DQN	Du Quoin            	Du Quoin	IL	12179
DRD	Durand              	Durand	MI	26131
DRS	Dorsey              	Elkridge	MD	12088
DRT	Del Rio             	Del Rio	TX	29991
DUF	Duffields           	Duffields	WV	19647
DUK	Dunkirk             	Dunkirk	NY	2302
DUL	Duluth (Greyhound St	Duluth	MN	16982
DUN	Dunsmuir            	Dunsmuir	CA	6810
DUU	Duluth (University o	Duluth	MN	29249
DVI	Danville            	Danville	IL	30565
DVL	Devils Lake         	Devils Lake	ND	15516
DVP	Davenport           	Davenport	IA	5618
DVR	Dover               	Dover	DE	4491
DWT	Dwight              	Dwight	IL	9122
DYA	Daytona Beach       	Daytona Beach	FL	25583
DYE	Dyer                	Dyer	IN	12775
EDG	Edgewood            	Edgewood	MD	20935
EDM	Edmonds             	Edmonds	WA	28963
EFG	Effingham           	Effingham	IL	12763
EGH	Egg Harbor City     	Egg Harbor City	NJ	20423
EKA	Eureka              	Eureka	CA	10271
EKG	Elk Grove           	Elk Grove	CA	19147
EKH	Elkhart             	Elkhart	IN	29791
ELK	Elko                	Elko	NV	24061
ELP	El Paso             	El Paso	TX	455
ELS	Elsie               	Elsie	OR	16527
ELT	Elizabethtown       	Elizabethtown	PA	8562
ELY	Elyria              	Elyria	OH	24830
EMI	Escanaba            	Escanaba	MI	28927
EMY	Emeryville          	Emeryville	CA	5487
EPH	Ephrata (Train)     	Ephrata	WA	20153
EPL	El Portal           	El Portal	CA	21425
EPR	Ephrata (Bus)       	Ephrata	WA	32767
ERI	Erie                	Erie	PA	26164
ESG	El Segundo          	El Segundo	CA	94
ESM	Essex               	Essex	MT	23371
ESN	Easton              	Easton	MD	29847
ESX	Essex Junction      	Essex Junction	VT	215
EUC	Eau Claire          	Eau Claire	WI	32767
EUG	Eugene              	Eugene	OR	17040
EUO	Eugene (University o	Eugene	OR	14199
EVR	Everett             	Everett	WA	20519
EWR	Newark Liberty Inter	Newark	NJ	24953
EXC	Exchange            	\N	\N	8318
EXP	Express             	\N	\N	10810
EXR	Exeter              	Exeter	NH	7285
EXT	Exton               	Exton	PA	16876
FAR	Fargo               	Fargo	ND	6188
FAY	Fayetteville        	Fayetteville	NC	19035
FBG	Fredericksburg      	Fredericksburg	VA	29611
FDL	Fond du Lac         	Fond du Lac	WI	14816
FDN	Fredonia            	Fredonia	NY	13611
FED	Fort Edward-Glens Fa	Fort Edward	NY	3029
FGG	Flagstaff (Greyhound	Flagstaff	AZ	29397
FHD	Fort Hood           	Fort Hood	TX	1842
FIL	Fillmore            	Fillmore	CA	14113
FIN	Group Final         	\N	\N	32767
FLG	Flagstaff           	Flagstaff	AZ	19238
FLN	Flint               	Flint	MI	3523
FLO	Florence            	Florence	SC	23144
FMD	Fort Madison        	Fort Madison	IA	17374
FMG	Fort Morgan         	Fort Morgan	CO	13755
FMT	Fremont (Capitol Tra	Fremont	CA	3922
FNO	Fresno              	Fresno	CA	25761
FOX	Foxwoods Casino     	Ledyard	CT	7809
FRA	Framingham          	Framingham	MA	5802
FRC	Frederick (Transit C	Frederick	MD	2719
FRO	Florence            	Florence	OR	15973
FRR	Frederick (Airport) 	Frederick	MD	12438
FRT	Fremont (San Joaquin	Fremont	CA	4158
FSB	Frostburg           	Frostburg	MD	26417
FSC	Frisco              	Frisco	CO	27611
FTA	Fortuna             	Fortuna	CA	1301
FTC	Ticonderoga         	Ticonderoga	NY	10958
FTL	Fort Lauderdale     	Fort Lauderdale	FL	19168
FTM	Fort Myers          	Fort Myers	FL	16733
FTN	Fulton              	Fulton	KY	25348
FTW	Fort Worth          	Fort Worth	TX	32160
FUL	Fullerton           	Fullerton	CA	32767
GAC	Santa Clara (Great A	Santa Clara	CA	32767
GAI	Gaithersburg        	Gaithersburg	MD	18586
GAS	Gastonia            	Gastonia	NC	29607
GBB	Galesburg           	Galesburg	IL	2178
GBC	Garibaldi Highlands 	Garibaldi Highlands	BC	8362
GBT	Greenbelt           	Greenbelt	MD	12164
GBV	Garberville         	Garberville	CA	8905
GBY	Green Bay           	Green Bay	WI	1798
GCA	Group Car Attendant 	\N	\N	23274
GCB	Grand Canyon Nationa	Grand Canyon National Park	AZ	9150
GCK	Garden City         	Garden City	KS	18155
GCN	Grand Canyon Nationa	Grand Canyon National Park	AZ	10849
GDL	Glendale            	Glendale	CA	14053
GEM	Germantown          	Germantown	MD	16956
GFK	Grand Forks         	Grand Forks	ND	32495
GFV	Greenfield Village  	Dearborn	MI	32
GGW	Glasgow             	Glasgow	MT	26219
GHL	Gold Hill           	Gold Hill	OR	6745
GHT	Gearhart            	Gearhart	OR	21889
GIF	Gift Certificate    	\N	\N	24873
GJT	Grand Junction      	Grand Junction	CO	32523
GLE	Gainesville         	Gainesville	TX	20861
GLF	Golf Bag            	\N	\N	10337
GLM	Gilman              	Gilman	IL	32767
GLN	Glenview            	Glenview	IL	10085
GLP	Gallup              	Gallup	NM	21606
GLS	Galveston (Texas Eag	Galveston	TX	28604
GLV	Galveston (Sunset Li	Galveston	TX	19284
GLY	Gilroy              	Gilroy	CA	7824
GMS	Grimsby             	Grimsby	ON	19289
GNB	Greensburg          	Greensburg	PA	24531
GNF	Gainesville         	Gainesville	FL	30045
GNS	Gainesville         	Gainesville	GA	29532
GPB	Group Breakfast     	\N	\N	32767
GPD	Group Dinner        	\N	\N	32591
GPF	Group FedEx TBM     	\N	\N	25090
GPI	Kids Trains and Meal	\N	\N	32050
GPK	East Glacier Park   	East Glacier Park	MT	5582
GPL	Group Lunch         	\N	\N	22792
GPM	Garrett Park        	Garrett Park	MD	31801
GPS	Group Special Meal  	\N	\N	14776
GRA	Granby              	Granby	CO	29479
GRI	Green River         	Green River	UT	15798
GRO	Greensboro          	Greensboro	NC	20206
GRR	Grand Rapids        	Grand Rapids	MI	7211
GRU	Group               	\N	\N	3113
GRV	Greenville          	Greenville	SC	20386
GSC	Glenwood Springs    	Glenwood Springs	CO	8664
GSN	Goshen Junction     	Goshen	CA	1036
GTA	Goleta              	Goleta	CA	20850
GTP	Grants Pass         	Grants Pass	OR	31223
GTV	Grantsville         	Grantsville	MD	25977
GUA	Guadalupe-Santa Mari	Guadalupe	CA	30358
GUI	Guilford            	Guilford	CT	28604
GUT	Guthrie             	Guthrie	OK	23485
GVB	Grover Beach        	Grover Beach	CA	18653
GVI	Grangeville         	Grangeville	ID	614
GWD	Greenwood           	Greenwood	MS	5118
HAE	Halethorpe          	Baltimore	MD	9907
HAG	Hagerstown          	Hagerstown	MD	32767
HAM	Hamlet              	Hamlet	NC	28553
HAR	Harrisburg          	Harrisburg	PA	298
HAS	Hastings            	Hastings	NE	27911
HAV	Havre               	Havre	MT	12744
HAY	Hayward             	Hayward	CA	10443
HAZ	Hazlehurst          	Hazlehurst	MS	4250
HBG	Hattiesburg         	Hattiesburg	MS	26657
HDS	Hudson              	Hudson	WI	9608
HEA	Healdsburg          	Healdsburg	CA	32767
HEM	Hermann             	Hermann	MO	2827
HER	Helper              	Helper	UT	22182
HET	Hemet (West Florida 	Hemet	CA	741
HFD	Hartford            	Hartford	CT	25731
HFY	Harpers Ferry       	Harpers Ferry	WV	8174
HGD	Huntingdon          	Huntingdon	PA	9341
HGH	Houghton            	Houghton	MI	10887
HHL	Haverhill           	Haverhill	MA	16550
HIN	Hinton              	Hinton	WV	20598
HKL	Hinckley            	Hinckley	MN	20891
HKM	Hancock             	Hancock	MI	4346
HLD	Holdrege            	Holdrege	NE	24147
HMD	Hammond             	Hammond	LA	30502
HMI	Hammond-Whiting     	Hammond	IN	10355
HMT	Hemet (Devonshire Av	Hemet	CA	23726
HMW	Homewood            	Homewood	IL	1006
HNF	Hanford             	Hanford	CA	23048
HNK	Hancock             	Hancock	MD	32767
HOL	Hollywood           	Hollywood	FL	32767
HOM	Holland             	Holland	MI	32756
HOO	Hood River          	Hood River	OR	5933
HOS	Houston             	Houston	TX	1885
HPT	High Point          	High Point	NC	30955
HTN	Hammonton           	Hammonton	NJ	32767
HUD	Hudson              	Hudson	NY	13387
HUN	Huntington          	Huntington	WV	9754
HUT	Hutchinson          	Hutchinson	KS	23378
HWC	Howard City         	Howard City	MI	17725
IDO	Indio               	Indio	CA	31995
IDP	Independence        	Independence	MO	15336
IND	Indianapolis        	Indianapolis	IN	21519
IRV	Irvine              	Irvine	CA	31981
ISE	Isleton             	Isleton	CA	8361
JAN	Jackson             	Jackson	MS	8867
JAX	Jacksonville        	Jacksonville	FL	16378
JEF	Jefferson City      	Jefferson City	MO	20829
JES	Jessup              	Jessup	MD	10441
JMN	Jamestown           	Jamestown	NY	2833
JNL	June Lake           	June Lake	CA	4173
JOL	Joliet              	Joliet	IL	23168
JSP	Jesup               	Jesup	GA	21778
JST	Johnstown           	Johnstown	PA	27093
JVL	Janesville          	Janesville	WI	3519
JXN	Jackson             	Jackson	MI	4570
KAL	Kalamazoo           	Kalamazoo	MI	18817
KAN	Kannapolis          	Kannapolis	NC	30345
KCY	Kansas City         	Kansas City	MO	3036
KEE	Kewanee             	Kewanee	IL	606
KEL	Kelso-Longview      	Kelso	WA	31832
KFS	Klamath Falls       	Klamath Falls	OR	6560
KGC	King City           	King City	CA	18264
KGS	Kingsley            	Kingsley	MI	3733
KIL	Killeen             	Killeen	TX	26466
KIN	Kingston            	West Kingston	RI	30607
KIS	Kissimmee           	Kissimmee	FL	10247
KKI	Kankakee            	Kankakee	IL	17278
KLK	Kalkaska            	Kalkaska	MI	17799
KNG	Kingman             	Kingman	AZ	3142
KNT	Kent Island         	Grasonville	MD	20271
KSM	Kensington          	Kensington	MD	26511
KTC	Kettleman City      	Kettleman City	CA	3522
KTF	Kettle Falls        	Kettle Falls	WA	17105
KTR	Kingstree           	Kingstree	SC	17643
KWD	Kirkwood            	Kirkwood	MO	29294
LAB	Latrobe             	Latrobe	PA	3177
LAE	La Grande           	La Grande	OR	26457
LAF	Lafayette           	Lafayette	IN	8504
LAG	La Grange Road      	La Grange	IL	7345
LAJ	La Junta            	La Junta	CO	32767
LAK	Lakeland            	Lakeland	FL	17050
LAN	L'Anse              	L'Anse	MI	22764
LAP	La Plata            	La Plata	MO	21515
LAS	Las Vegas Internatio	Las Vegas	NV	28556
LAU	Laurel              	Laurel	MS	30517
LAX	Los Angeles         	Los Angeles	CA	30508
LBC	Long Beach          	Long Beach	CA	2978
LBQ	Long Beach (Queen Ma	Long Beach	CA	288
LCA	La Crescenta        	La Crescenta	CA	32767
LCH	Lake Charles        	Lake Charles	LA	31283
LCN	Lincoln             	Lincoln	IL	31232
LCS	Lancaster           	Lancaster	CA	13319
LCV	Lincolnville        	Lincolnville	ME	508
LDB	Lordsburg           	Lordsburg	NM	29988
LDW	Lindenwold          	Somerdale	NJ	10025
LEE	Lee's Summit        	Lee's Summit	MO	19967
LEG	Leggett             	Leggett	CA	3990
LEV	Leavenworth (Buses) 	Leavenworth	WA	13450
LEW	Lewistown           	Lewistown	PA	4812
LEX	Lexington           	Lexington	NC	28365
LFT	Lafayette           	Lafayette	LA	8957
LGO	Lego Land           	Carlsbad	CA	27921
LGX	Legoland Admission T	Carlsbad	CA	9447
LIB	Libby               	Libby	MT	32767
LIV	Livermore (Transit C	Livermore	CA	11408
LKL	Lakeland            	Lakeland	FL	12953
LLK	Loon Lake           	Loon Lake	WA	18106
LMC	Lemoore             	Lemoore	CA	27915
LMN	Lemoore (Naval Air S	Lemoore	CA	5800
LMQ	La Marque           	La Marque	TX	32036
LMR	Lamar               	Lamar	CO	18263
LMY	Lamy                	Lamy	NM	5348
LNC	Lancaster           	Lancaster	PA	31376
LNK	Lincoln             	Lincoln	NE	3740
LNL	Laguna Niguel/Missio	Laguna Niguel	CA	29360
LNN	Lincoln             	Lincoln	NH	24700
LNS	East Lansing        	East Lansing	MI	31457
LNV	Laughlin            	Laughlin	NV	3349
LOD	Lodi                	Lodi	CA	25784
LOM	Lompoc              	Lompoc	CA	144
LOR	Lorton (Auto Train) 	Lorton	VA	27043
LPD	Lake Placid         	Lake Placid	NY	28483
LPE	Lapeer              	Lapeer	MI	14357
LPN	La Pine             	La Pine	OR	7783
LPS	Lompoc-Surf         	Surf	CA	22896
LQT	La Quinta           	La Quinta	CA	16688
LRC	Lawrence            	Lawrence	KS	9069
LRK	Little Rock         	Little Rock	AR	30090
LRM	Laurel              	Laurel	MD	28655
LRT	Laurel Racetrack    	Laurel	MD	26776
LSE	La Crosse           	La Crosse	WI	5548
LSV	Las Vegas           	Las Vegas	NM	31865
LTL	Littleton           	Littleton	NH	1286
LTM	Lathrop/Manteca     	Manteca	CA	8640
LTR	Littlerock          	Littlerock	CA	14458
LTV	Laytonville         	Laytonville	CA	11168
LVL	Louisville          	Louisville	KY	10379
LVN	Lee Vining          	Lee Vining	CA	4749
LVS	Las Vegas (Downtown)	Las Vegas	NV	22122
LVW	Longview            	Longview	TX	2257
LWA	Leavenworth (Trains)	Leavenworth	WA	23624
LWN	Lewiston            	Lewiston	ID	9707
LYH	Lynchburg           	Lynchburg	VA	7755
MAC	Macomb              	Macomb	IL	14775
MAK	Mackinaw City       	Mackinaw City	MI	206
MAL	Malta               	Malta	MT	1377
MAR	Marceline           	Marceline	MO	14983
MAT	Mattoon             	Mattoon	IL	31997
MAY	Maysville           	Maysville	KY	10996
MCA	McCall              	McCall	ID	18787
MCB	McComb              	McComb	MS	21762
MCD	Merced              	Merced	CA	10750
MCG	McGregor            	McGregor	TX	32481
MCI	Michigan City       	Michigan City	IN	13481
MCK	McCook              	McCook	NE	29984
MCY	Monocacy (Frederick)	Frederick	MD	18906
MDN	Meriden             	Meriden	CT	7879
MDP	Midpines            	Midpines	CA	4050
MDR	Madera              	Madera	CA	1779
MDS	Madison             	Madison	CT	9944
MDT	Mendota             	Mendota	IL	21609
MEE	Monroe (Eastbound)  	Monroe	WA	27201
MEI	Meridian            	Meridian	MS	3945
MEM	Memphis             	Memphis	TN	23690
MET	Metropark (Iselin)  	Iselin	NJ	2197
MEW	Monroe (Westbound)  	Monroe	WA	1988
MFR	Medford             	Medford	OR	17126
MGP	Mangonia Park       	West Palm Beach	FL	9429
MHC	Morgan Hill         	Morgan Hill	CA	28821
MHL	Marshall            	Marshall	TX	5916
MHT	Manchester          	Manchester	NH	13833
MIA	Miami               	Miami	FL	29639
MID	Middletown          	Middletown	PA	5282
MIN	Mineola             	Mineola	TX	4152
MJY	Mount Joy           	Mount Joy	PA	28006
MKA	Milwaukee (General M	Milwaukee	WI	19765
MKE	Milwaukee (Intermoda	Milwaukee	WI	13770
MKV	McKinleyville       	McKinleyville	CA	2038
MLI	Moline              	Moline	IL	21659
MLK	Moses Lake          	Moses Lake	WA	336
MLN	Mancelona           	Mancelona	MI	25000
MMK	Mammoth Lakes       	Mammoth Lakes	CA	8811
MNG	Montgomery          	Montgomery	WV	16831
MNI	Manning             	Manning	OR	30504
MNM	Menomonie           	Menomonie	WI	32767
MOC	Moscow              	Moscow	ID	15628
MOD	Modesto             	Modesto	CA	31435
MOJ	Mojave              	Mojave	CA	8065
MOT	Minot               	Minot	ND	30064
MOV	Moreno Valley       	Riverside	CA	31524
MPK	Moorpark            	Moorpark	CA	15571
MPR	Montpelier          	Montpelier	VT	752
MQT	Marquette           	Marquette	MI	4595
MRB	Martinsburg         	Martinsburg	WV	32759
MRC	Maricopa            	Maricopa	AZ	29392
MRM	Mariposa (Midtown)  	Mariposa	CA	32568
MRP	Mariposa (Park and R	Mariposa	CA	21681
MRV	Marysville          	Marysville	CA	16449
MRY	Monterey (Transit Pl	Monterey	CA	12893
MSA	Martin State Airport	Middle River	MD	21069
MSC	Miscellaneous       	\N	\N	23238
MSD	Madison (Deforest)  	Deforest	WI	24307
MSI	Mosinee             	Mosinee	WI	17804
MSN	Madison (University 	Madison	WI	24798
MSP	St. Paul-Minneapolis	St. Paul	MN	30820
MSS	Manassas            	Manassas	VA	75
MTC	Manitowoc           	Manitowoc	WI	31616
MTG	Metropolitan Grove  	Gaithersburg	MD	558
MTO	Manton              	Manton	MI	24955
MTP	Mt. Pleasant        	Mt. Pleasant	IA	28566
MTR	Montreal (Gare Centr	Montreal	QC	20404
MTZ	Martinez            	Martinez	CA	15011
MUK	Muirkirk            	Beltsville	MD	7904
MVN	Malvern             	Malvern	AR	2163
MVW	Mount Vernon        	Mount Vernon	WA	15411
MWI	Marinette           	Marinette	WI	25177
MYA	Monterey (Aquarium) 	Monterey	CA	21541
MYH	Monterey (Hyatt Rege	Monterey	CA	3146
MYM	Monterey (Marriott) 	Monterey	CA	21086
MYS	Mystic              	Mystic	CT	11655
MYT	Monterey (Travelodge	Monterey	CA	21660
NAM	Nampa               	Nampa	ID	27243
NAP	Napa (VINE Transit C	Napa	CA	19927
NBK	New Brunswick       	New Brunswick	NJ	28101
NBN	Newbern-Dyersburg   	Newbern	TN	24623
NBT	Newburyport         	Newburyport	MA	14941
NBU	New Buffalo         	New Buffalo	MI	26962
NCG	Nacogdoches         	Nacogdoches	TX	23105
NCM	Necanicum Junction  	Necanicum Junction	OR	1923
NCR	New Carrollton      	New Carrollton	MD	25121
NDL	Needles             	Needles	CA	7698
NEW	Newton              	Newton	KS	24683
NFK	Norfolk             	Norfolk	VA	16357
NFL	Niagara Falls       	Niagara Falls	NY	22077
NFS	Niagara Falls       	Niagara Falls	ON	27630
NHL	Santa Clarita-Newhal	Santa Clarita	CA	18913
NHN	New Hampton         	New Hampton	NH	32767
NHV	New Haven           	New Haven	CT	15468
NIB	New Iberia          	New Iberia	LA	3086
NLC	New London          	New London	CT	20774
NLS	Niles               	Niles	MI	2719
NNI	Nanaimo             	Nanaimo	BC	297
NOL	New Orleans         	New Orleans	LA	14538
NOR	Norman              	Norman	OK	27592
NPN	Newport News        	Newport News	VA	2730
NPO	Newport             	Newport	OR	31969
NPV	Naperville          	Naperville	IL	19362
NPW	Napa (Wine Train Sta	Napa	CA	6878
NRK	Newark              	Newark	DE	11251
NRO	New Rochelle        	New Rochelle	NY	32767
NSF	North Carolina State	North Carolina State Fair	NC	32767
NSH	Nashua              	Nashua	NH	13867
NWK	Newark (Penn Station	Newark	NJ	20608
NYF	New York State Fair 	Syracuse	NY	5970
NYP	New York (Penn Stati	New York	NY	23518
OAC	Oakland (Coliseum/Ai	Oakland	CA	12083
OCA	Ocala               	Ocala	FL	31107
OCM	Ocean City          	Ocean City	MD	11378
OCO	Oconto              	Oconto	WI	23586
OCP	Ocean Pines         	Berlin	MD	1697
OGD	Ogden               	Ogden	UT	670
OGE	Orange              	Orange	CA	16661
OGW	Okanagan            	Okanogan	WA	17161
OKC	Oklahoma City       	Oklahoma City	OK	25384
OKE	Okeechobee          	Okeechobee	FL	9664
OKJ	Oakland (Jack London	Oakland	CA	32088
OKL	Oakville            	Oakville	ON	17149
OLT	San Diego (Old Town)	San Diego	CA	20519
OLW	Olympia-Lacey       	Lacey	WA	5913
OMA	Omaha               	Omaha	NE	13026
OMW	Omak                	Omak	WA	6179
ONA	Ontario             	Ontario	CA	32767
ONT	Ontario             	Ontario	OR	22196
ORB	Old Orchard Beach   	Old Orchard Beach	ME	20432
ORC	Oregon City         	Oregon City	OR	28351
ORL	Orlando             	Orlando	FL	18785
ORO	Orono-University of 	Orono	ME	9049
ORV	Oroville            	Oroville	CA	32528
OSB	Old Saybrook        	Old Saybrook	CT	30327
OSC	Osceola             	Osceola	IA	3637
OSD	Oceanside           	Oceanside	CA	8902
OSH	Oshkosh (Airport)   	Oshkosh	WI	21220
OSU	Oshkosh (University 	Oshkosh	WI	25315
OTM	Ottumwa             	Ottumwa	IA	4738
OTN	Odenton             	Odenton	MD	21910
OWO	Owosso              	Owosso	MI	2278
OXN	Oxnard              	Oxnard	CA	32767
PAK	Palatka             	Palatka	FL	18316
PAO	Paoli               	Paoli	PA	23219
PAR	Parkesburg          	Parkesburg	PA	17831
PAS	Pasadena            	Pasadena	CA	28769
PBF	Poplar Bluff        	Poplar Bluff	MO	32767
PBT	Pemberton           	Pemberton	BC	18673
PCH	Port Charlotte      	Port Charlotte	FL	29400
PCT	Princeton           	Princeton	IL	32767
PCV	Placerville         	Placerville	CA	7330
PDC	Palm Desert         	Palm Desert	CA	32767
PDG	Portland (Greyhound 	Portland	OR	3618
PDL	Prunedale           	Prunedale	CA	29873
PDX	Portland (Amtrak - U	Portland	OR	24489
PEN	Pendleton           	Pendleton	OR	25568
PFS	Post Falls          	Post Falls	ID	13112
PGH	Pittsburgh          	Pittsburgh	PA	19664
PHA	Phoenix (Airport)   	Phoenix	AZ	22297
PHG	Phoenix (Greyhound) 	Phoenix	AZ	2709
PHL	Philadelphia (30th S	Philadelphia	PA	14708
PHN	Philadelphia (North)	Philadelphia	PA	32767
PIA	Peoria              	Peoria	IL	12025
PIC	Picayune            	Picayune	MS	29847
PIT	Pittsfield          	Pittsfield	MA	10938
PJC	Princeton Junction  	Princeton Junction	NJ	17619
PLB	Plattsburgh         	Plattsburgh	NY	23896
PLO	Plano               	Plano	IL	28947
PLS	Pleasanton (ACE Stat	Pleasanton	CA	2731
PLU	Plummer             	Plummer	ID	1680
PMD	Palmdale            	Palmdale	CA	22010
PMM	Primm               	Primm	NV	13709
PMO	Plymouth            	Plymouth	NH	26261
PNT	Pontiac             	Pontiac	MI	29788
POG	Portage             	Portage	WI	12060
POH	Port Henry          	Port Henry	NY	28174
PON	Pontiac             	Pontiac	IL	32767
POR	Portland            	Portland	ME	9522
POS	Pomona (Sunset Ltd) 	Pomona	CA	414
POU	Poughkeepsie        	Poughkeepsie	NY	21329
PRB	Paso Robles         	Paso Robles	CA	18970
PRC	Prince              	Prince	WV	28507
PRI	Perris              	Perris	CA	28441
PRK	Port Kent           	Port Kent	NY	19409
PRM	Point of Rocks      	Point of Rocks	MD	13615
PRO	Provo               	Provo	UT	30060
PRV	Perryville          	Perryville	MD	16287
PSC	Pasco               	Pasco	WA	20988
PSK	Petoskey            	Petosky	MI	32767
PSN	Palm Springs (Train)	Palm Springs	CA	8298
PSP	Palm Springs (Buses-	Palm Springs	CA	27046
PSS	Palm Springs (Buses-	Palm Springs	CA	24884
PST	Pellston            	Pellston	MI	23379
PTB	Petersburg          	Petersburg	VA	32767
PTC	Petaluma            	Petaluma	CA	32767
PTE	Pateros             	Pateros	WA	19251
PTH	Port Huron          	Port Huron	MI	16327
PTL	Potlatch            	Potlatch	ID	26986
PTS	Portsmouth          	Portsmouth	NH	1776
PUB	Pueblo              	Pueblo	CO	12484
PUL	Pullman             	Pullman	WA	4280
PUR	Purcell             	Purcell	OK	23689
PVD	Providence          	Providence	RI	18260
PVL	Pauls Valley        	Pauls Valley	OK	31701
PXN	Phoenix (Metro Cente	Phoenix	AZ	26695
QAN	Quantico            	Quantico	VA	5037
QCY	Quincy              	Quincy	IL	4259
QUC	Quincy              	Quincy	WA	9064
RAT	Raton               	Raton	NM	11310
RBC	Richmond            	Richmond	BC	223
RBF	Red Bluff           	Red Bluff	CA	5830
RCK	Rockford            	Rockford	IL	32235
RDD	Redding (Amtrak Stat	Redding	CA	32412
RDM	Redmond Airport     	Redmond	OR	10473
RDR	Redding (RABA Transi	Redding	CA	11407
RDS	Rio Dell-Scotia     	Scotia	CA	29255
RDW	Red Wing            	Red Wing	MN	3877
REE	Reed City           	Reed City	MI	25555
REF	Refund              	\N	\N	17910
REN	Rensselaer          	Rensselaer	IN	13723
RGH	Raleigh             	Raleigh	NC	12462
RHI	Rhinecliff          	Rhinecliff	NY	14980
RIC	Richmond            	Richmond	CA	3875
RIV	Riverside           	Riverside	CA	27531
RKF	Rockford            	Rockford	MI	27574
RKI	Rock Island         	Rock Island	IL	26526
RKV	Rockville           	Rockville	MD	22192
RLN	Rocklin             	Rocklin	CA	1290
RLP	Destination code for	\N	\N	22665
RMT	Rocky Mount         	Rocky Mount	NC	27805
RNO	Reno                	Reno	NV	27828
RNY	Running Y Ranch     	Klamath Falls	OR	6440
ROC	Rochester           	Rochester	NY	17882
ROD	Rockland            	Rockland	ME	5676
ROM	Rome                	Rome	NY	17248
ROY	Royal Oak           	Royal Oak	MI	2032
RPA	Rail Pass           	\N	\N	14576
RPC	Rohnert Park        	Rohnert Park	CA	32767
RPH	Randolph            	Randolph	VT	25909
RPT	Reedsport           	Reedsport	OR	17211
RSP	Rouses Point        	Rouses Point	NY	3654
RSV	Roseville           	Roseville	CA	5443
RTE	Route 128           	Westwood	MA	11706
RTL	Rantoul             	Rantoul	IL	24383
RTZ	Ritzville           	Ritzville	WA	19313
RUD	Rutland             	Rutland	VT	16365
RUG	Rugby               	Rugby	ND	20769
RVD	Riverdale           	Riverdale	MD	30757
RVM	Richmond (Main St)  	Richmond	VA	14459
RVR	Richmond (Staples Mi	Richmond	VA	29145
RVT	Rio Vista           	Rio Vista	CA	21115
SAB	St. Albans          	St Albans	VT	6245
SAC	Sacramento          	Sacramento	CA	6661
SAF	Santa Fe (Lamy Shutt	Santa Fe	NM	1547
SAL	Salisbury           	Salisbury	NC	23447
SAN	San Diego (Downtown)	San Diego	CA	17709
SAO	Saco                	Saco	ME	17406
SAP	Santa Paula         	Santa Paula	CA	30348
SAR	Saratoga Springs    	Saratoga Springs	NY	32767
SAS	San Antonio         	San Antonio	TX	24494
SAT	Santa Maria         	Santa Maria	CA	28749
SAV	Savannah            	Savannah	GA	5084
SBA	Santa Barbara       	Santa Barbara	CA	24142
SBG	Sebring             	Sebring	FL	7876
SBY	Shelby              	Shelby	MT	27954
SCA	St. Catharines      	St. Catharines	ON	7679
SCC	Santa Clara (Univers	Santa Clara	CA	9989
SCD	St. Cloud           	St. Cloud	MN	29918
SCH	Schriever           	Schriever	LA	26040
SCS	Sacramento (State Ca	Sacramento	CA	15586
SCZ	Santa Cruz          	Santa Cruz	CA	6856
SDC	Sedona              	Sedona	AZ	5913
SDL	Slidell             	Slidell	LA	31132
SDY	Schenectady         	Schenectady	NY	17565
SEA	Seattle (Amtrak)    	Seattle	WA	1396
SEB	Seabrook            	Lanham	MD	23495
SED	Sedalia             	Sedalia	MO	4355
SES	Seaside             	Seaside	CA	337
SFA	Sanford (Auto Train)	Sanford	FL	11218
SFB	San Francisco Bay Cr	San Francisco	CA	22541
SFC	San Francisco (Ferry	San Francisco	CA	26351
SFF	San Francisco (Finan	San Francisco	CA	9121
SFG	San Francisco (Group	San Francisco	CA	23225
SFM	San Francisco (Conv 	San Francisco	CA	32767
SFP	San Francisco (Caltr	San Francisco	CA	17756
SFS	San Francisco (Shopp	San Francisco	CA	21581
SFV	San Francisco (Civic	San Francisco	CA	29511
SFW	San Francisco (Wharf	San Francisco	CA	23869
SGL	Sagle               	Sagle	ID	29224
SGW	Saginaw             	Saginaw	MI	12231
SHB	Sheboygan           	Sheboygan	WI	8796
SHR	Shreveport          	Shreveport	LA	24646
SHW	Shawano             	Shawano	WI	6494
SID	Sandpoint (Bus)     	Sandpoint	ID	1620
SIM	Simi Valley         	Simi Valley	CA	1235
SJC	San Jose            	San Jose	CA	23180
SJM	St. Joseph          	St. Joseph	MI	32767
SKE	Skykomish (Eastbound	Skykomish	WA	20513
SKN	Stockton (711-718)  	Stockton	CA	11420
SKT	Stockton (ACE       	Stockton	CA	32767
SKW	Skykomish (Westbound	Skykomish	WA	2765
SKY	Sandusky            	Sandusky	OH	22191
SLB	Salt Lake City (Buse	Salt Lake City	UT	28921
SLC	Salt Lake City (Amtr	Salt Lake City	UT	26911
SLG	Salem (Greyhound)   	Salem	OR	32516
SLH	Stateline Transit Ce	Stateline	CA	30090
SLM	Salem               	Salem	OR	8940
SLN	Stateline           	Stateline	NV	15200
SLO	San Luis Obispo     	San Luis Obispo	CA	28695
SLP	San Luis Obispo (Cal	San Luis Obispo	CA	11708
SLQ	St-Lambert          	St-Lambert	QC	5969
SLS	Salisbury (BayRunner	Salisbury	MD	32767
SLT	South Lake Tahoe    	South Lake Tahoe	CA	9772
SLV	Solvang             	Solvang	CA	14082
SLY	Salisbury (Greyhound	Salisbury	MD	635
SMC	San Marcos          	San Marcos	TX	5086
SMD	Madison (Dutch Mill)	Madison	WI	16946
SMI	Sault Sainte Marie  	Sault Sainte Marie	MI	15534
SMR	Smith River         	Smith River	CA	7976
SMT	Summit              	Summit	IL	11222
SNA	Santa Ana           	Santa Ana	CA	16002
SNB	San Bernardino (Amtr	San Bernardino	CA	25672
SNC	San Juan Capistrano 	San Juan Capistrano	CA	25400
SND	Sanderson           	Sanderson	TX	15230
SNP	San Clemente Pier   	San Clemente	CA	24853
SNS	Salinas             	Salinas	CA	29534
SNY	Stanley             	Stanley	WI	24873
SOB	South Bend          	South Bend	IN	6951
SOL	Solana Beach        	Solana Beach	CA	7370
SOP	Southern Pines      	Southern Pines	NC	2274
SPB	Spartanburg         	Spartanburg	SC	104
SPD	San Pedro (Catalina 	San Pedro	CA	21405
SPG	Springfield         	Springfield	MA	30146
SPI	Springfield         	Springfield	IL	7760
SPK	Spokane             	Spokane	WA	437
SPL	Staples             	Staples	MN	14933
SPM	South Shore-South Po	South Shore	KY	20573
SPO	San Pedro (Downtown)	San Pedro	CA	32738
SPT	Sandpoint (Amtrak)  	Sandpoint	ID	1067
SPX	Sparks              	Sparks	NV	7072
SQA	Squamish            	Squamish	BC	27050
SRA	Sarasota            	Sarasota	FL	13677
SRC	Santa Rosa          	Santa Rosa	CA	6832
SRK	Saratoga Race Course	Saratoga Springs	NY	26223
SRT	Searsport           	Searsport	ME	6229
SSD	Seaside             	Seaside	OR	18515
SSM	Selma               	Selma	NC	3230
SSP	Silver Spring       	Silver Spring	MD	15873
SSW	Stevens Pass        	Stevens Pass	WA	31634
STA	Staunton            	Staunton	VA	29732
STD	St. Denis           	Baltimore	MD	10373
STG	St. George          	St. George	UT	5384
STI	St. Ignace          	St. Ignace	MI	7762
STL	St. Louis           	St. Louis	MO	14586
STM	Stamford            	Stamford	CT	30452
STN	Stanley             	Stanley	ND	20959
STP	St Petersburg-Clearw	Clearwater	FL	18510
STS	New Haven (State Str	New Haven	CT	14457
STW	Stanwood            	Stanwood	WA	32328
SUI	Suisun-Fairfield    	Suisun City	CA	1622
SUN	Sunriver            	Sunriver	OR	32767
SUT	Sun City-Menifee    	Sun City-Menifee	CA	13662
SUY	Surrey              	South Surrey	BC	12323
SVF	Seattle (Ferry - Pie	Seattle	WA	1716
SVG	Savage              	Annapolis Junction	MD	19543
SVP	Stevens Point (200 D	Stevens Point	WI	13859
SVT	Sturtevant          	Sturtevant	WI	19019
SVU	Stevens Point (Unive	Stevens Point	WI	10776
SVY	Scotts Valley       	Scotts Valley	CA	27822
SYR	Syracuse            	Syracuse	NY	3352
TAC	Tacoma              	Tacoma	WA	21534
TAY	Taylor              	Taylor	TX	12302
TCA	Toccoa              	Toccoa	GA	3351
TCL	Tuscaloosa          	Tuscaloosa	AL	18553
TDO	Toledo              	Toledo	OR	32767
TEH	Tehachapi           	Tehachapi	CA	22884
TFI	Twin Falls          	Twin Falls	ID	16005
THD	The Dalles          	The Dalles	OR	6912
THN	Thurmond            	Thurmond	WV	1967
TLT	Tilton              	Tilton	NH	16383
TOA	Torrance            	Torrance	CA	31421
TOH	Tomah               	Tomah	WI	28635
TOL	Toledo              	Toledo	OH	25407
TOP	Topeka              	Topeka	KS	11229
TPA	Tampa               	Tampa	FL	28042
TPL	Temple              	Temple	TX	21956
TRA	Tracy (Bus)         	Tracy	CA	7152
TRC	Tracy (ACE Station) 	Tracy	CA	20762
TRE	Trenton             	Trenton	NJ	21532
TRI	Trinidad            	Trinidad	CO	22503
TRK	Turlock-Denair      	Denair	CA	3783
TRU	Truckee             	Truckee	CA	32767
TRV	Traverse City       	Traverse City	MI	32767
TSY	Tusayan             	Tusayan	AZ	18437
TUK	Tukwila             	Tukwila	WA	32357
TUS	Tucson              	Tucson	AZ	3040
TVF	The Villages        	The Villages	FL	24548
TWC	Tawas City          	Tawas City	MI	20095
TWO	Toronto             	Toronto	ON	2618
TXA	Texarkana           	Texarkana	AR	27198
TYR	Tyrone              	Tyrone	PA	25255
UCA	Utica               	Utica	NY	9019
UKH	Ukiah               	Ukiah	CA	25323
UOP	University of Pennsy	Philadelphia	PA	18170
USA	USA Rail Pass       	\N	\N	907
USF	USA Rail Pass Pseudo	\N	\N	30414
UWS	Winston-Salem State 	Winston-Salem	NC	22481
VAB	Virginia Beach      	Virginia Beach	VA	13647
VAC	Vancouver           	Vancouver	BC	30052
VAE	Vale                	Vale	OR	28319
VAI	Vail                	Vail	CO	32767
VAL	Vallejo             	Vallejo	CA	32767
VAN	Vancouver           	Vancouver	WA	4881
VAS	Livermore (Vasco Roa	Livermore	CA	4617
VBC	Victoria (Bus Statio	Victoria	BC	11637
VEC	Ventura             	Ventura	CA	22092
VIA	VIA Rail Canada     	\N	\N	31843
VIF	Victoria (Ferry)    	Victoria	BC	6561
VIS	Visalia             	Visalia	CA	30582
VMW	Six Flags Discovery 	Vallejo	CA	31518
VNC	Van Nuys            	Van Nuys	CA	4434
VRB	Victorville (Thruway	Victorville	CA	17325
VRV	Victorville (Southwe	Victorville	CA	12706
WAB	Waterbury           	Waterbury	VT	29345
WAC	Wasco               	Wasco	CA	3986
WAH	Washington          	Washington	MO	14009
WAR	Warrensburg         	Warrensburg	MO	28359
WAS	Washington          	Washington	DC	27845
WAU	Waupaca             	Waupaca	WI	6683
WBG	Williamsburg        	Williamsburg	VA	23232
WBL	West Baltimore      	Baltimore	MD	32264
WCH	Westchester         	Westchester	CA	7395
WCT	White City          	White City	OR	24479
WDB	Woodbridge          	Woodbridge	VA	11859
WDL	Wisconsin Dells     	Wisconsin Dells	WI	30488
WDO	Waldo               	Waldo	FL	9482
WDR	Waldoboro           	Waldoboro	ME	26701
WEM	Wells               	Wells	ME	28323
WEN	Wenatchee           	Wenatchee	WA	531
WES	Westwood-UCLA       	Los Angeles	CA	7420
WFD	Wallingford         	Wallingford	CT	24002
WFH	Whitefish           	Whitefish	MT	27098
WGL	West Glacier        	West Glacier	MT	11063
WGM	Washington Grove    	Gaithersburg	MD	15770
WHL	Whitehall           	Whitehall	NY	11952
WIH	Wishram             	Wishram	WA	10090
WIL	Wilmington          	Wilmington	DE	1881
WIN	Winona              	Winona	MN	32767
WIP	Winter Park/Fraser  	Fraser	CO	13177
WIT	Wittenberg          	Wittenberg	WI	20576
WLN	Wilson              	Wilson	NC	5377
WLO	Winslow             	Winslow	AZ	20082
WLY	Westerly            	Westerly	RI	32767
WMA	Williams            	Williams	AZ	9623
WMJ	Williams Junction   	Williams Junction	AZ	24644
WND	Windsor             	Windsor	CT	17105
WNK	Walloon Lake        	Walloon Lake	MI	3826
WNL	Windsor Locks       	Windsor Locks	CT	17482
WNM	Windsor             	Windsor	VT	449
WNN	Winnemucca          	Winnemucca	NV	4147
WNR	Walnut Ridge        	Walnut Ridge	AR	23227
WNS	Winston-Salem       	Winston-Salem	NC	12456
WNT	Warrenton           	Warrenton	OR	32767
WOB	Woburn              	Woburn	MA	16669
WOR	Worcester           	Worcester	MA	10434
WPB	West Palm Beach     	West Palm Beach	FL	31374
WPK	Winter Park         	Winter Park	FL	27201
WPN	Waupun              	Waupun	WI	756
WPT	Wolf Point          	Wolf Point	MT	19910
WRJ	White River Jct.    	White River Junction	VT	15321
WRM	Western Railway Muse	Rio Vista Junction	CA	23340
WSB	Westbrook           	Westbrook	CT	16595
WSF	Westfield           	Westfield	WI	32767
WSJ	Wausau (Transit Cent	Wausau	WI	17383
WSL	Whistler            	Whistler Village	BC	32767
WSP	Westport            	Westport	NY	996
WSS	White Sulphur Spring	White Sulphur Springs	WV	1614
WST	Wiscasset           	Wiscasset	ME	26186
WSU	Wausau-Rothschild (L	Rothschild	WI	22845
WTH	Winter Haven        	Winter Haven	FL	14339
WTI	Waterloo            	Waterloo	IN	24533
WTN	Williston           	Williston	ND	3040
WTS	Willits             	Willits	CA	18614
WWA	Walla Walla         	Walla Walla	WA	23741
WWD	Wildwood            	Wildwood	FL	22801
YAZ	Yazoo City          	Yazoo City	MS	15950
YEM	Yemassee            	Yemassee	SC	22563
YNY	Yonkers             	Yonkers	NY	25871
YOA	Yosemite - Ahwahnee 	Yosemite National Park	CA	3876
YOC	Yosemite - Curry Vil	Yosemite National Park	CA	28352
YOF	Yosemite - Crane Fla	Yosemite National Park	CA	32767
YOS	Yosemite - Lodge    	Yosemite National Park	CA	16373
YOT	Yosemite - Tuolumne 	Yosemite National Park	CA	28499
YOV	Yosemite - Visitor C	Yosemite National Park	CA	29119
YOW	Yosemite - White Wol	Yosemite National Park	CA	16718
YUM	Yuma                	Yuma	AZ	19739
ZMW	Six Flags Discovery 	Vallejo	CA	24161
\.


--
-- Data for Name: dask_sample; Type: TABLE DATA; Schema: public; Owner: cleaning
--

COPY public.dask_sample (index, "timestamp", id, name, x, y) FROM stdin;
3456	2000-01-02 00:57:36	941	Alice     	-0.612	-0.636484981
3457	2000-01-02 00:57:37	1004	Victor    	0.450	-0.687718153
3458	2000-01-02 00:57:38	980	Quinn     	0.552	0.454158217
3459	2000-01-02 00:57:39	1023	Oliver    	-0.797	-0.570034206
3460	2000-01-02 00:57:40	973	Hannah    	0.129	-0.0456986241
3461	2000-01-02 00:57:41	971	Tim       	0.351	-0.681465149
3462	2000-01-02 00:57:42	1000	Xavier    	0.018	0.0292143039
3463	2000-01-02 00:57:43	1026	Charlie   	-0.697	0.842686296
3464	2000-01-02 00:57:44	1080	Frank     	-0.373	-0.851097107
3465	2000-01-02 00:57:45	1016	Edith     	0.554	0.821616471
3466	2000-01-02 00:57:46	1005	Jerry     	0.638	-0.589487731
3467	2000-01-02 00:57:47	1033	Victor    	-0.564	0.102641009
3468	2000-01-02 00:57:48	1053	Ursula    	0.740	0.55422461
3469	2000-01-02 00:57:49	1007	George    	0.166	0.301263958
3470	2000-01-02 00:57:50	976	Ray       	0.498	0.249029368
3471	2000-01-02 00:57:51	991	Yvonne    	0.326	0.168195322
3472	2000-01-02 00:57:52	1009	Kevin     	-0.001	-0.237274125
3473	2000-01-02 00:57:53	1010	Oliver    	0.006	0.582372069
3474	2000-01-02 00:57:54	997	Tim       	-0.048	0.798149884
3475	2000-01-02 00:57:55	984	Sarah     	0.919	-0.157757491
3476	2000-01-02 00:57:56	1001	Quinn     	-0.412	0.225632936
3477	2000-01-02 00:57:57	989	Bob       	-0.668	0.895414352
3478	2000-01-02 00:57:58	994	Ingrid    	0.943	-0.546268702
3479	2000-01-02 00:57:59	1004	Wendy     	0.457	0.145161659
3480	2000-01-02 00:58:00	999	Norbert   	-0.071	-0.675264597
3481	2000-01-02 00:58:01	954	Ingrid    	0.289	-0.608402252
3482	2000-01-02 00:58:02	1044	Frank     	-0.244	0.895470798
3483	2000-01-02 00:58:03	953	Frank     	0.430	0.288207263
3484	2000-01-02 00:58:04	974	Hannah    	0.116	-0.991666257
3485	2000-01-02 00:58:05	1012	Jerry     	-0.202	-0.497354746
3486	2000-01-02 00:58:06	1044	Wendy     	0.808	-0.190062478
3487	2000-01-02 00:58:07	1023	Hannah    	-0.042	-0.315017372
3488	2000-01-02 00:58:08	998	Oliver    	0.877	-0.930935323
3489	2000-01-02 00:58:09	984	Hannah    	0.461	-0.273157567
3490	2000-01-02 00:58:10	1033	Hannah    	0.062	0.356785625
3491	2000-01-02 00:58:11	1078	Norbert   	-0.457	0.157089844
3492	2000-01-02 00:58:12	1006	Kevin     	-0.954	-0.243507504
3493	2000-01-02 00:58:13	1040	Wendy     	-0.602	0.795362175
3494	2000-01-02 00:58:14	1014	Hannah    	-0.910	-0.435607046
3495	2000-01-02 00:58:15	1007	George    	0.852	-0.542991877
3496	2000-01-02 00:58:16	967	Ingrid    	0.446	0.852449417
3497	2000-01-02 00:58:17	984	Norbert   	-0.590	0.214127332
3498	2000-01-02 00:58:18	971	Oliver    	-0.387	0.259471178
3499	2000-01-02 00:58:19	1007	Patricia  	-0.193	-0.436799049
3500	2000-01-02 00:58:20	986	Zelda     	-0.521	0.0100183571
3501	2000-01-02 00:58:21	1019	Ingrid    	-0.572	-0.576511204
3502	2000-01-02 00:58:22	980	Xavier    	-0.732	-0.979870677
3503	2000-01-02 00:58:23	986	Jerry     	-0.056	-0.665860355
3504	2000-01-02 00:58:24	1014	Laura     	-0.176	-0.538579702
3505	2000-01-02 00:58:25	961	Quinn     	0.727	0.687571883
3506	2000-01-02 00:58:26	959	Zelda     	0.666	0.809479415
3507	2000-01-02 00:58:27	1010	Kevin     	-0.339	0.542340636
3508	2000-01-02 00:58:28	1028	Sarah     	0.218	-0.349396288
3509	2000-01-02 00:58:29	1018	Hannah    	-0.523	-0.616102576
3510	2000-01-02 00:58:30	1032	Laura     	-0.561	0.210617602
3511	2000-01-02 00:58:31	983	Kevin     	-0.902	-0.136536852
3512	2000-01-02 00:58:32	1060	Quinn     	0.839	-0.52475512
3513	2000-01-02 00:58:33	1016	Charlie   	-0.779	0.671991885
3514	2000-01-02 00:58:34	987	Victor    	0.568	0.615733147
3515	2000-01-02 00:58:35	1042	Frank     	0.782	0.404567659
3516	2000-01-02 00:58:36	997	Bob       	-0.492	0.268412292
3517	2000-01-02 00:58:37	963	Ray       	-0.803	-0.657561004
3518	2000-01-02 00:58:38	981	Kevin     	0.759	-0.627723217
3519	2000-01-02 00:58:39	1007	Xavier    	0.856	0.820715129
3520	2000-01-02 00:58:40	1023	Wendy     	0.777	-0.878644943
3521	2000-01-02 00:58:41	986	Kevin     	-0.270	-0.938015819
3522	2000-01-02 00:58:42	984	Dan       	-0.539	0.40419212
3523	2000-01-02 00:58:43	1009	Norbert   	-0.990	0.0818159729
3524	2000-01-02 00:58:44	1015	Sarah     	-0.667	-0.541403055
3525	2000-01-02 00:58:45	1006	Wendy     	0.749	-0.655114949
3526	2000-01-02 00:58:46	1025	Michael   	0.610	0.917114973
3527	2000-01-02 00:58:47	1052	Jerry     	0.052	0.69904238
3528	2000-01-02 00:58:48	999	Ursula    	-0.127	-0.498841852
3529	2000-01-02 00:58:49	961	Ursula    	-0.078	-0.142900795
3530	2000-01-02 00:58:50	1010	Victor    	-0.845	0.927418053
3531	2000-01-02 00:58:51	986	Ingrid    	-0.139	0.389754444
3532	2000-01-02 00:58:52	1027	Zelda     	0.907	-0.749364853
3533	2000-01-02 00:58:53	937	Jerry     	0.159	0.113327317
3534	2000-01-02 00:58:54	973	Hannah    	0.118	0.617615819
3535	2000-01-02 00:58:55	957	Sarah     	-0.533	0.322197139
3536	2000-01-02 00:58:56	998	Ray       	-0.325	-0.124409415
3537	2000-01-02 00:58:57	1009	Edith     	-0.591	0.829950869
3538	2000-01-02 00:58:58	1004	Victor    	0.592	-0.83263582
3539	2000-01-02 00:58:59	946	Edith     	0.413	0.884620607
3540	2000-01-02 00:59:00	1006	Patricia  	0.812	-0.0725572333
3541	2000-01-02 00:59:01	998	Zelda     	-0.771	-0.0497263744
3542	2000-01-02 00:59:02	978	Tim       	0.030	0.456672102
3543	2000-01-02 00:59:03	931	Edith     	0.742	-0.430999398
3544	2000-01-02 00:59:04	1041	Edith     	-0.480	-0.566353738
3545	2000-01-02 00:59:05	1005	Jerry     	-0.061	-0.45011887
3546	2000-01-02 00:59:06	963	Sarah     	-0.128	-0.0532378331
3547	2000-01-02 00:59:07	1003	Xavier    	-0.973	-0.297623217
3548	2000-01-02 00:59:08	1028	Alice     	0.707	0.570453882
3549	2000-01-02 00:59:09	1025	Zelda     	-0.178	-0.598306417
3550	2000-01-02 00:59:10	1008	Jerry     	0.360	0.954050124
3551	2000-01-02 00:59:11	996	Laura     	-0.902	-0.935985863
3552	2000-01-02 00:59:12	986	Ursula    	0.499	-0.990881443
3553	2000-01-02 00:59:13	906	Yvonne    	-0.725	0.854121864
3554	2000-01-02 00:59:14	1004	Sarah     	0.548	0.5923118
3555	2000-01-02 00:59:15	997	Ray       	-0.617	0.148990795
3556	2000-01-02 00:59:16	1002	George    	-0.391	-0.795622945
3557	2000-01-02 00:59:17	1017	Jerry     	0.260	-0.183671623
3558	2000-01-02 00:59:18	946	Patricia  	0.097	-0.0323656686
3559	2000-01-02 00:59:19	972	Alice     	0.508	-0.886932254
3560	2000-01-02 00:59:20	992	Oliver    	-0.310	-0.510003209
3561	2000-01-02 00:59:21	942	Laura     	-0.279	0.0919258818
3562	2000-01-02 00:59:22	1030	Wendy     	-0.709	-0.477336675
3563	2000-01-02 00:59:23	1040	Dan       	-0.949	-0.07496842
3564	2000-01-02 00:59:24	981	Norbert   	-0.776	0.617775202
3565	2000-01-02 00:59:25	1056	Kevin     	0.243	0.594278395
3566	2000-01-02 00:59:26	969	Michael   	0.964	0.718727946
3567	2000-01-02 00:59:27	963	Frank     	-0.848	-0.276734114
3568	2000-01-02 00:59:28	958	Quinn     	0.739	0.26769805
3569	2000-01-02 00:59:29	988	Ray       	0.963	0.523281097
3570	2000-01-02 00:59:30	949	Kevin     	0.441	0.731499553
3571	2000-01-02 00:59:31	964	Kevin     	-1.000	0.607930839
3572	2000-01-02 00:59:32	992	Hannah    	-0.866	0.196132451
3573	2000-01-02 00:59:33	1053	Ingrid    	0.953	-0.91181308
3574	2000-01-02 00:59:34	1031	Victor    	-0.268	-0.300622225
3575	2000-01-02 00:59:35	1050	Dan       	-0.655	-0.847850502
3576	2000-01-02 00:59:36	1054	Wendy     	-0.742	0.167312205
3577	2000-01-02 00:59:37	1095	Norbert   	-0.898	0.849384427
3578	2000-01-02 00:59:38	979	Laura     	-0.946	0.277652085
3579	2000-01-02 00:59:39	1015	Sarah     	-0.502	0.345940739
3580	2000-01-02 00:59:40	1021	Edith     	0.167	-0.320261627
3581	2000-01-02 00:59:41	964	Zelda     	-0.645	-0.641386569
3582	2000-01-02 00:59:42	1008	Michael   	0.211	0.51576829
3583	2000-01-02 00:59:43	946	Charlie   	-0.095	-0.867511809
3584	2000-01-02 00:59:44	945	Hannah    	0.631	0.805858195
3585	2000-01-02 00:59:45	960	Dan       	0.678	-0.895962119
3586	2000-01-02 00:59:46	996	Victor    	0.714	-0.151461869
3587	2000-01-02 00:59:47	1005	Sarah     	-0.860	0.2575652
3588	2000-01-02 00:59:48	999	Ingrid    	0.416	0.0460866168
3589	2000-01-02 00:59:49	985	Michael   	-0.756	0.110412054
3590	2000-01-02 00:59:50	1037	Ray       	0.307	0.30914554
3591	2000-01-02 00:59:51	982	Frank     	-0.822	0.256471545
3592	2000-01-02 00:59:52	969	Yvonne    	-0.848	0.0724298432
3593	2000-01-02 00:59:53	1003	Zelda     	0.335	0.229652047
3594	2000-01-02 00:59:54	956	Ingrid    	-0.174	0.406883746
3595	2000-01-02 00:59:55	1035	Kevin     	0.745	0.644584477
3596	2000-01-02 00:59:56	988	Sarah     	-0.796	-0.240267232
3597	2000-01-02 00:59:57	1011	Jerry     	0.365	0.642772973
3598	2000-01-02 00:59:58	969	Alice     	0.619	-0.420204341
3599	2000-01-02 00:59:59	1047	Charlie   	-0.752	-0.954512656
3600	2000-01-02 01:00:00	962	Patricia  	0.465	0.0206219293
3601	2000-01-02 01:00:01	1018	Patricia  	0.037	-0.723044157
3602	2000-01-02 01:00:02	1027	Xavier    	-0.018	0.654127181
3603	2000-01-02 01:00:03	1016	Ray       	0.082	0.685403705
3604	2000-01-02 01:00:04	986	Michael   	-0.840	-0.400830567
3605	2000-01-02 01:00:05	979	Oliver    	-0.444	-0.423178673
3606	2000-01-02 01:00:06	1031	Oliver    	0.983	-0.491466403
3607	2000-01-02 01:00:07	1039	George    	0.484	0.30255419
3608	2000-01-02 01:00:08	1012	Sarah     	0.009	0.544659436
3609	2000-01-02 01:00:09	998	Ingrid    	0.233	-0.4146007
3610	2000-01-02 01:00:10	971	Ingrid    	-0.260	-0.535572529
3611	2000-01-02 01:00:11	989	Victor    	0.240	-0.814299881
3612	2000-01-02 01:00:12	995	Wendy     	-0.289	0.352803648
3613	2000-01-02 01:00:13	961	Wendy     	-0.829	0.19284986
3614	2000-01-02 01:00:14	954	Edith     	0.593	-0.402238041
3615	2000-01-02 01:00:15	984	Bob       	-0.784	-0.047373753
3616	2000-01-02 01:00:16	1001	Laura     	-0.291	-0.0419803113
3617	2000-01-02 01:00:17	1038	Edith     	-0.692	-0.640602171
3618	2000-01-02 01:00:18	1001	Tim       	0.621	0.0512649417
3619	2000-01-02 01:00:19	1013	Patricia  	-0.534	-0.938130975
3620	2000-01-02 01:00:20	1015	George    	-0.739	-0.390265137
3621	2000-01-02 01:00:21	979	Alice     	0.270	-0.766227722
3622	2000-01-02 01:00:22	1012	Hannah    	0.914	0.911777675
3623	2000-01-02 01:00:23	1032	Frank     	0.688	-0.14708446
3624	2000-01-02 01:00:24	971	Wendy     	0.323	-0.463022918
3625	2000-01-02 01:00:25	1013	Oliver    	-0.741	-0.335195154
3626	2000-01-02 01:00:26	972	Zelda     	0.915	-0.192645818
3627	2000-01-02 01:00:27	973	Dan       	-0.339	0.71601367
3628	2000-01-02 01:00:28	1054	Charlie   	-0.400	0.932610989
3629	2000-01-02 01:00:29	949	Hannah    	-0.983	0.300089598
3630	2000-01-02 01:00:30	1016	Victor    	0.723	-0.797109723
3631	2000-01-02 01:00:31	983	Yvonne    	0.573	-0.216597021
3632	2000-01-02 01:00:32	1031	Dan       	-0.834	-0.732040405
3633	2000-01-02 01:00:33	1051	Quinn     	-0.440	0.633846939
3634	2000-01-02 01:00:34	1034	Kevin     	0.708	0.658919513
3635	2000-01-02 01:00:35	1024	Oliver    	-0.439	-0.346189737
3636	2000-01-02 01:00:36	984	Yvonne    	0.687	-0.591916263
3637	2000-01-02 01:00:37	1002	Michael   	0.311	0.582999229
3638	2000-01-02 01:00:38	1024	Oliver    	0.533	-0.179088831
3639	2000-01-02 01:00:39	1009	Laura     	-0.966	-0.885702252
3640	2000-01-02 01:00:40	966	Sarah     	-0.334	-0.329273909
3641	2000-01-02 01:00:41	1052	Sarah     	-0.676	-0.551723301
3642	2000-01-02 01:00:42	1076	Hannah    	0.129	0.453086466
3643	2000-01-02 01:00:43	973	Yvonne    	0.411	0.986736178
3644	2000-01-02 01:00:44	981	Dan       	0.439	-0.635479629
3645	2000-01-02 01:00:45	962	Laura     	0.081	0.541908383
3646	2000-01-02 01:00:46	1029	Ray       	0.269	0.669873238
3647	2000-01-02 01:00:47	1017	Frank     	0.569	-0.613660097
3648	2000-01-02 01:00:48	1014	Edith     	0.427	-0.355188549
3649	2000-01-02 01:00:49	1044	Laura     	-0.096	-0.687086463
3650	2000-01-02 01:00:50	1013	Oliver    	-0.676	-0.562622786
3651	2000-01-02 01:00:51	1028	Sarah     	-0.196	-0.0971889272
3652	2000-01-02 01:00:52	952	Charlie   	-0.733	-0.479920387
3653	2000-01-02 01:00:53	939	Norbert   	-0.740	0.732899427
3654	2000-01-02 01:00:54	1020	Michael   	-0.234	-0.440881729
3655	2000-01-02 01:00:55	1031	Quinn     	-0.210	0.685304284
3656	2000-01-02 01:00:56	1017	Edith     	0.619	0.131924227
3657	2000-01-02 01:00:57	972	Bob       	0.387	-0.0396457091
3658	2000-01-02 01:00:58	958	George    	-0.360	0.0504836589
3659	2000-01-02 01:00:59	1023	Patricia  	0.410	0.133585811
3660	2000-01-02 01:01:00	957	Wendy     	-0.243	0.128218159
3661	2000-01-02 01:01:01	988	Hannah    	-0.218	-0.142149225
3662	2000-01-02 01:01:02	1020	Victor    	-0.976	0.873857439
3663	2000-01-02 01:01:03	1034	Sarah     	0.641	0.716934562
3664	2000-01-02 01:01:04	1004	Jerry     	-0.714	0.495250642
3665	2000-01-02 01:01:05	973	Sarah     	-0.337	0.817004979
3666	2000-01-02 01:01:06	1056	Zelda     	0.119	-0.0910321549
3667	2000-01-02 01:01:07	962	Jerry     	0.137	-0.367334753
3668	2000-01-02 01:01:08	1017	Yvonne    	-0.038	0.691613257
3669	2000-01-02 01:01:09	999	Zelda     	0.806	-0.0148313344
3670	2000-01-02 01:01:10	1052	Alice     	-0.637	-0.0194448158
3671	2000-01-02 01:01:11	985	Yvonne    	-0.286	-0.831352174
3672	2000-01-02 01:01:12	983	Victor    	-0.617	0.568315744
3673	2000-01-02 01:01:13	966	Alice     	-0.087	0.526855648
3674	2000-01-02 01:01:14	1018	Jerry     	0.673	-0.915700257
3675	2000-01-02 01:01:15	1032	Hannah    	0.683	-0.0943910331
3676	2000-01-02 01:01:16	995	Ingrid    	0.932	0.632551908
3677	2000-01-02 01:01:17	968	Frank     	0.916	0.550962389
3678	2000-01-02 01:01:18	1042	Wendy     	-0.895	0.0388327017
3679	2000-01-02 01:01:19	999	Laura     	0.132	0.961697996
3680	2000-01-02 01:01:20	993	Laura     	-0.863	0.162718266
3681	2000-01-02 01:01:21	1024	Frank     	-0.594	0.327722967
3682	2000-01-02 01:01:22	1013	Charlie   	-0.784	0.482118547
3683	2000-01-02 01:01:23	1032	Edith     	-0.423	-0.472362697
3684	2000-01-02 01:01:24	992	Dan       	0.896	-0.34054473
3685	2000-01-02 01:01:25	1011	Michael   	0.687	0.762307882
3686	2000-01-02 01:01:26	957	Bob       	-0.454	0.875549793
3687	2000-01-02 01:01:27	1070	Sarah     	0.735	-0.172846302
3688	2000-01-02 01:01:28	1010	Xavier    	0.960	0.0458352081
3689	2000-01-02 01:01:29	984	Yvonne    	0.824	-0.414687872
3690	2000-01-02 01:01:30	985	Ingrid    	-0.114	-0.345684618
3691	2000-01-02 01:01:31	959	Laura     	-0.992	-0.987175465
3692	2000-01-02 01:01:32	964	Ray       	-0.908	0.340751648
3693	2000-01-02 01:01:33	1029	Dan       	0.847	0.471770108
3694	2000-01-02 01:01:34	1037	George    	-0.323	0.462117881
3695	2000-01-02 01:01:35	1056	Wendy     	0.046	0.465436965
3696	2000-01-02 01:01:36	1053	Michael   	-0.433	-0.958600044
3697	2000-01-02 01:01:37	1047	Dan       	-0.625	-0.959422886
3698	2000-01-02 01:01:38	984	Jerry     	-0.033	-0.384936541
3699	2000-01-02 01:01:39	1005	Patricia  	-0.941	0.234241888
3700	2000-01-02 01:01:40	977	Ray       	0.995	-0.0811507851
3701	2000-01-02 01:01:41	975	Jerry     	0.082	-0.433052182
3702	2000-01-02 01:01:42	1001	George    	-0.220	0.0928740725
3703	2000-01-02 01:01:43	982	Yvonne    	-0.373	-0.992247164
3704	2000-01-02 01:01:44	974	Victor    	0.757	0.581847012
3705	2000-01-02 01:01:45	954	Dan       	-0.680	-0.102280088
3706	2000-01-02 01:01:46	1020	Laura     	-0.831	-0.60360229
3707	2000-01-02 01:01:47	1040	Patricia  	0.185	-0.147836745
3708	2000-01-02 01:01:48	946	Oliver    	0.582	-0.908840597
3709	2000-01-02 01:01:49	996	Michael   	0.136	-0.776188016
3710	2000-01-02 01:01:50	990	Xavier    	0.008	0.527649343
3711	2000-01-02 01:01:51	1057	Norbert   	0.194	-0.384221882
3712	2000-01-02 01:01:52	1029	Edith     	0.190	-0.253822684
3713	2000-01-02 01:01:53	1004	Sarah     	0.270	-0.239044428
3714	2000-01-02 01:01:54	970	Wendy     	0.172	-0.765602052
3715	2000-01-02 01:01:55	1005	Michael   	-0.454	0.303120643
3716	2000-01-02 01:01:56	987	Michael   	0.578	0.879578292
3717	2000-01-02 01:01:57	969	George    	-0.565	0.829264224
3718	2000-01-02 01:01:58	999	Patricia  	-0.896	0.865185201
3719	2000-01-02 01:01:59	1073	Quinn     	-0.193	-0.733281255
3720	2000-01-02 01:02:00	953	Michael   	-0.810	-0.207912832
3721	2000-01-02 01:02:01	999	Charlie   	0.052	-0.601069093
3722	2000-01-02 01:02:02	1005	Tim       	0.803	0.667761385
3723	2000-01-02 01:02:03	1008	Dan       	0.094	0.0950227976
3724	2000-01-02 01:02:04	994	Charlie   	-0.031	0.325253993
3725	2000-01-02 01:02:05	1014	Michael   	-0.562	-0.709984422
3726	2000-01-02 01:02:06	961	Oliver    	-0.116	-0.321314275
3727	2000-01-02 01:02:07	996	Tim       	-0.226	0.224691823
3728	2000-01-02 01:02:08	980	Edith     	0.429	0.732233226
3729	2000-01-02 01:02:09	1018	Ursula    	0.743	-0.353292286
3730	2000-01-02 01:02:10	1029	Quinn     	-0.933	0.79371798
3731	2000-01-02 01:02:11	971	Patricia  	-0.673	0.371638894
3732	2000-01-02 01:02:12	1014	Jerry     	-0.573	-0.562402368
3733	2000-01-02 01:02:13	1027	Patricia  	0.937	0.0510292873
3734	2000-01-02 01:02:14	1032	Ingrid    	0.997	-0.121089511
3735	2000-01-02 01:02:15	959	Charlie   	0.540	-0.815940201
3736	2000-01-02 01:02:16	1011	Sarah     	0.210	0.334213793
3737	2000-01-02 01:02:17	959	Zelda     	-0.029	-0.760558128
3738	2000-01-02 01:02:18	987	Victor    	0.347	-0.502952695
3739	2000-01-02 01:02:19	1005	George    	0.529	-0.833639264
3740	2000-01-02 01:02:20	1008	Quinn     	-0.307	-0.222100094
3741	2000-01-02 01:02:21	1057	Hannah    	0.344	-0.795642555
3742	2000-01-02 01:02:22	994	Xavier    	0.833	0.0428701378
3743	2000-01-02 01:02:23	936	Yvonne    	-0.291	-0.435643375
3744	2000-01-02 01:02:24	1021	Victor    	0.017	-0.218489736
3745	2000-01-02 01:02:25	1021	Jerry     	0.699	0.888759673
3746	2000-01-02 01:02:26	1073	Frank     	0.099	0.308225453
3747	2000-01-02 01:02:27	1017	Charlie   	-0.804	0.909388244
3748	2000-01-02 01:02:28	1055	Bob       	-0.700	-0.137389988
3749	2000-01-02 01:02:29	973	Frank     	0.786	0.0255500097
3750	2000-01-02 01:02:30	1010	Charlie   	-0.396	-0.702606142
3751	2000-01-02 01:02:31	1010	Bob       	0.495	0.448799372
3752	2000-01-02 01:02:32	997	Bob       	-0.521	0.0207809228
3753	2000-01-02 01:02:33	975	Ursula    	-0.736	-0.337307692
3754	2000-01-02 01:02:34	992	Frank     	-0.585	-0.636104822
3755	2000-01-02 01:02:35	1020	Patricia  	-0.368	0.635501087
3756	2000-01-02 01:02:36	1016	Dan       	0.429	0.249123484
3757	2000-01-02 01:02:37	1048	Yvonne    	-0.487	-0.175626323
3758	2000-01-02 01:02:38	1004	George    	0.381	-0.410948902
3759	2000-01-02 01:02:39	983	Wendy     	0.243	0.594061792
3760	2000-01-02 01:02:40	979	Edith     	0.083	-0.901810348
3761	2000-01-02 01:02:41	998	Ingrid    	-0.279	-0.304647446
3762	2000-01-02 01:02:42	1053	Michael   	-0.030	0.125674322
3763	2000-01-02 01:02:43	997	George    	-0.800	0.620101869
3764	2000-01-02 01:02:44	1004	Ray       	0.336	-0.0266829412
3765	2000-01-02 01:02:45	1023	Wendy     	0.183	-0.562129021
3766	2000-01-02 01:02:46	992	Sarah     	0.978	0.0797910243
3767	2000-01-02 01:02:47	1012	Kevin     	0.338	0.80030328
3768	2000-01-02 01:02:48	991	Victor    	0.406	-0.833518386
3769	2000-01-02 01:02:49	1021	Victor    	-0.829	0.705303133
3770	2000-01-02 01:02:50	1028	Kevin     	0.966	-0.81246978
3771	2000-01-02 01:02:51	1058	Quinn     	0.071	-0.207427368
3772	2000-01-02 01:02:52	1038	Norbert   	-0.764	-0.69230181
3773	2000-01-02 01:02:53	1015	Michael   	-0.077	-0.0245125704
3774	2000-01-02 01:02:54	973	Bob       	-0.765	-0.530127764
3775	2000-01-02 01:02:55	979	Victor    	-0.816	0.47344026
3776	2000-01-02 01:02:56	1023	Jerry     	0.857	-0.330973059
3777	2000-01-02 01:02:57	1002	Sarah     	0.411	0.233549058
3778	2000-01-02 01:02:58	1040	Bob       	0.323	0.992295742
3779	2000-01-02 01:02:59	1022	Quinn     	-0.937	-0.644716382
3780	2000-01-02 01:03:00	1001	Edith     	-0.359	0.258331329
3781	2000-01-02 01:03:01	1023	Zelda     	-0.948	0.439110488
3782	2000-01-02 01:03:02	1029	Laura     	-0.868	-0.874852121
3783	2000-01-02 01:03:03	1029	Quinn     	0.214	0.226140589
3784	2000-01-02 01:03:04	1000	Edith     	0.112	-0.617224574
3785	2000-01-02 01:03:05	996	Laura     	0.605	-0.252646744
3786	2000-01-02 01:03:06	957	Dan       	0.899	0.288875341
3787	2000-01-02 01:03:07	1017	Ursula    	-0.780	-0.830385625
3788	2000-01-02 01:03:08	1042	Bob       	0.705	0.0292000733
3789	2000-01-02 01:03:09	1012	Ray       	-0.784	-0.684381902
3790	2000-01-02 01:03:10	982	Kevin     	0.474	0.599981308
3791	2000-01-02 01:03:11	1050	Zelda     	-0.899	-0.208485737
3792	2000-01-02 01:03:12	968	Alice     	0.388	-0.10837999
3793	2000-01-02 01:03:13	1045	Michael   	-0.292	0.292378008
3794	2000-01-02 01:03:14	972	Hannah    	-0.544	0.651039124
3795	2000-01-02 01:03:15	1012	Kevin     	-0.718	0.0955803022
3796	2000-01-02 01:03:16	968	Hannah    	-0.602	0.886537373
3797	2000-01-02 01:03:17	1003	Michael   	0.372	0.177362725
3798	2000-01-02 01:03:18	1041	Edith     	0.544	-0.149358988
3799	2000-01-02 01:03:19	987	Oliver    	0.362	0.00774769951
3800	2000-01-02 01:03:20	980	Kevin     	-0.541	-0.813313425
3801	2000-01-02 01:03:21	958	Ray       	0.465	-0.035766881
3802	2000-01-02 01:03:22	1055	Patricia  	-0.206	0.60760504
3803	2000-01-02 01:03:23	961	Dan       	0.607	0.766578317
3804	2000-01-02 01:03:24	970	Laura     	-0.669	-0.616890132
3805	2000-01-02 01:03:25	1006	Hannah    	0.091	-0.797774673
3806	2000-01-02 01:03:26	1025	Ursula    	-0.199	0.423399985
3807	2000-01-02 01:03:27	1063	Alice     	-0.881	-0.675894678
3808	2000-01-02 01:03:28	949	Alice     	0.978	-0.487677246
3809	2000-01-02 01:03:29	996	Ingrid    	-0.970	-0.411569625
3810	2000-01-02 01:03:30	1045	Alice     	0.766	-0.182113335
3811	2000-01-02 01:03:31	1047	Ingrid    	-0.924	0.521517694
3812	2000-01-02 01:03:32	1032	Oliver    	-0.421	0.0678685084
3813	2000-01-02 01:03:33	974	Alice     	0.848	0.860244572
3814	2000-01-02 01:03:34	1011	Ursula    	-0.095	0.609248638
3815	2000-01-02 01:03:35	995	Kevin     	0.825	-0.722623944
3816	2000-01-02 01:03:36	969	Alice     	-0.584	-0.620873332
3817	2000-01-02 01:03:37	1041	Ray       	-0.943	-0.479628026
3818	2000-01-02 01:03:38	992	Xavier    	-0.344	-0.917076886
3819	2000-01-02 01:03:39	1041	Oliver    	-0.298	-0.946557581
3820	2000-01-02 01:03:40	990	Sarah     	0.904	-0.188193396
3821	2000-01-02 01:03:41	1032	Sarah     	-0.363	-0.212881505
3822	2000-01-02 01:03:42	980	Edith     	-0.276	0.740855813
3823	2000-01-02 01:03:43	1003	Bob       	0.265	0.654178083
3824	2000-01-02 01:03:44	983	Norbert   	0.657	0.782763541
3825	2000-01-02 01:03:45	990	Charlie   	-0.096	-0.83815527
3826	2000-01-02 01:03:46	1048	Victor    	0.926	-0.773116887
3827	2000-01-02 01:03:47	992	Sarah     	0.077	0.9620682
3828	2000-01-02 01:03:48	952	Ingrid    	0.264	0.535454154
3829	2000-01-02 01:03:49	1001	Sarah     	-0.023	0.097332783
3830	2000-01-02 01:03:50	1004	Michael   	0.633	-0.0216362588
3831	2000-01-02 01:03:51	1049	Zelda     	-0.590	0.160841987
3832	2000-01-02 01:03:52	1040	Ursula    	0.673	-0.956368923
3833	2000-01-02 01:03:53	944	Michael   	0.477	0.470185488
3834	2000-01-02 01:03:54	1051	Bob       	-0.543	-0.915724874
3835	2000-01-02 01:03:55	1032	Dan       	-0.001	0.913564742
3836	2000-01-02 01:03:56	1065	Ursula    	-0.553	0.786357164
3837	2000-01-02 01:03:57	1030	Kevin     	-0.489	-0.912192285
3838	2000-01-02 01:03:58	979	Laura     	-0.298	-0.407848537
3839	2000-01-02 01:03:59	996	Frank     	0.113	0.0334060676
3840	2000-01-02 01:04:00	1017	Tim       	-0.371	-0.154868513
3841	2000-01-02 01:04:01	977	Yvonne    	-0.559	0.258023828
3842	2000-01-02 01:04:02	1007	Michael   	-0.131	0.830364943
3843	2000-01-02 01:04:03	998	Ursula    	0.140	0.391083568
3844	2000-01-02 01:04:04	977	Frank     	0.573	-0.921088815
3845	2000-01-02 01:04:05	984	George    	-0.975	-0.356403261
3846	2000-01-02 01:04:06	997	Alice     	-0.313	-0.816259146
3847	2000-01-02 01:04:07	960	Laura     	0.704	-0.856510937
3848	2000-01-02 01:04:08	938	Ursula    	0.395	0.521686196
3849	2000-01-02 01:04:09	1047	Xavier    	0.551	0.455368787
3850	2000-01-02 01:04:10	995	Laura     	-0.771	-0.570721865
3851	2000-01-02 01:04:11	997	Michael   	0.064	0.775220394
3852	2000-01-02 01:04:12	992	Jerry     	-0.681	0.409720421
3853	2000-01-02 01:04:13	967	Frank     	0.363	-0.820104361
3854	2000-01-02 01:04:14	1028	Edith     	-0.439	-0.177038103
3855	2000-01-02 01:04:15	1023	Ray       	0.319	0.564675927
3856	2000-01-02 01:04:16	1022	Alice     	0.350	-0.6669209
3857	2000-01-02 01:04:17	1043	Quinn     	-0.786	0.668117285
3858	2000-01-02 01:04:18	1000	Tim       	-0.418	-0.717571735
3859	2000-01-02 01:04:19	1031	Frank     	-0.329	0.768606484
3860	2000-01-02 01:04:20	983	Oliver    	-0.641	0.777917445
3861	2000-01-02 01:04:21	979	George    	0.331	0.0741049796
3862	2000-01-02 01:04:22	1043	Wendy     	-0.485	0.6491552
3863	2000-01-02 01:04:23	1030	Zelda     	0.291	0.997996747
3864	2000-01-02 01:04:24	982	Sarah     	0.425	-0.848790586
3865	2000-01-02 01:04:25	1003	Patricia  	0.732	0.661748528
3866	2000-01-02 01:04:26	982	Michael   	-0.437	0.447689027
3867	2000-01-02 01:04:27	1047	Hannah    	-0.148	-0.692524433
3868	2000-01-02 01:04:28	1024	Patricia  	-0.638	-0.203013688
3869	2000-01-02 01:04:29	992	Edith     	-0.937	-0.437343478
3870	2000-01-02 01:04:30	1041	Kevin     	0.943	0.968407154
3871	2000-01-02 01:04:31	1010	Hannah    	0.253	0.842977166
3872	2000-01-02 01:04:32	1004	Ingrid    	-0.989	-0.759448946
3873	2000-01-02 01:04:33	975	Tim       	-0.063	-0.98923552
3874	2000-01-02 01:04:34	1044	Patricia  	0.964	-0.722156882
3875	2000-01-02 01:04:35	1024	Jerry     	0.102	-0.461901426
3876	2000-01-02 01:04:36	1004	Yvonne    	0.885	0.892799556
3877	2000-01-02 01:04:37	972	Charlie   	-0.720	0.357490122
3878	2000-01-02 01:04:38	1016	Zelda     	-0.077	0.737870097
3879	2000-01-02 01:04:39	1030	Wendy     	-0.398	0.930579662
3880	2000-01-02 01:04:40	971	Victor    	-0.540	0.347809404
3881	2000-01-02 01:04:41	1004	Alice     	-0.969	0.755612671
3882	2000-01-02 01:04:42	1030	Edith     	-0.823	0.0958997086
3883	2000-01-02 01:04:43	998	Jerry     	0.243	-0.562396348
3884	2000-01-02 01:04:44	974	Oliver    	-0.766	0.0120211421
3885	2000-01-02 01:04:45	964	Laura     	-0.486	-0.775302291
3886	2000-01-02 01:04:46	1000	Alice     	-0.565	-0.699375749
3887	2000-01-02 01:04:47	1001	Ray       	-0.060	0.533478141
3888	2000-01-02 01:04:48	1005	Ray       	-0.854	-0.902841151
3889	2000-01-02 01:04:49	987	Dan       	-0.955	-0.49408263
3890	2000-01-02 01:04:50	1015	Oliver    	-0.827	-0.0851513222
3891	2000-01-02 01:04:51	1033	Wendy     	-0.758	-0.846521378
3892	2000-01-02 01:04:52	982	Sarah     	-0.598	0.36202988
3893	2000-01-02 01:04:53	952	Sarah     	0.051	-0.000946053711
3894	2000-01-02 01:04:54	1019	Tim       	0.874	0.115986772
3895	2000-01-02 01:04:55	979	Victor    	-0.377	0.939886928
3896	2000-01-02 01:04:56	976	Zelda     	-0.071	0.836246431
3897	2000-01-02 01:04:57	934	Frank     	0.927	-0.522448301
3898	2000-01-02 01:04:58	1032	Wendy     	0.320	-0.06456431
3899	2000-01-02 01:04:59	974	Sarah     	-0.170	-0.176949576
3900	2000-01-02 01:05:00	996	Yvonne    	-0.902	-0.403287649
3901	2000-01-02 01:05:01	1033	Wendy     	0.629	0.18189773
3902	2000-01-02 01:05:02	982	Hannah    	0.793	-0.192301109
3903	2000-01-02 01:05:03	967	Wendy     	-0.918	-0.141619787
3904	2000-01-02 01:05:04	1036	Quinn     	0.134	-0.52281028
3905	2000-01-02 01:05:05	986	Charlie   	-0.309	0.370314002
3906	2000-01-02 01:05:06	964	George    	0.098	0.898194671
3907	2000-01-02 01:05:07	958	Alice     	-0.508	0.677153111
3908	2000-01-02 01:05:08	1026	Frank     	-0.175	-0.23013477
3909	2000-01-02 01:05:09	942	Dan       	-0.771	-0.250153273
3910	2000-01-02 01:05:10	927	George    	0.869	0.574961305
3911	2000-01-02 01:05:11	989	Ray       	0.070	-0.3405478
3912	2000-01-02 01:05:12	971	Hannah    	0.487	0.671158493
3913	2000-01-02 01:05:13	995	Sarah     	0.153	0.93604213
3914	2000-01-02 01:05:14	944	Sarah     	0.005	-0.160881534
3915	2000-01-02 01:05:15	1000	Zelda     	0.857	0.953717113
3916	2000-01-02 01:05:16	983	Hannah    	0.358	0.123601571
3917	2000-01-02 01:05:17	988	George    	0.631	0.941235662
3918	2000-01-02 01:05:18	1039	Dan       	-0.359	0.919837534
3919	2000-01-02 01:05:19	1026	Laura     	-0.892	-0.25583306
3920	2000-01-02 01:05:20	927	Hannah    	-0.589	0.543345511
3921	2000-01-02 01:05:21	954	Oliver    	0.391	-0.932916462
3922	2000-01-02 01:05:22	957	Ingrid    	-0.732	-0.848273695
3923	2000-01-02 01:05:23	1051	Charlie   	-0.353	-0.364444971
3924	2000-01-02 01:05:24	1014	Michael   	0.756	0.0320283398
3925	2000-01-02 01:05:25	987	Yvonne    	0.742	-0.860394776
3926	2000-01-02 01:05:26	1026	Sarah     	-0.915	-0.264959306
3927	2000-01-02 01:05:27	991	Michael   	0.936	-0.620681822
3928	2000-01-02 01:05:28	1044	Patricia  	0.818	0.891279876
3929	2000-01-02 01:05:29	1042	Dan       	-0.223	-0.821357429
3930	2000-01-02 01:05:30	973	Ursula    	-0.555	-0.958175123
3931	2000-01-02 01:05:31	1045	Hannah    	-0.383	0.825336695
3932	2000-01-02 01:05:32	984	Ursula    	0.121	0.732877374
3933	2000-01-02 01:05:33	1002	Sarah     	-0.314	-0.274889022
3934	2000-01-02 01:05:34	1049	Kevin     	0.754	0.0247801226
3935	2000-01-02 01:05:35	956	Sarah     	0.894	-0.916715741
3936	2000-01-02 01:05:36	1004	Bob       	0.857	-0.25304535
3937	2000-01-02 01:05:37	1032	Patricia  	0.668	0.392217755
3938	2000-01-02 01:05:38	1039	Quinn     	0.029	-0.877526104
3939	2000-01-02 01:05:39	936	Edith     	0.510	0.123237342
3940	2000-01-02 01:05:40	1002	Sarah     	-0.200	-0.394033194
3941	2000-01-02 01:05:41	944	Frank     	0.924	-0.0159279052
3942	2000-01-02 01:05:42	993	Hannah    	0.901	-0.191631779
3943	2000-01-02 01:05:43	1034	Frank     	-0.194	0.793964088
3944	2000-01-02 01:05:44	1018	Ursula    	-0.194	-0.288632751
3945	2000-01-02 01:05:45	1045	Sarah     	-0.485	0.854887247
3946	2000-01-02 01:05:46	1026	Jerry     	-0.775	0.320745647
3947	2000-01-02 01:05:47	1060	Laura     	0.050	-0.897763968
3948	2000-01-02 01:05:48	998	George    	0.786	-0.0657280684
3949	2000-01-02 01:05:49	1069	Wendy     	-0.597	-0.349350959
3950	2000-01-02 01:05:50	998	Yvonne    	0.040	-0.307802141
3951	2000-01-02 01:05:51	995	Charlie   	-0.728	-0.41746676
3952	2000-01-02 01:05:52	1002	Jerry     	-0.355	-0.925876915
3953	2000-01-02 01:05:53	1031	Xavier    	0.695	-0.960178077
3954	2000-01-02 01:05:54	967	Yvonne    	0.160	-0.652332008
3955	2000-01-02 01:05:55	978	Edith     	0.029	0.316007227
3956	2000-01-02 01:05:56	1027	Tim       	-0.485	0.0607416742
3957	2000-01-02 01:05:57	986	Laura     	0.565	-0.431730092
3958	2000-01-02 01:05:58	999	Wendy     	0.453	-0.234948292
3959	2000-01-02 01:05:59	998	Alice     	0.182	-0.790141463
3960	2000-01-02 01:06:00	1032	Ingrid    	0.743	0.432417661
3961	2000-01-02 01:06:01	1015	Norbert   	-0.821	0.979586244
3962	2000-01-02 01:06:02	987	Victor    	-0.793	0.902384937
3963	2000-01-02 01:06:03	974	Oliver    	-0.287	-0.447136253
3964	2000-01-02 01:06:04	1013	Bob       	0.307	-0.773569465
3965	2000-01-02 01:06:05	1044	Edith     	-0.179	-0.517766416
3966	2000-01-02 01:06:06	1012	Victor    	-0.927	-0.743877053
3967	2000-01-02 01:06:07	959	Yvonne    	-0.645	-0.573238432
3968	2000-01-02 01:06:08	954	Yvonne    	-0.265	0.444742084
3969	2000-01-02 01:06:09	998	Ray       	-0.156	-0.761057675
3970	2000-01-02 01:06:10	1021	Ingrid    	-0.633	-0.107501954
3971	2000-01-02 01:06:11	1004	Kevin     	0.925	-0.092468299
3972	2000-01-02 01:06:12	974	Charlie   	-0.328	-0.33545661
3973	2000-01-02 01:06:13	978	Ursula    	0.470	0.0751405358
3974	2000-01-02 01:06:14	964	Edith     	0.670	0.987496614
3975	2000-01-02 01:06:15	977	Kevin     	0.645	0.377373904
3976	2000-01-02 01:06:16	1027	Wendy     	0.488	0.867326975
3977	2000-01-02 01:06:17	1000	George    	0.403	0.956472397
3978	2000-01-02 01:06:18	1001	Michael   	0.442	-0.445206106
3979	2000-01-02 01:06:19	978	Charlie   	0.774	0.946441293
3980	2000-01-02 01:06:20	1047	Quinn     	-0.592	-0.95842576
3981	2000-01-02 01:06:21	976	Kevin     	0.680	-0.31078583
3982	2000-01-02 01:06:22	981	Laura     	-0.910	-0.73914957
3983	2000-01-02 01:06:23	983	Ursula    	0.802	-0.285228819
3984	2000-01-02 01:06:24	960	Ursula    	0.370	0.648767412
3985	2000-01-02 01:06:25	1014	George    	-0.323	0.583819747
3986	2000-01-02 01:06:26	974	Victor    	0.760	-0.0407689475
3987	2000-01-02 01:06:27	983	Bob       	-0.583	0.592716157
3988	2000-01-02 01:06:28	1002	Patricia  	-0.398	-0.05185863
3989	2000-01-02 01:06:29	990	Michael   	-0.901	-0.758827388
3990	2000-01-02 01:06:30	995	Bob       	0.555	0.00957057718
3991	2000-01-02 01:06:31	1007	Edith     	-0.535	0.679502606
3992	2000-01-02 01:06:32	1004	Norbert   	0.106	-0.763710022
3993	2000-01-02 01:06:33	1022	Norbert   	-0.487	-0.369445086
3994	2000-01-02 01:06:34	1027	Jerry     	0.631	0.698577583
3995	2000-01-02 01:06:35	1009	Ray       	0.026	0.54343909
3996	2000-01-02 01:06:36	910	Laura     	0.806	0.0439885221
3997	2000-01-02 01:06:37	1020	Michael   	-0.464	-0.124293245
3998	2000-01-02 01:06:38	1036	Oliver    	-0.168	0.720196307
3999	2000-01-02 01:06:39	998	Edith     	0.666	0.481349528
4000	2000-01-02 01:06:40	1010	Norbert   	0.668	-0.491793185
4001	2000-01-02 01:06:41	984	Ingrid    	-0.802	0.355140597
4002	2000-01-02 01:06:42	1020	Victor    	-0.458	0.108958416
4003	2000-01-02 01:06:43	992	Frank     	-0.388	-0.492212355
4004	2000-01-02 01:06:44	999	Quinn     	0.248	0.429940641
4005	2000-01-02 01:06:45	1055	Tim       	0.449	-0.886327863
4006	2000-01-02 01:06:46	1009	Ray       	-0.455	0.126214266
4007	2000-01-02 01:06:47	984	Norbert   	0.145	-0.598564386
4008	2000-01-02 01:06:48	1019	Laura     	0.502	-0.071775347
4009	2000-01-02 01:06:49	950	Xavier    	0.460	0.692077339
4010	2000-01-02 01:06:50	1007	Ursula    	0.422	-0.35287717
4011	2000-01-02 01:06:51	1028	Ray       	0.083	0.868918061
4012	2000-01-02 01:06:52	1028	Wendy     	-0.478	0.629560173
4013	2000-01-02 01:06:53	1023	Laura     	-0.738	-0.547610641
4014	2000-01-02 01:06:54	976	Charlie   	-0.096	-0.678522408
4015	2000-01-02 01:06:55	986	Zelda     	0.468	0.281360388
4016	2000-01-02 01:06:56	1034	Wendy     	-0.111	-0.73714
4017	2000-01-02 01:06:57	1007	Charlie   	-0.838	-0.395038188
4018	2000-01-02 01:06:58	996	Michael   	-0.937	0.750995159
4019	2000-01-02 01:06:59	1029	Victor    	0.155	-0.860299408
4020	2000-01-02 01:07:00	1000	Victor    	0.735	-0.873335242
4021	2000-01-02 01:07:01	972	Kevin     	0.954	-0.642722666
4022	2000-01-02 01:07:02	1019	Norbert   	0.232	-0.212441027
4023	2000-01-02 01:07:03	990	Tim       	-0.871	0.605159342
4024	2000-01-02 01:07:04	993	Michael   	-0.932	0.51035279
4025	2000-01-02 01:07:05	1018	Ray       	-0.201	0.399961144
4026	2000-01-02 01:07:06	977	Ray       	-0.859	-0.154440701
4027	2000-01-02 01:07:07	981	Oliver    	0.377	0.429600209
4028	2000-01-02 01:07:08	994	Dan       	-0.911	-0.992981374
4029	2000-01-02 01:07:09	960	Alice     	0.096	-0.24938333
4030	2000-01-02 01:07:10	976	Jerry     	-0.983	-0.0454675145
4031	2000-01-02 01:07:11	1021	Alice     	-0.653	-0.452135533
4032	2000-01-02 01:07:12	1007	Yvonne    	0.059	0.11935655
4033	2000-01-02 01:07:13	954	Ray       	0.226	-0.34937039
4034	2000-01-02 01:07:14	985	Bob       	-0.200	0.504552901
4035	2000-01-02 01:07:15	1077	Ray       	0.518	0.600012362
4036	2000-01-02 01:07:16	1000	Edith     	0.834	0.180463225
4037	2000-01-02 01:07:17	1016	Tim       	0.716	-0.263802558
4038	2000-01-02 01:07:18	981	Victor    	-0.230	-0.898520708
4039	2000-01-02 01:07:19	1030	Dan       	-0.099	0.398410618
4040	2000-01-02 01:07:20	1040	Hannah    	-0.857	-0.270084888
4041	2000-01-02 01:07:21	997	Hannah    	-0.635	-0.432307154
4042	2000-01-02 01:07:22	981	Norbert   	-0.394	-0.857562065
4043	2000-01-02 01:07:23	996	Sarah     	-0.369	0.966260076
4044	2000-01-02 01:07:24	963	Hannah    	0.303	0.916726589
4045	2000-01-02 01:07:25	1007	Alice     	-0.110	-0.00763736526
4046	2000-01-02 01:07:26	1013	Victor    	-0.184	0.921526611
4047	2000-01-02 01:07:27	981	Wendy     	0.506	-0.906147897
4048	2000-01-02 01:07:28	1009	Michael   	-0.770	0.453881323
4049	2000-01-02 01:07:29	956	Quinn     	-0.316	0.445463151
4050	2000-01-02 01:07:30	990	Dan       	0.565	-0.808936715
4051	2000-01-02 01:07:31	1032	Patricia  	-0.603	0.199448347
4052	2000-01-02 01:07:32	984	Charlie   	-0.294	-0.754303753
4053	2000-01-02 01:07:33	997	Frank     	0.240	-0.447680354
4054	2000-01-02 01:07:34	988	Bob       	0.147	0.467812091
4055	2000-01-02 01:07:35	1038	Quinn     	0.591	0.500268042
4056	2000-01-02 01:07:36	1014	Patricia  	0.490	0.779542685
4057	2000-01-02 01:07:37	1000	Bob       	0.375	-0.595243931
4058	2000-01-02 01:07:38	1051	Norbert   	-0.150	-0.48508814
4059	2000-01-02 01:07:39	1089	Wendy     	-0.720	-0.614517748
4060	2000-01-02 01:07:40	997	Bob       	-0.775	0.757852793
4061	2000-01-02 01:07:41	1048	Zelda     	-0.386	0.327844352
4062	2000-01-02 01:07:42	947	Ingrid    	0.663	0.31325835
4063	2000-01-02 01:07:43	1010	Wendy     	0.172	-0.239633486
4064	2000-01-02 01:07:44	1025	Tim       	0.941	0.87684983
4065	2000-01-02 01:07:45	1020	Xavier    	-0.053	-0.739713132
4066	2000-01-02 01:07:46	1010	Tim       	0.083	-0.689279318
4067	2000-01-02 01:07:47	1011	Bob       	-0.745	-0.888129771
4068	2000-01-02 01:07:48	962	Ingrid    	0.777	-0.815107465
4069	2000-01-02 01:07:49	960	Dan       	-0.748	-0.641459286
4070	2000-01-02 01:07:50	984	Ingrid    	0.271	0.201673657
4071	2000-01-02 01:07:51	1036	Ingrid    	0.236	-0.886600256
4072	2000-01-02 01:07:52	972	Ray       	0.049	-0.686522007
4073	2000-01-02 01:07:53	961	Kevin     	-0.612	0.31049785
4074	2000-01-02 01:07:54	961	Frank     	0.865	-0.753635406
4075	2000-01-02 01:07:55	1001	Oliver    	0.561	0.477894187
4076	2000-01-02 01:07:56	1002	Laura     	0.003	0.0553826913
4077	2000-01-02 01:07:57	940	Zelda     	0.870	-0.790501773
4078	2000-01-02 01:07:58	1053	Tim       	0.004	-0.0563028976
4079	2000-01-02 01:07:59	974	Norbert   	0.969	0.825028121
4080	2000-01-02 01:08:00	1002	Sarah     	0.664	-0.394212514
4081	2000-01-02 01:08:01	970	Edith     	0.864	0.421816736
4082	2000-01-02 01:08:02	1022	Tim       	0.217	-0.832858264
4083	2000-01-02 01:08:03	924	Charlie   	-0.867	-0.14084965
4084	2000-01-02 01:08:04	1017	Alice     	-0.908	-0.352598608
4085	2000-01-02 01:08:05	1021	Xavier    	-0.703	0.874540329
4086	2000-01-02 01:08:06	999	Ray       	-0.547	0.0595082641
4087	2000-01-02 01:08:07	1043	Dan       	0.777	-0.650347948
4088	2000-01-02 01:08:08	989	Jerry     	-0.764	0.312498003
4089	2000-01-02 01:08:09	1006	Yvonne    	0.963	-0.443074763
4090	2000-01-02 01:08:10	974	Frank     	-0.310	-0.523614943
4091	2000-01-02 01:08:11	995	Victor    	-0.738	-0.974864066
4092	2000-01-02 01:08:12	956	Kevin     	-0.445	0.623698413
4093	2000-01-02 01:08:13	1024	Michael   	-0.071	0.69543606
4094	2000-01-02 01:08:14	974	Edith     	-0.033	0.842190683
4095	2000-01-02 01:08:15	960	Bob       	0.912	-0.125496492
4096	2000-01-02 01:08:16	1024	Alice     	0.176	-0.919800937
4097	2000-01-02 01:08:17	1019	Oliver    	-0.456	-0.0504582152
4098	2000-01-02 01:08:18	1003	Ursula    	0.913	-0.593445659
4099	2000-01-02 01:08:19	947	Oliver    	0.871	-0.762363851
4100	2000-01-02 01:08:20	968	Michael   	-0.294	-0.638469815
4101	2000-01-02 01:08:21	974	Ray       	0.877	-0.905489385
4102	2000-01-02 01:08:22	932	Kevin     	0.109	0.589422345
4103	2000-01-02 01:08:23	991	Norbert   	0.649	-0.508711517
4104	2000-01-02 01:08:24	1017	Charlie   	-0.918	0.44417128
4105	2000-01-02 01:08:25	966	Xavier    	-0.185	0.127767667
4106	2000-01-02 01:08:26	1002	Tim       	-0.784	-0.999759495
4107	2000-01-02 01:08:27	1022	Jerry     	-0.218	0.0164435823
4108	2000-01-02 01:08:28	976	Dan       	0.108	-0.642101169
4109	2000-01-02 01:08:29	999	Edith     	0.801	0.721638024
4110	2000-01-02 01:08:30	1052	Hannah    	0.733	0.192586258
4111	2000-01-02 01:08:31	1041	Dan       	-0.629	0.130186155
4112	2000-01-02 01:08:32	1059	Norbert   	-0.571	0.256586403
4113	2000-01-02 01:08:33	1034	Kevin     	0.675	0.504238486
4114	2000-01-02 01:08:34	997	Wendy     	0.564	-0.148717135
4115	2000-01-02 01:08:35	995	Hannah    	0.893	0.343748122
4116	2000-01-02 01:08:36	1052	Yvonne    	0.359	-0.453233361
4117	2000-01-02 01:08:37	954	Victor    	-0.379	-0.41486752
4118	2000-01-02 01:08:38	922	Sarah     	0.716	-0.970904589
4119	2000-01-02 01:08:39	993	Oliver    	0.738	-0.022268597
4120	2000-01-02 01:08:40	949	Victor    	-0.414	0.142402038
4121	2000-01-02 01:08:41	1018	Frank     	0.819	0.948429704
4122	2000-01-02 01:08:42	965	Ursula    	-0.187	0.452187449
4123	2000-01-02 01:08:43	1025	Ursula    	0.861	0.771197915
4124	2000-01-02 01:08:44	1030	Yvonne    	0.549	-0.233176678
4125	2000-01-02 01:08:45	1048	Frank     	-0.094	-0.829254508
4126	2000-01-02 01:08:46	1026	Sarah     	-0.795	0.968186975
4127	2000-01-02 01:08:47	1045	Tim       	-0.179	-0.283524156
4128	2000-01-02 01:08:48	941	Wendy     	0.414	0.834919691
4129	2000-01-02 01:08:49	1044	George    	-0.265	-0.646974087
4130	2000-01-02 01:08:50	1041	Sarah     	0.389	0.42798084
4131	2000-01-02 01:08:51	1024	Sarah     	0.618	0.288164496
4132	2000-01-02 01:08:52	1039	Xavier    	0.898	0.790429592
4133	2000-01-02 01:08:53	1012	Patricia  	0.937	0.955184042
4134	2000-01-02 01:08:54	988	Xavier    	0.296	-0.656229615
4135	2000-01-02 01:08:55	1053	Laura     	-0.780	-0.219176427
4136	2000-01-02 01:08:56	1019	Kevin     	0.776	-0.52680701
4137	2000-01-02 01:08:57	1017	Norbert   	0.320	-0.950953424
4138	2000-01-02 01:08:58	1017	Frank     	0.577	-0.0659153983
4139	2000-01-02 01:08:59	1047	Patricia  	-0.821	-0.122459777
4140	2000-01-02 01:09:00	990	Ingrid    	-0.179	-0.232067361
4141	2000-01-02 01:09:01	1034	Laura     	-0.989	0.0316604488
4142	2000-01-02 01:09:02	970	Ingrid    	0.072	-0.342908889
4143	2000-01-02 01:09:03	1016	Patricia  	-0.523	-0.34060967
4144	2000-01-02 01:09:04	1012	Frank     	-0.062	-0.87834084
4145	2000-01-02 01:09:05	1002	Wendy     	-0.276	-0.802134812
4146	2000-01-02 01:09:06	1029	Dan       	-0.705	0.339036614
4147	2000-01-02 01:09:07	1043	Kevin     	-0.666	-0.852616906
4148	2000-01-02 01:09:08	1032	Frank     	0.101	0.386505634
4149	2000-01-02 01:09:09	974	Hannah    	-0.266	0.644199729
4150	2000-01-02 01:09:10	1040	Wendy     	-0.909	-0.148412541
4151	2000-01-02 01:09:11	1040	Bob       	-1.000	0.617263496
4152	2000-01-02 01:09:12	1023	Wendy     	0.072	0.0177223142
4153	2000-01-02 01:09:13	965	Bob       	0.965	0.0309396908
4154	2000-01-02 01:09:14	1035	Tim       	-0.808	-0.411896378
4155	2000-01-02 01:09:15	965	Oliver    	-0.192	0.139888704
4156	2000-01-02 01:09:16	988	Kevin     	0.841	-0.103984274
4157	2000-01-02 01:09:17	977	Quinn     	0.412	0.793713152
4158	2000-01-02 01:09:18	975	Oliver    	0.389	0.0317107849
4159	2000-01-02 01:09:19	1013	Hannah    	-0.742	0.768063605
4160	2000-01-02 01:09:20	998	Michael   	0.178	0.797774196
4161	2000-01-02 01:09:21	1002	Oliver    	-0.335	-0.499547094
4162	2000-01-02 01:09:22	1010	Xavier    	-0.474	-0.99567169
4163	2000-01-02 01:09:23	1030	Quinn     	-0.129	0.831065118
4164	2000-01-02 01:09:24	1024	Kevin     	-0.572	5.71946148e-05
4165	2000-01-02 01:09:25	975	Yvonne    	0.267	-0.891008258
4166	2000-01-02 01:09:26	980	Ingrid    	-0.577	-0.642277122
4167	2000-01-02 01:09:27	983	Oliver    	-0.062	-0.0873592198
4168	2000-01-02 01:09:28	976	Kevin     	-0.188	0.280566216
4169	2000-01-02 01:09:29	1000	Dan       	-0.799	-0.757318258
4170	2000-01-02 01:09:30	1040	Oliver    	-0.916	-0.925866902
4171	2000-01-02 01:09:31	1038	Michael   	-0.870	0.296396196
4172	2000-01-02 01:09:32	1046	Charlie   	0.709	0.351168305
4173	2000-01-02 01:09:33	963	Frank     	0.153	0.363140762
4174	2000-01-02 01:09:34	998	Ingrid    	0.253	-0.248978928
4175	2000-01-02 01:09:35	1004	Bob       	0.638	0.0396876112
4176	2000-01-02 01:09:36	931	Patricia  	0.235	0.00192057062
4177	2000-01-02 01:09:37	941	Zelda     	0.648	-0.860183299
4178	2000-01-02 01:09:38	974	Xavier    	-0.323	-0.882067025
4179	2000-01-02 01:09:39	1022	Xavier    	0.965	-0.829763532
4180	2000-01-02 01:09:40	970	Laura     	-0.034	0.0286041088
4181	2000-01-02 01:09:41	1005	Dan       	-0.761	0.918169737
4182	2000-01-02 01:09:42	945	Ursula    	-0.772	0.624820888
4183	2000-01-02 01:09:43	968	Bob       	-0.147	0.362709016
4184	2000-01-02 01:09:44	1031	Patricia  	-0.829	0.747700751
4185	2000-01-02 01:09:45	996	Xavier    	0.791	-0.0679680556
4186	2000-01-02 01:09:46	984	Laura     	0.937	-0.526278555
4187	2000-01-02 01:09:47	953	Dan       	-0.699	0.780201435
4188	2000-01-02 01:09:48	1015	Wendy     	-0.945	0.05730021
4189	2000-01-02 01:09:49	963	Charlie   	-0.212	-0.445283651
4190	2000-01-02 01:09:50	991	Charlie   	-0.773	-0.465552241
4191	2000-01-02 01:09:51	992	Frank     	-0.178	-0.0566143505
4192	2000-01-02 01:09:52	1008	Victor    	0.634	0.90143168
4193	2000-01-02 01:09:53	976	Quinn     	-0.506	0.0837085247
4194	2000-01-02 01:09:54	1045	Wendy     	0.550	-0.081619665
4195	2000-01-02 01:09:55	1022	Frank     	-0.661	-0.608776212
4196	2000-01-02 01:09:56	982	Norbert   	0.196	-0.192349717
4197	2000-01-02 01:09:57	1030	Kevin     	-0.336	-0.887301981
4198	2000-01-02 01:09:58	977	Charlie   	-0.200	0.19486627
4199	2000-01-02 01:09:59	1004	Patricia  	-0.191	-0.0110528236
4200	2000-01-02 01:10:00	1046	Xavier    	0.672	-0.916575611
4201	2000-01-02 01:10:01	966	George    	-0.358	0.77353704
4202	2000-01-02 01:10:02	969	Tim       	0.543	-0.69932282
4203	2000-01-02 01:10:03	990	Wendy     	0.834	0.0438140482
4204	2000-01-02 01:10:04	981	Norbert   	0.450	0.817921698
4205	2000-01-02 01:10:05	979	Yvonne    	-0.687	-0.928051591
4206	2000-01-02 01:10:06	1035	Patricia  	-0.954	-0.356872201
4207	2000-01-02 01:10:07	989	Yvonne    	0.825	-0.716781139
4208	2000-01-02 01:10:08	1037	Bob       	-0.818	0.104164138
4209	2000-01-02 01:10:09	1009	Hannah    	0.251	-0.62416935
4210	2000-01-02 01:10:10	1024	Ray       	0.316	0.902314663
4211	2000-01-02 01:10:11	1028	Frank     	0.830	-0.404704094
4212	2000-01-02 01:10:12	1053	Yvonne    	-0.313	-0.163175479
4213	2000-01-02 01:10:13	939	Victor    	0.429	-0.615995288
4214	2000-01-02 01:10:14	1007	Tim       	-0.697	-0.672631264
4215	2000-01-02 01:10:15	1038	Edith     	-0.077	-0.328769088
4216	2000-01-02 01:10:16	1048	Xavier    	-0.553	-0.371844202
4217	2000-01-02 01:10:17	959	Xavier    	0.807	0.421352625
4218	2000-01-02 01:10:18	994	Ursula    	0.403	0.969072998
4219	2000-01-02 01:10:19	1010	George    	-0.367	-0.383666545
4220	2000-01-02 01:10:20	1022	Yvonne    	0.229	0.96681118
4221	2000-01-02 01:10:21	968	Oliver    	0.994	-0.0165176727
4222	2000-01-02 01:10:22	1014	Wendy     	0.058	-0.526695728
4223	2000-01-02 01:10:23	981	Michael   	-0.215	0.47052297
4224	2000-01-02 01:10:24	1023	Norbert   	0.998	-0.763176501
4225	2000-01-02 01:10:25	962	Ingrid    	0.706	0.0086733764
4226	2000-01-02 01:10:26	989	Laura     	0.571	0.868814945
4227	2000-01-02 01:10:27	978	Ursula    	0.131	-0.945127785
4228	2000-01-02 01:10:28	1002	Charlie   	-0.259	0.0363198146
4229	2000-01-02 01:10:29	1082	Yvonne    	0.112	0.989233255
4230	2000-01-02 01:10:30	991	Dan       	0.148	0.807717562
4231	2000-01-02 01:10:31	975	Edith     	0.882	0.502238572
4232	2000-01-02 01:10:32	1003	Wendy     	-0.009	-0.437576056
4233	2000-01-02 01:10:33	1057	George    	-0.949	-0.990596533
4234	2000-01-02 01:10:34	1046	Sarah     	-0.755	-0.412158847
4235	2000-01-02 01:10:35	992	Charlie   	-0.462	0.0679422095
4236	2000-01-02 01:10:36	1059	Hannah    	-0.746	-0.934066057
4237	2000-01-02 01:10:37	948	Norbert   	-0.887	-0.855798006
4238	2000-01-02 01:10:38	995	Yvonne    	-0.011	-0.952341497
4239	2000-01-02 01:10:39	937	Ursula    	-0.785	0.670269608
4240	2000-01-02 01:10:40	993	Zelda     	0.064	0.550916553
4241	2000-01-02 01:10:41	975	Sarah     	-0.034	0.492545187
4242	2000-01-02 01:10:42	933	Xavier    	0.967	-0.088580288
4243	2000-01-02 01:10:43	1012	Jerry     	-0.336	0.14075163
4244	2000-01-02 01:10:44	971	Zelda     	-0.737	0.297739208
4245	2000-01-02 01:10:45	950	Laura     	-0.810	-0.190501913
4246	2000-01-02 01:10:46	1009	Oliver    	0.772	0.738512754
4247	2000-01-02 01:10:47	1037	Oliver    	0.517	0.355532676
4248	2000-01-02 01:10:48	1066	Alice     	0.399	0.49275738
4249	2000-01-02 01:10:49	990	Ingrid    	-0.387	-0.103526592
4250	2000-01-02 01:10:50	966	Kevin     	-0.455	0.197238594
4251	2000-01-02 01:10:51	1039	Ingrid    	-0.745	0.97239244
4252	2000-01-02 01:10:52	975	Ursula    	0.998	0.3966811
4253	2000-01-02 01:10:53	963	Hannah    	-0.610	-0.00338539132
4254	2000-01-02 01:10:54	993	Ray       	0.752	-0.6130234
4255	2000-01-02 01:10:55	1034	Oliver    	-0.188	0.721982181
4256	2000-01-02 01:10:56	991	Tim       	-0.180	0.230949014
4257	2000-01-02 01:10:57	986	Tim       	-0.552	-0.397022992
4258	2000-01-02 01:10:58	1001	Bob       	-0.387	-0.422876894
4259	2000-01-02 01:10:59	1009	Xavier    	-0.621	-0.554734051
4260	2000-01-02 01:11:00	997	Bob       	-0.474	-0.629060507
4261	2000-01-02 01:11:01	996	Bob       	-0.581	-0.613229752
4262	2000-01-02 01:11:02	1001	Frank     	0.195	0.32240802
4263	2000-01-02 01:11:03	991	Xavier    	0.736	-0.849103928
4264	2000-01-02 01:11:04	1022	Quinn     	0.851	-0.100861453
4265	2000-01-02 01:11:05	1014	Quinn     	-0.285	-0.0155130066
4266	2000-01-02 01:11:06	939	George    	-0.050	0.393639684
4267	2000-01-02 01:11:07	969	Zelda     	-0.204	0.52780962
4268	2000-01-02 01:11:08	1022	Alice     	-0.226	-0.134364247
4269	2000-01-02 01:11:09	1015	Bob       	0.224	-0.202195182
4270	2000-01-02 01:11:10	1015	Zelda     	0.140	-0.842751682
4271	2000-01-02 01:11:11	1026	Bob       	-0.498	0.0594574846
4272	2000-01-02 01:11:12	966	Kevin     	0.667	-0.111042224
4273	2000-01-02 01:11:13	1013	Laura     	-0.744	0.668989062
4274	2000-01-02 01:11:14	955	Ray       	-0.260	0.563991845
4275	2000-01-02 01:11:15	996	Xavier    	-0.188	-0.732067585
4276	2000-01-02 01:11:16	1015	Yvonne    	-0.629	-0.608415544
4277	2000-01-02 01:11:17	997	Tim       	0.866	0.297912598
4278	2000-01-02 01:11:18	1019	Charlie   	0.251	0.812709093
4279	2000-01-02 01:11:19	1016	Patricia  	-0.872	0.711806357
4280	2000-01-02 01:11:20	980	Ursula    	-0.227	-0.711561203
4281	2000-01-02 01:11:21	987	Ray       	-0.503	0.0880661011
4282	2000-01-02 01:11:22	992	Sarah     	-0.498	-0.36503613
4283	2000-01-02 01:11:23	1008	Ray       	0.750	0.653581381
4284	2000-01-02 01:11:24	995	Quinn     	0.658	0.559470534
4285	2000-01-02 01:11:25	1050	Norbert   	-0.745	-0.47282365
4286	2000-01-02 01:11:26	993	Ingrid    	-0.917	0.632643759
4287	2000-01-02 01:11:27	1034	Edith     	-0.559	-0.767252982
4288	2000-01-02 01:11:28	940	Ursula    	-0.336	-0.160980061
4289	2000-01-02 01:11:29	997	Charlie   	-0.494	-0.221077949
4290	2000-01-02 01:11:30	1008	Quinn     	-0.738	-0.222689644
4291	2000-01-02 01:11:31	966	Norbert   	0.990	-0.669545591
4292	2000-01-02 01:11:32	1017	Bob       	-0.988	0.189320266
4293	2000-01-02 01:11:33	1051	Xavier    	-0.321	-0.275921166
4294	2000-01-02 01:11:34	1022	Alice     	-0.993	0.598621547
4295	2000-01-02 01:11:35	1036	Tim       	-0.215	-0.699937761
4296	2000-01-02 01:11:36	985	Michael   	0.170	0.438661456
4297	2000-01-02 01:11:37	969	Tim       	0.809	-0.241811901
4298	2000-01-02 01:11:38	966	Tim       	-0.373	0.785298884
4299	2000-01-02 01:11:39	1025	Ursula    	0.731	0.994626462
4300	2000-01-02 01:11:40	1036	Xavier    	0.747	-0.827265859
4301	2000-01-02 01:11:41	1010	Alice     	-0.820	-0.160057396
4302	2000-01-02 01:11:42	954	Patricia  	-0.147	0.855006516
4303	2000-01-02 01:11:43	974	Wendy     	-0.099	0.0056127524
4304	2000-01-02 01:11:44	993	Norbert   	-0.796	0.39049691
4305	2000-01-02 01:11:45	1011	Oliver    	-0.594	-0.428059995
4306	2000-01-02 01:11:46	1001	Alice     	-0.328	-0.130865797
4307	2000-01-02 01:11:47	1026	Michael   	0.864	-0.522051573
4308	2000-01-02 01:11:48	1022	George    	-0.501	-0.980037034
4309	2000-01-02 01:11:49	1014	Michael   	1.000	-0.6258955
4310	2000-01-02 01:11:50	1031	Ursula    	0.120	0.623474896
4311	2000-01-02 01:11:51	1083	Oliver    	0.429	-0.664972544
4312	2000-01-02 01:11:52	989	Bob       	0.171	-0.233062878
4313	2000-01-02 01:11:53	947	Frank     	0.002	0.219009981
4314	2000-01-02 01:11:54	982	Hannah    	0.641	0.510644972
4315	2000-01-02 01:11:55	1023	Victor    	-0.186	0.982180417
4316	2000-01-02 01:11:56	1038	Kevin     	-0.394	0.0752512738
4317	2000-01-02 01:11:57	1015	Ursula    	0.445	-0.106876746
4318	2000-01-02 01:11:58	1027	Alice     	-0.747	-0.685976326
4319	2000-01-02 01:11:59	1012	Charlie   	-0.694	0.960835516
4320	2000-01-02 01:12:00	1001	Ingrid    	-0.641	-0.53008157
4321	2000-01-02 01:12:01	1034	Michael   	-0.889	0.315556467
4322	2000-01-02 01:12:02	998	Michael   	-0.229	0.56143713
4323	2000-01-02 01:12:03	1001	Quinn     	-0.614	0.689298749
4324	2000-01-02 01:12:04	1023	Edith     	0.209	0.450372547
4325	2000-01-02 01:12:05	982	Kevin     	0.182	-0.518037975
4326	2000-01-02 01:12:06	997	Wendy     	-0.947	0.591839492
4327	2000-01-02 01:12:07	987	Yvonne    	-0.450	-0.83726728
4328	2000-01-02 01:12:08	966	Victor    	0.016	-0.208451733
4329	2000-01-02 01:12:09	1020	Alice     	0.937	0.316883415
4330	2000-01-02 01:12:10	981	Quinn     	0.606	0.92714864
4331	2000-01-02 01:12:11	981	Ursula    	-0.628	0.1200279
4332	2000-01-02 01:12:12	982	Sarah     	0.934	0.142467201
4333	2000-01-02 01:12:13	982	Alice     	0.022	-0.161495104
4334	2000-01-02 01:12:14	997	Dan       	0.401	0.392386049
4335	2000-01-02 01:12:15	1046	Bob       	0.369	-0.878494084
4336	2000-01-02 01:12:16	1026	Wendy     	0.676	-0.454150259
4337	2000-01-02 01:12:17	1040	Charlie   	-0.741	-0.815857708
4338	2000-01-02 01:12:18	1036	Bob       	0.532	0.647203326
4339	2000-01-02 01:12:19	1002	Frank     	-0.823	0.181031704
4340	2000-01-02 01:12:20	1002	Patricia  	-0.194	-0.216918245
4341	2000-01-02 01:12:21	1026	Bob       	-0.311	0.755408466
4342	2000-01-02 01:12:22	1006	Kevin     	-0.579	0.862688661
4343	2000-01-02 01:12:23	956	Zelda     	0.846	-0.928734481
4344	2000-01-02 01:12:24	1014	Sarah     	0.346	-0.208518192
4345	2000-01-02 01:12:25	992	Patricia  	-0.037	-0.405244291
4346	2000-01-02 01:12:26	949	Charlie   	0.618	-0.909021437
4347	2000-01-02 01:12:27	995	Edith     	0.634	-0.977234602
4348	2000-01-02 01:12:28	1007	Michael   	-0.851	0.0828912035
4349	2000-01-02 01:12:29	1007	Laura     	-0.847	0.452477455
4350	2000-01-02 01:12:30	978	Ray       	-0.973	0.752723157
4351	2000-01-02 01:12:31	989	George    	-0.227	-0.0701330677
4352	2000-01-02 01:12:32	1006	Ursula    	0.419	-0.395447433
4353	2000-01-02 01:12:33	1004	Yvonne    	0.976	-0.0226789527
4354	2000-01-02 01:12:34	1027	George    	-0.255	-0.532775342
4355	2000-01-02 01:12:35	1031	Kevin     	-0.350	0.576598406
4356	2000-01-02 01:12:36	986	Bob       	-0.697	-0.815751731
4357	2000-01-02 01:12:37	923	Charlie   	0.183	0.779885769
4358	2000-01-02 01:12:38	985	Yvonne    	-0.388	-0.406473577
4359	2000-01-02 01:12:39	954	Yvonne    	0.205	0.281203061
4360	2000-01-02 01:12:40	1021	Bob       	-0.372	0.122106016
4361	2000-01-02 01:12:41	1027	Zelda     	-0.657	-0.213761479
4362	2000-01-02 01:12:42	910	Ursula    	-0.335	0.927473247
4363	2000-01-02 01:12:43	1021	Ursula    	0.474	-0.831458688
4364	2000-01-02 01:12:44	1038	Jerry     	0.643	0.216593936
4365	2000-01-02 01:12:45	976	Charlie   	-0.416	0.911736965
4366	2000-01-02 01:12:46	983	Laura     	-0.718	0.773182631
4367	2000-01-02 01:12:47	987	George    	0.986	-0.874483049
4368	2000-01-02 01:12:48	1014	Kevin     	-0.705	-0.388405442
4369	2000-01-02 01:12:49	1003	Alice     	0.539	0.235048279
4370	2000-01-02 01:12:50	916	Kevin     	-0.225	-0.722768128
4371	2000-01-02 01:12:51	964	Hannah    	0.378	0.579505503
4372	2000-01-02 01:12:52	1004	Oliver    	-0.732	-0.932014883
4373	2000-01-02 01:12:53	1016	Laura     	-0.811	0.0296109803
4374	2000-01-02 01:12:54	991	Victor    	0.224	-0.821023822
4375	2000-01-02 01:12:55	1004	Charlie   	-0.296	-0.673734784
4376	2000-01-02 01:12:56	941	Jerry     	0.705	-0.644298792
4377	2000-01-02 01:12:57	1012	Michael   	0.567	0.167187929
4378	2000-01-02 01:12:58	934	Hannah    	0.612	-0.684103251
4379	2000-01-02 01:12:59	1018	Wendy     	0.879	-0.832912862
4380	2000-01-02 01:13:00	1032	Ray       	0.079	0.631991565
4381	2000-01-02 01:13:01	997	Xavier    	-0.113	-0.129486784
4382	2000-01-02 01:13:02	979	Victor    	0.414	0.378303915
4383	2000-01-02 01:13:03	1031	Bob       	0.167	-0.987634361
4384	2000-01-02 01:13:04	1030	Dan       	0.288	0.669905126
4385	2000-01-02 01:13:05	986	Frank     	0.765	-0.421283007
4386	2000-01-02 01:13:06	995	Sarah     	-0.312	0.17693761
4387	2000-01-02 01:13:07	1104	Ingrid    	-0.673	0.494928271
4388	2000-01-02 01:13:08	1004	Edith     	0.796	-0.0782817379
4389	2000-01-02 01:13:09	990	Wendy     	-0.916	-0.495790362
4390	2000-01-02 01:13:10	1062	Zelda     	-0.441	-0.815323055
4391	2000-01-02 01:13:11	1055	Sarah     	-0.488	-0.829897404
4392	2000-01-02 01:13:12	1063	Patricia  	-0.685	0.522776902
4393	2000-01-02 01:13:13	996	George    	0.992	0.482545346
4394	2000-01-02 01:13:14	991	Oliver    	0.836	-0.0469825491
4395	2000-01-02 01:13:15	1032	Wendy     	0.725	0.0399849825
4396	2000-01-02 01:13:16	998	Bob       	-0.060	0.304493904
4397	2000-01-02 01:13:17	1006	Frank     	0.203	-0.0221765433
4398	2000-01-02 01:13:18	1057	Dan       	0.639	0.659551144
4399	2000-01-02 01:13:19	963	Alice     	-0.426	0.784474671
4400	2000-01-02 01:13:20	971	Xavier    	0.380	0.258882225
4401	2000-01-02 01:13:21	1003	George    	0.440	0.898170352
4402	2000-01-02 01:13:22	976	Bob       	0.850	0.179994628
4403	2000-01-02 01:13:23	973	Hannah    	-0.939	0.130216181
4404	2000-01-02 01:13:24	983	Frank     	-0.950	-0.112453252
4405	2000-01-02 01:13:25	1003	Zelda     	0.859	-0.490223199
4406	2000-01-02 01:13:26	943	Oliver    	0.536	-0.0786418989
4407	2000-01-02 01:13:27	995	Kevin     	0.064	-0.142554507
4408	2000-01-02 01:13:28	962	Victor    	0.852	-0.605058491
4409	2000-01-02 01:13:29	1020	Yvonne    	-0.478	-0.501863599
4410	2000-01-02 01:13:30	931	Laura     	0.167	0.883585274
4411	2000-01-02 01:13:31	997	Quinn     	0.885	-0.895821333
4412	2000-01-02 01:13:32	1059	Oliver    	-0.375	0.980780661
4413	2000-01-02 01:13:33	1028	Xavier    	0.510	-0.470711678
4414	2000-01-02 01:13:34	1014	Jerry     	0.057	0.345394731
4415	2000-01-02 01:13:35	974	Ursula    	0.836	-0.835485876
4416	2000-01-02 01:13:36	1028	Xavier    	0.633	0.611653447
4417	2000-01-02 01:13:37	958	Jerry     	0.179	0.385982573
4418	2000-01-02 01:13:38	1026	Hannah    	0.740	-0.0113557782
4419	2000-01-02 01:13:39	947	Zelda     	-0.787	0.323693156
4420	2000-01-02 01:13:40	1011	Yvonne    	0.352	0.628357708
4421	2000-01-02 01:13:41	1031	Edith     	-0.837	0.577306807
4422	2000-01-02 01:13:42	965	Dan       	0.159	-0.562227547
4423	2000-01-02 01:13:43	1032	Tim       	-0.633	-0.27443403
4424	2000-01-02 01:13:44	995	Kevin     	0.845	0.946166575
4425	2000-01-02 01:13:45	1010	Oliver    	0.620	0.658544779
4426	2000-01-02 01:13:46	1045	Edith     	-0.039	-0.700414538
4427	2000-01-02 01:13:47	998	Jerry     	-0.975	-0.203823268
4428	2000-01-02 01:13:48	1036	Dan       	-0.689	0.972450018
4429	2000-01-02 01:13:49	956	Charlie   	-0.662	0.40176627
4430	2000-01-02 01:13:50	990	Jerry     	0.157	0.598211527
4431	2000-01-02 01:13:51	1023	Tim       	-0.512	-0.825753033
4432	2000-01-02 01:13:52	1026	Tim       	-0.480	-0.371768832
4433	2000-01-02 01:13:53	1029	Wendy     	0.808	-0.806941628
4434	2000-01-02 01:13:54	956	Michael   	0.261	0.865850806
4435	2000-01-02 01:13:55	985	Frank     	0.017	0.41225186
4436	2000-01-02 01:13:56	1013	Ray       	-0.809	0.0905311108
4437	2000-01-02 01:13:57	1024	Oliver    	-0.803	-0.189847007
4438	2000-01-02 01:13:58	1040	Yvonne    	0.523	-0.0873125046
4439	2000-01-02 01:13:59	1003	Victor    	0.561	0.994170308
4440	2000-01-02 01:14:00	1063	Edith     	0.931	0.907464981
4441	2000-01-02 01:14:01	963	Edith     	0.105	0.576538086
4442	2000-01-02 01:14:02	1012	Alice     	0.560	0.479281902
4443	2000-01-02 01:14:03	1016	Norbert   	-0.683	0.692638278
4444	2000-01-02 01:14:04	1010	Ingrid    	0.346	-0.545417547
4445	2000-01-02 01:14:05	996	Michael   	-0.945	-0.0260336623
4446	2000-01-02 01:14:06	1042	Dan       	0.939	0.11139559
4447	2000-01-02 01:14:07	972	Ursula    	-0.317	0.538521945
4448	2000-01-02 01:14:08	1003	Jerry     	0.451	0.207437783
4449	2000-01-02 01:14:09	1094	Edith     	-0.571	-0.13012509
4450	2000-01-02 01:14:10	1022	Michael   	0.895	-0.18988882
4451	2000-01-02 01:14:11	1018	Sarah     	0.661	-0.362945378
4452	2000-01-02 01:14:12	1053	Kevin     	-0.999	-0.916540802
4453	2000-01-02 01:14:13	951	Tim       	-0.814	-0.994586229
4454	2000-01-02 01:14:14	968	Ursula    	0.778	-0.489110857
4455	2000-01-02 01:14:15	968	Charlie   	0.792	0.378321439
4456	2000-01-02 01:14:16	952	Laura     	-0.237	-0.696532965
4457	2000-01-02 01:14:17	1012	Dan       	0.013	0.338468194
4458	2000-01-02 01:14:18	963	Jerry     	-0.581	0.0686094612
4459	2000-01-02 01:14:19	996	Hannah    	0.824	-0.507915676
4460	2000-01-02 01:14:20	960	Edith     	0.051	0.57545799
4461	2000-01-02 01:14:21	1032	Tim       	-0.927	0.694312692
4462	2000-01-02 01:14:22	994	Patricia  	0.247	-0.953680038
4463	2000-01-02 01:14:23	1014	Jerry     	-0.912	-0.0860793889
4464	2000-01-02 01:14:24	938	Oliver    	0.077	0.551243901
4465	2000-01-02 01:14:25	979	Sarah     	0.704	0.791359007
4466	2000-01-02 01:14:26	1040	Edith     	-0.914	0.444464445
4467	2000-01-02 01:14:27	996	Quinn     	0.870	-0.913324594
4468	2000-01-02 01:14:28	1038	Quinn     	0.853	-0.437954485
4469	2000-01-02 01:14:29	992	Charlie   	-0.809	0.181904569
4470	2000-01-02 01:14:30	986	Quinn     	0.903	0.199090168
4471	2000-01-02 01:14:31	1043	Ursula    	0.348	0.783080995
4472	2000-01-02 01:14:32	928	Norbert   	0.083	-0.047147911
4473	2000-01-02 01:14:33	1007	Oliver    	0.212	-0.539496839
4474	2000-01-02 01:14:34	1053	Hannah    	0.210	0.768558145
4475	2000-01-02 01:14:35	993	Edith     	0.323	-0.28602156
4476	2000-01-02 01:14:36	1010	Alice     	0.148	0.950496852
4477	2000-01-02 01:14:37	1019	Patricia  	0.053	-0.911075652
4478	2000-01-02 01:14:38	1031	Edith     	-0.984	0.598152816
4479	2000-01-02 01:14:39	1007	Quinn     	0.515	0.687858462
4480	2000-01-02 01:14:40	1062	Patricia  	-0.417	-0.0619995557
4481	2000-01-02 01:14:41	987	Frank     	-0.567	0.523231387
4482	2000-01-02 01:14:42	1034	Alice     	-0.927	0.220314488
4483	2000-01-02 01:14:43	998	Sarah     	-0.560	-0.329696745
4484	2000-01-02 01:14:44	1033	Ray       	-0.367	-0.804509521
4485	2000-01-02 01:14:45	1069	Zelda     	-0.108	-0.668990552
4486	2000-01-02 01:14:46	995	George    	-0.727	0.166924849
4487	2000-01-02 01:14:47	1076	Ray       	0.090	-0.443869263
4488	2000-01-02 01:14:48	1000	Tim       	-0.135	-0.427783877
4489	2000-01-02 01:14:49	975	Hannah    	0.963	0.798267245
4490	2000-01-02 01:14:50	971	Laura     	0.553	-0.401533455
4491	2000-01-02 01:14:51	1034	Ingrid    	-0.320	0.207998797
4492	2000-01-02 01:14:52	970	Oliver    	0.206	0.52036643
4493	2000-01-02 01:14:53	1004	Tim       	-0.536	-0.879668951
4494	2000-01-02 01:14:54	972	George    	-0.069	-0.431540519
4495	2000-01-02 01:14:55	988	Yvonne    	-0.085	-0.573723018
4496	2000-01-02 01:14:56	974	Hannah    	0.828	0.35751307
4497	2000-01-02 01:14:57	1019	Charlie   	0.067	0.908076286
4498	2000-01-02 01:14:58	1023	Victor    	0.865	-0.54293108
4499	2000-01-02 01:14:59	1010	Laura     	0.274	0.125968382
4500	2000-01-02 01:15:00	1053	Ray       	0.422	-0.648129046
4501	2000-01-02 01:15:01	1014	Quinn     	0.603	-0.87700814
4502	2000-01-02 01:15:02	999	Quinn     	-0.302	-0.535657704
4503	2000-01-02 01:15:03	981	Yvonne    	0.192	-0.872988701
4504	2000-01-02 01:15:04	1019	Michael   	0.272	0.386361688
4505	2000-01-02 01:15:05	976	Zelda     	-0.723	0.528827608
4506	2000-01-02 01:15:06	1048	Oliver    	0.791	-0.706539512
4507	2000-01-02 01:15:07	1016	Victor    	-0.104	-0.905344129
4508	2000-01-02 01:15:08	984	Zelda     	-0.907	0.961415648
4509	2000-01-02 01:15:09	987	Edith     	-0.477	0.598026395
4510	2000-01-02 01:15:10	956	Norbert   	0.786	-0.920167923
4511	2000-01-02 01:15:11	1000	Yvonne    	-0.324	-0.943712175
4512	2000-01-02 01:15:12	1003	Xavier    	0.790	-0.324440807
4513	2000-01-02 01:15:13	998	Charlie   	0.504	-0.0519359596
4514	2000-01-02 01:15:14	948	George    	-0.111	-0.300418317
4515	2000-01-02 01:15:15	1017	Bob       	-0.861	-0.623743236
4516	2000-01-02 01:15:16	1017	Oliver    	-0.330	0.878294289
4517	2000-01-02 01:15:17	1013	Ingrid    	0.359	0.668914437
4518	2000-01-02 01:15:18	1063	Dan       	-0.606	0.141066223
4519	2000-01-02 01:15:19	1000	Norbert   	0.497	0.324583769
4520	2000-01-02 01:15:20	982	Ray       	-0.418	-0.0461016409
4521	2000-01-02 01:15:21	1036	Oliver    	0.141	-0.0891246349
4522	2000-01-02 01:15:22	983	Frank     	-0.651	0.0753449872
4523	2000-01-02 01:15:23	1015	Ingrid    	-0.840	0.898364902
4524	2000-01-02 01:15:24	1005	Michael   	0.655	0.201880589
4525	2000-01-02 01:15:25	1045	Yvonne    	-0.153	-0.0941952541
4526	2000-01-02 01:15:26	1048	Dan       	0.137	0.703979254
4527	2000-01-02 01:15:27	1006	Bob       	0.223	-0.632277489
4528	2000-01-02 01:15:28	1018	Wendy     	-0.991	0.753328323
4529	2000-01-02 01:15:29	967	Laura     	0.525	-0.146263599
4530	2000-01-02 01:15:30	986	Victor    	0.312	-0.594917893
4531	2000-01-02 01:15:31	1014	Oliver    	-0.230	0.94493562
4532	2000-01-02 01:15:32	1021	Tim       	0.115	-0.327777326
4533	2000-01-02 01:15:33	1004	Quinn     	-0.905	-0.0362607166
4534	2000-01-02 01:15:34	1003	Edith     	0.676	0.205266178
4535	2000-01-02 01:15:35	977	Michael   	-0.869	-0.0424026996
4536	2000-01-02 01:15:36	1012	Zelda     	0.807	-0.947215915
4537	2000-01-02 01:15:37	965	Alice     	-0.360	-0.65047586
4538	2000-01-02 01:15:38	1037	Norbert   	0.166	0.844699621
4539	2000-01-02 01:15:39	1001	Xavier    	-0.700	-0.605005801
4540	2000-01-02 01:15:40	965	Quinn     	-0.775	-0.452134639
4541	2000-01-02 01:15:41	949	Wendy     	-0.646	-0.142809317
4542	2000-01-02 01:15:42	1038	Jerry     	-0.060	0.44208914
4543	2000-01-02 01:15:43	968	Alice     	-0.195	-0.330406904
4544	2000-01-02 01:15:44	996	Yvonne    	0.386	0.210317954
4545	2000-01-02 01:15:45	1003	Kevin     	0.238	-0.799216032
4546	2000-01-02 01:15:46	1002	Michael   	0.783	0.359224081
4547	2000-01-02 01:15:47	1021	Patricia  	-0.399	0.166507676
4548	2000-01-02 01:15:48	975	Norbert   	-0.537	0.504603088
4549	2000-01-02 01:15:49	976	Xavier    	-0.662	-0.763483465
4550	2000-01-02 01:15:50	1023	Laura     	0.585	-0.952238321
4551	2000-01-02 01:15:51	1024	Ursula    	-0.614	-0.543971062
4552	2000-01-02 01:15:52	979	Jerry     	0.102	0.0501528122
4553	2000-01-02 01:15:53	1070	Yvonne    	-0.411	-0.0997622833
4554	2000-01-02 01:15:54	982	Ingrid    	-0.538	-0.13679257
4555	2000-01-02 01:15:55	997	Quinn     	-0.439	-0.519454539
4556	2000-01-02 01:15:56	1048	Alice     	0.469	0.34979707
4557	2000-01-02 01:15:57	1013	Ursula    	-0.962	0.699787796
4558	2000-01-02 01:15:58	1008	Ray       	-0.343	0.28729257
4559	2000-01-02 01:15:59	994	Bob       	0.916	-0.312881738
4560	2000-01-02 01:16:00	977	Zelda     	0.674	-0.255615294
4561	2000-01-02 01:16:01	978	Zelda     	0.389	-0.75167501
4562	2000-01-02 01:16:02	1020	Dan       	-0.553	-0.127730206
4563	2000-01-02 01:16:03	943	Yvonne    	0.886	-0.35977447
4564	2000-01-02 01:16:04	1010	Frank     	0.033	0.326876968
4565	2000-01-02 01:16:05	953	Wendy     	-0.855	-0.346485764
4566	2000-01-02 01:16:06	972	Ingrid    	-0.064	0.223737299
4567	2000-01-02 01:16:07	958	Dan       	-0.767	-0.359755516
4568	2000-01-02 01:16:08	944	Bob       	0.049	-0.119022295
4569	2000-01-02 01:16:09	965	Victor    	-0.632	0.225503877
4570	2000-01-02 01:16:10	1028	Kevin     	0.241	0.470354497
4571	2000-01-02 01:16:11	976	Quinn     	-0.851	0.0624681823
4572	2000-01-02 01:16:12	997	Ray       	0.896	0.512460351
4573	2000-01-02 01:16:13	965	Zelda     	0.887	0.313870639
4574	2000-01-02 01:16:14	1021	Frank     	-0.157	0.200944215
4575	2000-01-02 01:16:15	962	Laura     	0.550	0.0817064345
4576	2000-01-02 01:16:16	1014	Ray       	0.425	0.00765955215
4577	2000-01-02 01:16:17	1028	Michael   	0.019	-0.0238179769
4578	2000-01-02 01:16:18	1041	Xavier    	0.838	0.115667097
4579	2000-01-02 01:16:19	983	Hannah    	0.228	0.403025955
4580	2000-01-02 01:16:20	942	Yvonne    	0.031	0.849273264
4581	2000-01-02 01:16:21	1025	Zelda     	0.159	0.644904077
4582	2000-01-02 01:16:22	999	Patricia  	-0.727	0.552547395
4583	2000-01-02 01:16:23	1008	Ray       	-0.479	0.673904479
4584	2000-01-02 01:16:24	1027	Jerry     	-0.665	0.343384385
4585	2000-01-02 01:16:25	1052	Xavier    	0.587	0.740450323
4586	2000-01-02 01:16:26	932	Charlie   	0.052	0.307388067
4587	2000-01-02 01:16:27	1039	Ursula    	0.548	-0.743210077
4588	2000-01-02 01:16:28	1062	Sarah     	0.888	-0.381438464
4589	2000-01-02 01:16:29	1021	Laura     	0.309	-0.7943151
4590	2000-01-02 01:16:30	1103	Michael   	0.892	0.0963812172
4591	2000-01-02 01:16:31	989	Zelda     	0.649	-0.799668252
4592	2000-01-02 01:16:32	1009	Edith     	-0.061	-0.382468581
4593	2000-01-02 01:16:33	984	Wendy     	0.716	-0.331845731
4594	2000-01-02 01:16:34	993	Charlie   	-0.754	-0.360073864
4595	2000-01-02 01:16:35	1051	Hannah    	0.607	-0.786831439
4596	2000-01-02 01:16:36	989	Alice     	0.762	0.0577104166
4597	2000-01-02 01:16:37	989	Michael   	-0.241	-0.931121469
4598	2000-01-02 01:16:38	976	Zelda     	-0.184	0.945885479
4599	2000-01-02 01:16:39	1018	Jerry     	-0.807	-0.0594753735
4600	2000-01-02 01:16:40	984	Norbert   	-0.382	0.13457346
4601	2000-01-02 01:16:41	978	Dan       	-0.003	0.216630206
4602	2000-01-02 01:16:42	1012	Frank     	-0.208	-0.133829549
4603	2000-01-02 01:16:43	998	Laura     	0.346	0.588255823
4604	2000-01-02 01:16:44	995	Xavier    	-0.895	0.163398296
4605	2000-01-02 01:16:45	1018	Patricia  	-0.407	0.720612526
4606	2000-01-02 01:16:46	1034	Norbert   	0.310	0.499794006
4607	2000-01-02 01:16:47	1017	Alice     	-0.471	0.902831197
4608	2000-01-02 01:16:48	969	Sarah     	0.070	-0.759290874
4609	2000-01-02 01:16:49	970	Charlie   	0.355	0.91074717
4610	2000-01-02 01:16:50	1017	Patricia  	-0.521	-0.865359664
4611	2000-01-02 01:16:51	989	Wendy     	-0.459	-0.366188943
4612	2000-01-02 01:16:52	1010	Hannah    	-0.451	-0.905737221
4613	2000-01-02 01:16:53	1014	Victor    	0.958	0.271554261
4614	2000-01-02 01:16:54	1005	Ingrid    	0.142	0.920226038
4615	2000-01-02 01:16:55	973	Wendy     	-0.289	0.246453166
4616	2000-01-02 01:16:56	945	Oliver    	-0.001	-0.0521939397
4617	2000-01-02 01:16:57	971	Laura     	0.649	0.0391743146
4618	2000-01-02 01:16:58	984	Michael   	-0.897	-0.0576812364
4619	2000-01-02 01:16:59	998	Jerry     	0.157	-0.18798922
4620	2000-01-02 01:17:00	1036	Oliver    	0.679	-0.633083284
4621	2000-01-02 01:17:01	974	Kevin     	0.474	0.648761451
4622	2000-01-02 01:17:02	1019	Alice     	0.803	0.438096255
4623	2000-01-02 01:17:03	1007	Ingrid    	0.694	-0.961916685
4624	2000-01-02 01:17:04	1018	Xavier    	-0.507	-0.274807215
4625	2000-01-02 01:17:05	986	Bob       	-0.470	-0.892750263
4626	2000-01-02 01:17:06	1020	Frank     	-0.085	0.853138983
4627	2000-01-02 01:17:07	1098	Bob       	0.001	-0.684433997
4628	2000-01-02 01:17:08	980	Sarah     	-0.247	0.207285985
4629	2000-01-02 01:17:09	1060	Patricia  	-0.916	0.783573329
4630	2000-01-02 01:17:10	1059	Yvonne    	-0.856	-0.996433496
4631	2000-01-02 01:17:11	966	Zelda     	0.362	-0.941935956
4632	2000-01-02 01:17:12	1075	Xavier    	0.119	-0.893013299
4633	2000-01-02 01:17:13	985	Laura     	0.192	0.784286737
4634	2000-01-02 01:17:14	983	Patricia  	0.476	-0.870944679
4635	2000-01-02 01:17:15	1030	Tim       	-0.143	0.0768912882
4636	2000-01-02 01:17:16	995	Bob       	-0.908	0.147786245
4637	2000-01-02 01:17:17	1023	Jerry     	-0.407	0.972490132
4638	2000-01-02 01:17:18	1005	Jerry     	-0.003	0.198477253
4639	2000-01-02 01:17:19	992	Laura     	-0.651	0.868696451
4640	2000-01-02 01:17:20	1069	Edith     	-0.919	0.222788304
4641	2000-01-02 01:17:21	960	Victor    	-0.369	0.490494281
4642	2000-01-02 01:17:22	1024	Ray       	0.318	-0.32003811
4643	2000-01-02 01:17:23	1008	Sarah     	0.686	0.417802572
4644	2000-01-02 01:17:24	1011	Michael   	-0.002	0.398940712
4645	2000-01-02 01:17:25	969	Hannah    	0.628	0.389737606
4646	2000-01-02 01:17:26	960	Oliver    	0.804	-0.943481326
4647	2000-01-02 01:17:27	1014	Edith     	-0.170	0.740741551
4648	2000-01-02 01:17:28	1016	Sarah     	-0.010	-0.380878299
4649	2000-01-02 01:17:29	1005	Xavier    	0.764	0.544297159
4650	2000-01-02 01:17:30	989	Tim       	-0.838	0.842962146
4651	2000-01-02 01:17:31	1000	Zelda     	-0.545	0.768731475
4652	2000-01-02 01:17:32	1005	Patricia  	0.526	-0.69677645
4653	2000-01-02 01:17:33	1012	Ursula    	-0.119	-0.0491603352
4654	2000-01-02 01:17:34	976	Zelda     	-0.207	-0.682081878
4655	2000-01-02 01:17:35	1017	Jerry     	-0.809	0.78354305
4656	2000-01-02 01:17:36	1006	Xavier    	0.646	-0.755880296
4657	2000-01-02 01:17:37	999	Edith     	-0.217	-0.135039866
4658	2000-01-02 01:17:38	972	Jerry     	-0.972	0.498630375
4659	2000-01-02 01:17:39	1011	George    	-0.243	-0.509028077
4660	2000-01-02 01:17:40	949	Sarah     	-0.380	-0.691946805
4661	2000-01-02 01:17:41	1002	Hannah    	0.156	0.0265648346
4662	2000-01-02 01:17:42	1042	Tim       	0.372	-0.470066875
4663	2000-01-02 01:17:43	1021	Kevin     	0.105	0.901771486
4664	2000-01-02 01:17:44	962	Alice     	0.910	0.327536017
4665	2000-01-02 01:17:45	1061	Jerry     	-0.239	0.0328296274
4666	2000-01-02 01:17:46	1032	Xavier    	0.810	-0.166347682
4667	2000-01-02 01:17:47	997	Ingrid    	0.933	0.637437999
4668	2000-01-02 01:17:48	1050	Michael   	-0.977	0.139714465
4669	2000-01-02 01:17:49	1011	Xavier    	-0.357	-0.300643712
4670	2000-01-02 01:17:50	996	Norbert   	-0.867	-0.657785773
4671	2000-01-02 01:17:51	954	Wendy     	0.469	0.732340813
4672	2000-01-02 01:17:52	953	Patricia  	0.842	0.709959507
4673	2000-01-02 01:17:53	981	Yvonne    	0.409	0.493395239
4674	2000-01-02 01:17:54	992	Victor    	0.493	0.810040891
4675	2000-01-02 01:17:55	1024	Jerry     	-0.712	-0.777119219
4676	2000-01-02 01:17:56	990	Wendy     	-0.931	-0.459515572
4677	2000-01-02 01:17:57	999	Kevin     	0.027	-0.559846938
4678	2000-01-02 01:17:58	1015	Dan       	0.781	0.657509446
4679	2000-01-02 01:17:59	967	Sarah     	0.092	0.71733588
4680	2000-01-02 01:18:00	1021	Bob       	0.910	-0.267831624
4681	2000-01-02 01:18:01	1026	Frank     	0.763	0.747773886
4682	2000-01-02 01:18:02	928	Edith     	0.487	0.839275301
4683	2000-01-02 01:18:03	945	Xavier    	-0.126	-0.493069977
4684	2000-01-02 01:18:04	1049	Alice     	-0.743	0.567695916
4685	2000-01-02 01:18:05	994	Jerry     	-0.667	0.752168655
4686	2000-01-02 01:18:06	994	Jerry     	-0.957	0.375872374
4687	2000-01-02 01:18:07	984	Edith     	0.458	0.464484155
4688	2000-01-02 01:18:08	992	Ursula    	0.376	0.234533638
4689	2000-01-02 01:18:09	987	Laura     	0.190	-0.252490968
4690	2000-01-02 01:18:10	995	Oliver    	0.921	-0.0756226256
4691	2000-01-02 01:18:11	1038	Edith     	-0.557	0.318340182
4692	2000-01-02 01:18:12	1043	Frank     	-0.838	-0.332517326
4693	2000-01-02 01:18:13	982	Tim       	0.839	-0.580558479
4694	2000-01-02 01:18:14	1087	Ingrid    	0.635	0.865917504
4695	2000-01-02 01:18:15	945	Wendy     	-0.855	0.172866017
4696	2000-01-02 01:18:16	996	Wendy     	-0.518	-0.531192958
4697	2000-01-02 01:18:17	1011	Wendy     	0.086	0.233215094
4698	2000-01-02 01:18:18	969	Charlie   	-0.995	-0.953997552
4699	2000-01-02 01:18:19	946	Oliver    	-0.962	-0.875368893
4700	2000-01-02 01:18:20	965	Jerry     	0.749	-0.601220965
4701	2000-01-02 01:18:21	1008	Jerry     	0.134	-0.914828241
4702	2000-01-02 01:18:22	992	Tim       	-0.269	-0.751433909
4703	2000-01-02 01:18:23	962	Ray       	-0.814	-0.0674789771
4704	2000-01-02 01:18:24	986	Laura     	0.990	0.476086229
4705	2000-01-02 01:18:25	992	Ursula    	0.164	0.962651014
4706	2000-01-02 01:18:26	1009	Hannah    	-0.289	-0.956011832
4707	2000-01-02 01:18:27	908	Ursula    	-0.162	-0.392731279
4708	2000-01-02 01:18:28	1015	Yvonne    	0.711	0.858095825
4709	2000-01-02 01:18:29	1003	Kevin     	-0.450	0.204947084
4710	2000-01-02 01:18:30	1087	Frank     	0.848	0.856845438
4711	2000-01-02 01:18:31	984	Alice     	-0.916	-0.153520986
4712	2000-01-02 01:18:32	954	Xavier    	0.463	0.423924595
4713	2000-01-02 01:18:33	974	Zelda     	-0.859	0.149523363
4714	2000-01-02 01:18:34	1008	Bob       	-0.174	0.513865829
4715	2000-01-02 01:18:35	944	George    	0.059	0.319954187
4716	2000-01-02 01:18:36	1013	Tim       	-0.657	-0.222328216
4717	2000-01-02 01:18:37	1018	Victor    	-0.366	0.157737941
4718	2000-01-02 01:18:38	1033	Kevin     	0.218	0.997552097
4719	2000-01-02 01:18:39	993	Wendy     	0.831	-0.198706925
4720	2000-01-02 01:18:40	992	Kevin     	0.416	0.81901598
4721	2000-01-02 01:18:41	1014	Alice     	-0.308	-0.649440587
4722	2000-01-02 01:18:42	986	Hannah    	-0.851	-0.139288798
4723	2000-01-02 01:18:43	975	Oliver    	-0.499	-0.649645209
4724	2000-01-02 01:18:44	1017	Quinn     	-0.492	-0.981856346
4725	2000-01-02 01:18:45	993	Ray       	-0.726	-0.960037649
4726	2000-01-02 01:18:46	1025	Bob       	0.169	-0.55215776
4727	2000-01-02 01:18:47	1027	Yvonne    	0.719	0.460793018
4728	2000-01-02 01:18:48	1025	George    	0.524	-0.231403872
4729	2000-01-02 01:18:49	1034	Tim       	0.312	0.818636358
4730	2000-01-02 01:18:50	984	Ingrid    	-0.156	0.69099164
4731	2000-01-02 01:18:51	988	Patricia  	-0.846	0.624683738
4732	2000-01-02 01:18:52	1067	Laura     	-0.142	0.0123668825
4733	2000-01-02 01:18:53	1014	Ray       	0.803	0.843034327
4734	2000-01-02 01:18:54	1009	Victor    	0.310	0.996710002
4735	2000-01-02 01:18:55	1011	Ray       	0.058	0.65757817
4736	2000-01-02 01:18:56	1007	Victor    	0.888	0.602823198
4737	2000-01-02 01:18:57	998	Charlie   	-0.152	-0.883716762
4738	2000-01-02 01:18:58	996	Dan       	-0.024	0.329770893
4739	2000-01-02 01:18:59	1004	Yvonne    	0.383	-0.510675788
4740	2000-01-02 01:19:00	978	Patricia  	-0.285	-0.243751138
4741	2000-01-02 01:19:01	964	Frank     	-0.444	-0.475731462
4742	2000-01-02 01:19:02	979	Laura     	-0.589	-0.160761327
4743	2000-01-02 01:19:03	934	Xavier    	0.837	0.821835041
4744	2000-01-02 01:19:04	1019	Yvonne    	0.775	0.4319987
4745	2000-01-02 01:19:05	989	Laura     	0.397	0.109417625
4746	2000-01-02 01:19:06	1009	Patricia  	-0.229	-0.336610973
4747	2000-01-02 01:19:07	1058	George    	-0.628	-0.137435406
4748	2000-01-02 01:19:08	977	Bob       	0.569	-0.73957926
4749	2000-01-02 01:19:09	958	Ursula    	0.069	-0.0492940024
4750	2000-01-02 01:19:10	978	Michael   	0.378	-0.657091975
4751	2000-01-02 01:19:11	958	Ingrid    	-0.565	0.990441501
4752	2000-01-02 01:19:12	1013	Michael   	-0.092	0.249729425
4753	2000-01-02 01:19:13	980	George    	-0.855	-0.266341239
4754	2000-01-02 01:19:14	1060	Kevin     	-0.293	0.826400757
4755	2000-01-02 01:19:15	992	Michael   	0.879	0.308424115
4756	2000-01-02 01:19:16	999	Hannah    	-0.957	-0.652811348
4757	2000-01-02 01:19:17	984	Tim       	-0.071	-0.389080852
4758	2000-01-02 01:19:18	981	Edith     	0.234	-0.0386195369
4759	2000-01-02 01:19:19	970	Quinn     	-0.772	0.157066002
4760	2000-01-02 01:19:20	1031	Zelda     	0.268	-0.864989221
4761	2000-01-02 01:19:21	1023	Kevin     	0.746	-0.622601151
4762	2000-01-02 01:19:22	1042	Jerry     	-0.011	0.256352812
4763	2000-01-02 01:19:23	1014	Tim       	-0.673	0.647238433
4764	2000-01-02 01:19:24	1010	Michael   	0.999	0.0946973264
4765	2000-01-02 01:19:25	1015	Ingrid    	-0.779	0.276631445
4766	2000-01-02 01:19:26	1027	Kevin     	0.406	-0.276656687
4767	2000-01-02 01:19:27	1007	Frank     	-0.031	0.563095033
4768	2000-01-02 01:19:28	1000	Frank     	-0.608	-0.0333836414
4769	2000-01-02 01:19:29	972	Bob       	-0.104	0.354668081
4770	2000-01-02 01:19:30	941	Sarah     	0.854	-0.846764624
4771	2000-01-02 01:19:31	995	Laura     	-0.059	-0.976103544
4772	2000-01-02 01:19:32	953	Norbert   	0.430	-0.706976354
4773	2000-01-02 01:19:33	947	Zelda     	-0.436	0.301517993
4774	2000-01-02 01:19:34	1004	Dan       	0.666	-0.834148109
4775	2000-01-02 01:19:35	965	Charlie   	-0.534	0.846081018
4776	2000-01-02 01:19:36	967	Frank     	-0.696	-0.378491938
4777	2000-01-02 01:19:37	962	Dan       	-0.772	-0.673538446
4778	2000-01-02 01:19:38	984	Xavier    	-0.398	0.810010612
4779	2000-01-02 01:19:39	1014	Alice     	-0.843	0.479708016
4780	2000-01-02 01:19:40	1025	Norbert   	0.533	0.0751436055
4781	2000-01-02 01:19:41	1007	Charlie   	-0.093	-0.382161766
4782	2000-01-02 01:19:42	1006	Wendy     	-0.836	-0.585756719
4783	2000-01-02 01:19:43	1042	Patricia  	-0.609	0.237922117
4784	2000-01-02 01:19:44	991	Sarah     	0.295	-0.647676289
4785	2000-01-02 01:19:45	1031	Hannah    	0.736	0.436828494
4786	2000-01-02 01:19:46	987	Patricia  	-0.453	0.618113101
4787	2000-01-02 01:19:47	1026	Ingrid    	0.750	-0.853781462
4788	2000-01-02 01:19:48	988	Jerry     	-0.781	0.236662954
4789	2000-01-02 01:19:49	966	Bob       	-0.747	0.870034695
4790	2000-01-02 01:19:50	1005	Edith     	0.874	-0.48878774
4791	2000-01-02 01:19:51	963	Alice     	-0.785	0.9453879
4792	2000-01-02 01:19:52	1021	Yvonne    	-0.002	-0.640995026
4793	2000-01-02 01:19:53	981	Dan       	-0.346	0.253766805
4794	2000-01-02 01:19:54	1011	Quinn     	0.866	-0.692005992
4795	2000-01-02 01:19:55	964	Ursula    	0.207	0.253532618
4796	2000-01-02 01:19:56	948	Jerry     	-0.214	0.0821942165
4797	2000-01-02 01:19:57	986	Laura     	0.111	-0.887391925
4798	2000-01-02 01:19:58	970	Frank     	-0.300	-0.321690261
4799	2000-01-02 01:19:59	1016	Bob       	-0.288	-0.539829791
4800	2000-01-02 01:20:00	1050	Oliver    	-0.557	-0.625537038
4801	2000-01-02 01:20:01	1005	Tim       	-0.907	-0.361183971
4802	2000-01-02 01:20:02	960	Tim       	-0.067	0.586853087
4803	2000-01-02 01:20:03	1007	Patricia  	0.769	0.341823995
4804	2000-01-02 01:20:04	1068	Sarah     	-0.758	-0.575289786
4805	2000-01-02 01:20:05	1035	Oliver    	-0.103	0.027127523
4806	2000-01-02 01:20:06	974	Zelda     	0.927	0.877306759
4807	2000-01-02 01:20:07	980	Ursula    	0.428	-0.537575364
4808	2000-01-02 01:20:08	1003	Jerry     	0.090	-0.55912298
4809	2000-01-02 01:20:09	955	Laura     	-0.826	-0.563023984
4810	2000-01-02 01:20:10	960	Ursula    	0.443	0.400007337
4811	2000-01-02 01:20:11	969	Victor    	0.642	0.738232076
4812	2000-01-02 01:20:12	1010	Wendy     	0.581	-0.783177018
4813	2000-01-02 01:20:13	991	Yvonne    	-0.001	0.90127641
4814	2000-01-02 01:20:14	1022	Michael   	-0.017	0.355223984
4815	2000-01-02 01:20:15	989	Ingrid    	0.358	-0.705711246
4816	2000-01-02 01:20:16	1061	Oliver    	0.699	-0.435986876
4817	2000-01-02 01:20:17	1014	Michael   	0.303	0.219769284
4818	2000-01-02 01:20:18	985	Bob       	-0.929	-0.71350807
4819	2000-01-02 01:20:19	994	Norbert   	-0.222	-0.00436295196
4820	2000-01-02 01:20:20	934	Victor    	0.154	0.95076102
4821	2000-01-02 01:20:21	1016	Laura     	-0.373	-0.00886385329
4822	2000-01-02 01:20:22	970	Kevin     	0.834	-0.484934807
4823	2000-01-02 01:20:23	1001	Edith     	-0.019	0.708630323
4824	2000-01-02 01:20:24	1024	Norbert   	0.186	0.671620369
4825	2000-01-02 01:20:25	983	Jerry     	0.678	0.48540324
4826	2000-01-02 01:20:26	1047	Ursula    	-0.540	-0.952288985
4827	2000-01-02 01:20:27	988	Tim       	0.992	0.856409132
4828	2000-01-02 01:20:28	980	Frank     	0.720	-0.796989083
4829	2000-01-02 01:20:29	1027	Charlie   	-0.506	-0.83285749
4830	2000-01-02 01:20:30	991	Yvonne    	-0.435	-0.330630779
4831	2000-01-02 01:20:31	937	Ursula    	0.327	-0.813016832
4832	2000-01-02 01:20:32	1006	Ingrid    	-0.133	-0.33923623
4833	2000-01-02 01:20:33	1033	Yvonne    	-0.930	0.0260104276
4834	2000-01-02 01:20:34	990	George    	0.625	-0.235107556
4835	2000-01-02 01:20:35	1022	Hannah    	0.069	0.0590496548
4836	2000-01-02 01:20:36	992	Victor    	0.316	0.43682158
4837	2000-01-02 01:20:37	967	Charlie   	0.751	-0.0401322506
4838	2000-01-02 01:20:38	986	Michael   	0.699	-0.176855966
4839	2000-01-02 01:20:39	991	Xavier    	0.004	0.19104664
4840	2000-01-02 01:20:40	945	Dan       	-0.334	0.678608775
4841	2000-01-02 01:20:41	1019	Charlie   	-0.632	-0.790866137
4842	2000-01-02 01:20:42	1040	Tim       	0.770	0.637559235
4843	2000-01-02 01:20:43	1004	Jerry     	0.087	-0.828157246
4844	2000-01-02 01:20:44	1009	Jerry     	0.817	-0.748230338
4845	2000-01-02 01:20:45	1063	Norbert   	-0.296	-0.64352715
4846	2000-01-02 01:20:46	1002	Norbert   	0.184	0.650337458
4847	2000-01-02 01:20:47	983	Tim       	0.795	-0.866143584
4848	2000-01-02 01:20:48	1073	Oliver    	0.254	-0.356218547
4849	2000-01-02 01:20:49	1021	Hannah    	0.332	-0.938860714
4850	2000-01-02 01:20:50	1069	Bob       	-0.699	0.795724928
4851	2000-01-02 01:20:51	1019	Jerry     	-0.279	-0.337635309
4852	2000-01-02 01:20:52	1088	Wendy     	0.556	0.526981771
4853	2000-01-02 01:20:53	1040	Victor    	-0.934	0.531811476
4854	2000-01-02 01:20:54	1010	Charlie   	0.683	-0.415996462
4855	2000-01-02 01:20:55	944	Victor    	0.958	0.0112728924
4856	2000-01-02 01:20:56	1001	Norbert   	0.521	0.520636618
4857	2000-01-02 01:20:57	984	Dan       	-0.575	-0.838019788
4858	2000-01-02 01:20:58	1045	Frank     	0.810	-0.248567656
4859	2000-01-02 01:20:59	1033	Jerry     	-0.755	-0.668014169
4860	2000-01-02 01:21:00	1025	Patricia  	-0.873	-0.993881822
4861	2000-01-02 01:21:01	1011	Charlie   	0.726	0.0700342134
4862	2000-01-02 01:21:02	1015	Hannah    	0.945	-0.720462382
4863	2000-01-02 01:21:03	1064	Edith     	-0.769	-0.748046219
4864	2000-01-02 01:21:04	929	Zelda     	-0.051	-0.312927067
4865	2000-01-02 01:21:05	1025	Ursula    	0.247	-0.934737027
4866	2000-01-02 01:21:06	921	Kevin     	0.919	-0.808621407
4867	2000-01-02 01:21:07	985	Tim       	0.883	0.574038208
4868	2000-01-02 01:21:08	990	Wendy     	-0.773	0.439412296
4869	2000-01-02 01:21:09	964	Patricia  	0.366	0.955892026
4870	2000-01-02 01:21:10	1028	Victor    	0.499	0.204004377
4871	2000-01-02 01:21:11	998	Hannah    	-0.540	-0.508285642
4872	2000-01-02 01:21:12	940	Laura     	-0.266	0.7556113
4873	2000-01-02 01:21:13	1016	Michael   	-0.327	0.428259939
4874	2000-01-02 01:21:14	968	Hannah    	-0.344	0.397205234
4875	2000-01-02 01:21:15	1003	Xavier    	0.772	0.435274273
4876	2000-01-02 01:21:16	1028	George    	0.014	-0.995203316
4877	2000-01-02 01:21:17	1052	Michael   	0.148	0.0589356273
4878	2000-01-02 01:21:18	1025	Charlie   	-0.215	-0.248954058
4879	2000-01-02 01:21:19	992	George    	0.174	0.780032814
4880	2000-01-02 01:21:20	957	Zelda     	-0.334	-0.022514319
4881	2000-01-02 01:21:21	1030	Bob       	0.076	0.138158962
4882	2000-01-02 01:21:22	948	Laura     	0.837	-0.461263835
4883	2000-01-02 01:21:23	970	Ray       	0.984	0.888496757
4884	2000-01-02 01:21:24	1061	Norbert   	-0.241	-0.00179506768
4885	2000-01-02 01:21:25	975	Frank     	0.935	0.252745926
4886	2000-01-02 01:21:26	1010	Michael   	0.274	-0.615866423
4887	2000-01-02 01:21:27	971	Alice     	-0.723	-0.934540689
4888	2000-01-02 01:21:28	979	Yvonne    	0.504	-0.48777315
4889	2000-01-02 01:21:29	991	Kevin     	-0.535	0.420381695
4890	2000-01-02 01:21:30	992	Norbert   	-0.518	0.308042347
4891	2000-01-02 01:21:31	979	Patricia  	0.763	-0.282477856
4892	2000-01-02 01:21:32	1040	Jerry     	0.973	-0.78350848
4893	2000-01-02 01:21:33	1038	Victor    	-0.035	-0.636188328
4894	2000-01-02 01:21:34	1043	Victor    	-0.026	0.297578663
4895	2000-01-02 01:21:35	1013	Charlie   	0.326	0.637525618
4896	2000-01-02 01:21:36	1016	Zelda     	0.969	0.707396746
4897	2000-01-02 01:21:37	946	Oliver    	-0.462	0.230518475
4898	2000-01-02 01:21:38	983	Michael   	0.767	0.698301554
4899	2000-01-02 01:21:39	941	Charlie   	-0.196	-0.884328544
4900	2000-01-02 01:21:40	994	Quinn     	-0.974	-0.720542431
4901	2000-01-02 01:21:41	983	Norbert   	-0.965	0.835983992
4902	2000-01-02 01:21:42	995	Kevin     	0.184	0.345084816
4903	2000-01-02 01:21:43	998	Kevin     	0.729	-0.604937434
4904	2000-01-02 01:21:44	995	Oliver    	0.614	-0.333541542
4905	2000-01-02 01:21:45	967	Quinn     	-0.441	0.300852746
4906	2000-01-02 01:21:46	1020	Xavier    	-0.631	0.966792107
4907	2000-01-02 01:21:47	978	Quinn     	0.061	0.799976826
4908	2000-01-02 01:21:48	1006	Bob       	0.783	0.754966736
4909	2000-01-02 01:21:49	1006	Oliver    	0.972	-0.424507618
4910	2000-01-02 01:21:50	1002	Oliver    	0.117	0.419122428
4911	2000-01-02 01:21:51	1011	Zelda     	0.263	0.0580546521
4912	2000-01-02 01:21:52	1023	Patricia  	-0.084	-0.583278656
4913	2000-01-02 01:21:53	996	Sarah     	0.384	-0.722226262
4914	2000-01-02 01:21:54	1025	Charlie   	0.437	0.722029924
4915	2000-01-02 01:21:55	959	Dan       	-0.496	-0.253711581
4916	2000-01-02 01:21:56	1022	Alice     	0.783	-0.705321312
4917	2000-01-02 01:21:57	971	Alice     	-0.612	-0.977614641
4918	2000-01-02 01:21:58	998	Victor    	0.472	0.633556247
4919	2000-01-02 01:21:59	951	Alice     	-0.734	0.586600959
4920	2000-01-02 01:22:00	992	Xavier    	0.257	-0.0108858962
4921	2000-01-02 01:22:01	1045	Norbert   	0.377	-0.668573856
4922	2000-01-02 01:22:02	1038	Norbert   	-0.761	0.128420755
4923	2000-01-02 01:22:03	948	Yvonne    	-0.883	0.671774924
4924	2000-01-02 01:22:04	999	Laura     	-0.218	-0.338002831
4925	2000-01-02 01:22:05	1000	Oliver    	0.009	-0.528113544
4926	2000-01-02 01:22:06	1007	Dan       	0.284	-0.527563393
4927	2000-01-02 01:22:07	992	Charlie   	-0.665	0.936056733
4928	2000-01-02 01:22:08	1057	Laura     	-0.373	0.250672102
4929	2000-01-02 01:22:09	1022	Edith     	0.503	-0.137429863
4930	2000-01-02 01:22:10	983	Alice     	0.573	0.905301988
4931	2000-01-02 01:22:11	1027	Charlie   	0.761	-0.690365314
4932	2000-01-02 01:22:12	977	Hannah    	-0.604	0.268266439
4933	2000-01-02 01:22:13	931	Tim       	-0.850	0.285379261
4934	2000-01-02 01:22:14	1009	Sarah     	-0.154	-0.432213098
4935	2000-01-02 01:22:15	966	Wendy     	0.987	0.996558785
4936	2000-01-02 01:22:16	1028	Patricia  	-0.936	-0.636848629
4937	2000-01-02 01:22:17	980	Charlie   	-0.798	-0.909774303
4938	2000-01-02 01:22:18	940	Tim       	0.037	-0.634357333
4939	2000-01-02 01:22:19	1011	Norbert   	-0.838	0.24200578
4940	2000-01-02 01:22:20	996	Bob       	-0.693	0.866568089
4941	2000-01-02 01:22:21	950	Ray       	-0.655	-0.789768755
4942	2000-01-02 01:22:22	990	Dan       	0.179	0.138266027
4943	2000-01-02 01:22:23	1002	Hannah    	-0.146	-0.235430151
4944	2000-01-02 01:22:24	973	Kevin     	0.894	-0.863871098
4945	2000-01-02 01:22:25	949	Bob       	0.413	0.874148905
4946	2000-01-02 01:22:26	1042	Charlie   	0.914	0.431267232
4947	2000-01-02 01:22:27	981	Zelda     	0.855	-0.618565381
4948	2000-01-02 01:22:28	1035	Ray       	-0.878	0.728542864
4949	2000-01-02 01:22:29	975	Xavier    	0.612	0.0183166694
4950	2000-01-02 01:22:30	995	Kevin     	0.950	-0.604409754
4951	2000-01-02 01:22:31	939	Norbert   	-0.666	-0.237952545
4952	2000-01-02 01:22:32	987	Michael   	-0.816	-0.442884654
4953	2000-01-02 01:22:33	967	Ray       	0.849	0.770255506
4954	2000-01-02 01:22:34	1069	Ursula    	-0.891	-0.5306198
4955	2000-01-02 01:22:35	1026	Laura     	-0.064	-0.886876762
4956	2000-01-02 01:22:36	992	Patricia  	-0.285	0.483231992
4957	2000-01-02 01:22:37	995	Xavier    	0.456	-0.445390433
4958	2000-01-02 01:22:38	983	Quinn     	0.741	0.431909829
4959	2000-01-02 01:22:39	1068	Wendy     	0.961	-0.970923901
4960	2000-01-02 01:22:40	1021	Yvonne    	-0.887	-0.602888882
4961	2000-01-02 01:22:41	1051	Hannah    	-0.309	-0.796243668
4962	2000-01-02 01:22:42	956	Alice     	-0.793	0.419161618
4963	2000-01-02 01:22:43	1071	Xavier    	0.076	0.532703221
4964	2000-01-02 01:22:44	961	Sarah     	0.524	-0.722228527
4965	2000-01-02 01:22:45	1005	Tim       	-0.873	-0.0249802135
4966	2000-01-02 01:22:46	1002	Oliver    	0.056	0.235643625
4967	2000-01-02 01:22:47	925	Tim       	-0.460	-0.186224446
4968	2000-01-02 01:22:48	964	Zelda     	-0.654	-0.722081661
4969	2000-01-02 01:22:49	977	Victor    	-0.836	0.930468202
4970	2000-01-02 01:22:50	1026	Wendy     	0.138	0.643054366
4971	2000-01-02 01:22:51	1029	Patricia  	-0.801	-0.180691496
4972	2000-01-02 01:22:52	941	Alice     	0.243	0.661485851
4973	2000-01-02 01:22:53	983	Charlie   	0.851	-0.996332407
4974	2000-01-02 01:22:54	1065	Bob       	0.305	-0.0818431675
4975	2000-01-02 01:22:55	975	Bob       	-0.990	-0.507567346
4976	2000-01-02 01:22:56	1018	Ray       	-0.970	-0.631422997
4977	2000-01-02 01:22:57	993	Xavier    	0.777	-0.375023097
4978	2000-01-02 01:22:58	1042	Ingrid    	-0.537	0.494498789
4979	2000-01-02 01:22:59	1054	Hannah    	-0.909	-0.188131452
4980	2000-01-02 01:23:00	997	Zelda     	-0.556	0.138793632
4981	2000-01-02 01:23:01	947	Laura     	-0.110	0.768391013
4982	2000-01-02 01:23:02	1003	Ursula    	0.379	0.721366346
4983	2000-01-02 01:23:03	967	Wendy     	-0.897	0.601249814
4984	2000-01-02 01:23:04	1027	Ursula    	0.959	0.751690686
4985	2000-01-02 01:23:05	1017	Alice     	-0.412	-0.523861766
4986	2000-01-02 01:23:06	1044	Alice     	0.189	0.0644536018
4987	2000-01-02 01:23:07	995	Laura     	0.694	0.888785183
4988	2000-01-02 01:23:08	1032	Oliver    	0.821	-0.216179162
4989	2000-01-02 01:23:09	1040	Norbert   	-0.112	0.30082956
4990	2000-01-02 01:23:10	940	Zelda     	-0.212	0.0958135203
4991	2000-01-02 01:23:11	1016	Ursula    	-0.642	-0.624821544
4992	2000-01-02 01:23:12	1031	Bob       	-0.779	0.30866915
4993	2000-01-02 01:23:13	1041	Ray       	-0.306	-0.559132397
4994	2000-01-02 01:23:14	1035	Ray       	0.985	-0.49603802
4995	2000-01-02 01:23:15	962	Norbert   	-0.608	0.318041861
4996	2000-01-02 01:23:16	1024	Ingrid    	-0.760	0.38450703
4997	2000-01-02 01:23:17	1056	Jerry     	0.664	0.914732695
4998	2000-01-02 01:23:18	1030	Edith     	-0.357	-0.494297594
4999	2000-01-02 01:23:19	991	Dan       	0.371	-0.995523691
5000	2000-01-02 01:23:20	990	George    	-0.826	-0.471967936
5001	2000-01-02 01:23:21	1050	Wendy     	-0.252	0.338844895
5002	2000-01-02 01:23:22	1042	Ursula    	0.014	-0.224737898
5003	2000-01-02 01:23:23	984	Patricia  	-0.142	0.51125896
5004	2000-01-02 01:23:24	1025	George    	0.861	-0.680135667
5005	2000-01-02 01:23:25	956	Jerry     	0.608	-0.825567961
5006	2000-01-02 01:23:26	998	Charlie   	-0.132	-0.390366316
5007	2000-01-02 01:23:27	1022	Patricia  	-0.190	-0.730164886
5008	2000-01-02 01:23:28	991	Dan       	-0.244	0.620023489
5009	2000-01-02 01:23:29	991	George    	-0.038	0.926151454
5010	2000-01-02 01:23:30	1004	Xavier    	-0.133	0.554345906
5011	2000-01-02 01:23:31	950	Ursula    	-0.327	-0.718115032
5012	2000-01-02 01:23:32	937	Ray       	-0.807	-0.351181209
5013	2000-01-02 01:23:33	1040	Edith     	-0.759	0.377952695
5014	2000-01-02 01:23:34	964	Michael   	-0.272	-0.906242907
5015	2000-01-02 01:23:35	1029	Norbert   	-0.527	0.533888817
5016	2000-01-02 01:23:36	1035	Xavier    	-0.987	-0.611710727
5017	2000-01-02 01:23:37	1005	Dan       	-0.237	-0.196671277
5018	2000-01-02 01:23:38	1026	Sarah     	0.416	-0.11835283
5019	2000-01-02 01:23:39	978	Kevin     	0.533	-0.603816926
5020	2000-01-02 01:23:40	1039	Charlie   	0.859	0.076824531
5021	2000-01-02 01:23:41	1028	Zelda     	0.701	-0.627020895
5022	2000-01-02 01:23:42	1022	Michael   	0.191	0.369016975
5023	2000-01-02 01:23:43	1011	George    	0.931	0.0720844567
5024	2000-01-02 01:23:44	1055	Quinn     	-0.773	-0.581650138
5025	2000-01-02 01:23:45	1016	Xavier    	-0.699	-0.0920322165
5026	2000-01-02 01:23:46	971	Bob       	0.065	-0.217073113
5027	2000-01-02 01:23:47	998	Edith     	-0.291	-0.446190178
5028	2000-01-02 01:23:48	958	Charlie   	-0.834	-0.0905647278
5029	2000-01-02 01:23:49	979	Ursula    	-0.159	0.268413365
5030	2000-01-02 01:23:50	982	Frank     	-0.519	0.929689944
5031	2000-01-02 01:23:51	965	Wendy     	0.913	0.706650138
5032	2000-01-02 01:23:52	1038	Wendy     	-0.353	0.425165623
5033	2000-01-02 01:23:53	963	Tim       	-0.471	0.338256836
5034	2000-01-02 01:23:54	995	Michael   	0.841	-0.386130303
5035	2000-01-02 01:23:55	1037	Oliver    	-0.626	0.883181393
5036	2000-01-02 01:23:56	1059	Quinn     	0.950	0.673036635
5037	2000-01-02 01:23:57	995	Ursula    	-0.379	0.868684769
5038	2000-01-02 01:23:58	967	Ray       	-0.291	0.171875134
5039	2000-01-02 01:23:59	965	Yvonne    	0.864	0.20132044
5040	2000-01-02 01:24:00	1024	Xavier    	-0.072	0.948887289
5041	2000-01-02 01:24:01	1036	Sarah     	0.719	0.311112046
5042	2000-01-02 01:24:02	972	Norbert   	0.595	-0.514251947
5043	2000-01-02 01:24:03	1021	Yvonne    	0.842	0.52842474
5044	2000-01-02 01:24:04	1020	Victor    	0.904	0.49063763
5045	2000-01-02 01:24:05	1088	Dan       	0.113	0.439714283
5046	2000-01-02 01:24:06	1042	Wendy     	0.371	0.446151376
5047	2000-01-02 01:24:07	942	George    	0.200	0.297667712
5048	2000-01-02 01:24:08	993	Charlie   	-0.096	0.123715423
5049	2000-01-02 01:24:09	1018	Michael   	-0.466	-0.703206956
5050	2000-01-02 01:24:10	930	Dan       	0.311	0.380560249
5051	2000-01-02 01:24:11	1018	Jerry     	-0.003	-0.873654366
5052	2000-01-02 01:24:12	992	Quinn     	0.524	0.668210387
5053	2000-01-02 01:24:13	986	Frank     	-0.125	0.932490468
5054	2000-01-02 01:24:14	996	Norbert   	0.528	-0.874974132
5055	2000-01-02 01:24:15	1017	Charlie   	0.772	-0.302987188
5056	2000-01-02 01:24:16	994	Ingrid    	0.739	-0.377360523
5057	2000-01-02 01:24:17	964	Oliver    	0.703	0.491296023
5058	2000-01-02 01:24:18	982	Frank     	0.932	0.401286572
5059	2000-01-02 01:24:19	1001	Michael   	-0.677	0.245315194
5060	2000-01-02 01:24:20	1043	Alice     	-0.078	0.357964188
5061	2000-01-02 01:24:21	958	Jerry     	-0.984	0.502791524
5062	2000-01-02 01:24:22	1071	Yvonne    	0.772	0.615634859
5063	2000-01-02 01:24:23	1064	George    	0.823	0.907001734
5064	2000-01-02 01:24:24	990	Ursula    	-0.150	-0.879250884
5065	2000-01-02 01:24:25	1020	Sarah     	-0.952	0.979689896
5066	2000-01-02 01:24:26	1018	Wendy     	0.066	-0.119933784
5067	2000-01-02 01:24:27	947	Zelda     	-0.925	-0.219254643
5068	2000-01-02 01:24:28	1036	Ray       	0.149	0.822239816
5069	2000-01-02 01:24:29	956	Wendy     	0.128	0.285897225
5070	2000-01-02 01:24:30	976	Yvonne    	0.218	-0.609710991
5071	2000-01-02 01:24:31	1066	Norbert   	-0.302	-0.708193064
5072	2000-01-02 01:24:32	1077	Ingrid    	0.918	0.0284384284
5073	2000-01-02 01:24:33	951	Michael   	0.621	0.293050319
5074	2000-01-02 01:24:34	969	Tim       	-0.531	0.255295664
5075	2000-01-02 01:24:35	928	Oliver    	-0.661	0.387020946
5076	2000-01-02 01:24:36	1057	Victor    	-0.571	0.172679216
5077	2000-01-02 01:24:37	973	George    	-0.642	0.0378334709
5078	2000-01-02 01:24:38	995	Frank     	-0.541	0.748316705
5079	2000-01-02 01:24:39	975	Zelda     	-0.151	-0.644642711
5080	2000-01-02 01:24:40	1053	Oliver    	0.998	0.405475169
5081	2000-01-02 01:24:41	1014	Frank     	0.780	-0.683586538
5082	2000-01-02 01:24:42	1051	Victor    	-0.299	0.880859613
5083	2000-01-02 01:24:43	1034	Michael   	0.946	0.247713462
5084	2000-01-02 01:24:44	982	Hannah    	0.220	-0.616307557
5085	2000-01-02 01:24:45	1002	Patricia  	0.885	0.735989213
5086	2000-01-02 01:24:46	968	Oliver    	0.632	0.208058432
5087	2000-01-02 01:24:47	1000	Ray       	0.943	-0.922866881
5088	2000-01-02 01:24:48	1066	Laura     	-0.323	0.501859546
5089	2000-01-02 01:24:49	972	Kevin     	0.829	0.593049526
5090	2000-01-02 01:24:50	1008	Patricia  	-0.555	0.40451768
5091	2000-01-02 01:24:51	983	Ingrid    	0.828	-0.950459123
5092	2000-01-02 01:24:52	989	Bob       	0.960	0.0955748037
5093	2000-01-02 01:24:53	1054	Michael   	-0.517	-0.920992494
5094	2000-01-02 01:24:54	964	Hannah    	-0.385	0.968826056
5095	2000-01-02 01:24:55	977	Ursula    	0.551	0.369419932
5096	2000-01-02 01:24:56	1035	Yvonne    	-0.600	-0.515429258
5097	2000-01-02 01:24:57	1022	Frank     	0.174	0.858667612
5098	2000-01-02 01:24:58	1035	Kevin     	0.065	0.605252862
5099	2000-01-02 01:24:59	1028	Edith     	-0.048	-0.171171844
5100	2000-01-02 01:25:00	989	Victor    	0.247	-0.125939474
5101	2000-01-02 01:25:01	1011	Dan       	-0.225	0.514383554
5102	2000-01-02 01:25:02	940	Patricia  	0.398	0.250714839
5103	2000-01-02 01:25:03	970	Patricia  	-0.889	-0.527720869
5104	2000-01-02 01:25:04	1049	Norbert   	0.579	-0.819012403
5105	2000-01-02 01:25:05	1012	Norbert   	-0.236	0.423184037
5106	2000-01-02 01:25:06	945	Michael   	0.200	-0.863726139
5107	2000-01-02 01:25:07	1042	Edith     	-0.936	0.781715989
5108	2000-01-02 01:25:08	1002	Frank     	0.766	0.07071843
5109	2000-01-02 01:25:09	1027	Laura     	-0.241	-0.784869909
5110	2000-01-02 01:25:10	963	George    	0.901	-0.372546613
5111	2000-01-02 01:25:11	996	Norbert   	-0.322	0.979777992
5112	2000-01-02 01:25:12	971	Victor    	-0.980	-0.560564101
5113	2000-01-02 01:25:13	1048	Ingrid    	0.084	0.287278414
5114	2000-01-02 01:25:14	1011	Edith     	-0.033	-0.0408614725
5115	2000-01-02 01:25:15	970	Tim       	-0.279	-0.319644779
5116	2000-01-02 01:25:16	1029	Ursula    	-0.425	-0.547134757
5117	2000-01-02 01:25:17	975	Xavier    	0.486	-0.909339249
5118	2000-01-02 01:25:18	1065	Oliver    	-0.216	0.54741621
5119	2000-01-02 01:25:19	985	Laura     	-0.761	0.954495251
5120	2000-01-02 01:25:20	954	Xavier    	0.358	0.351910025
5121	2000-01-02 01:25:21	1047	Edith     	-0.674	0.616984069
5122	2000-01-02 01:25:22	976	Ursula    	0.644	0.856646299
5123	2000-01-02 01:25:23	1006	Patricia  	-0.235	0.690208137
5124	2000-01-02 01:25:24	980	Alice     	0.178	0.732604802
5125	2000-01-02 01:25:25	970	Alice     	0.389	-0.847595394
5126	2000-01-02 01:25:26	997	Tim       	0.590	-0.143336385
5127	2000-01-02 01:25:27	991	Charlie   	0.990	0.39122498
5128	2000-01-02 01:25:28	975	Jerry     	-0.458	0.534965396
5129	2000-01-02 01:25:29	1017	Patricia  	0.842	-0.406600893
5130	2000-01-02 01:25:30	1011	Ingrid    	0.046	-0.0289803911
5131	2000-01-02 01:25:31	1033	Charlie   	0.692	-0.0506752841
5132	2000-01-02 01:25:32	1044	Ray       	0.066	-0.291321516
5133	2000-01-02 01:25:33	1026	Xavier    	0.901	0.739895701
5134	2000-01-02 01:25:34	946	Sarah     	-0.134	-0.476462811
5135	2000-01-02 01:25:35	971	Ray       	-0.581	-0.0246280096
5136	2000-01-02 01:25:36	962	Sarah     	0.125	-0.00195480627
5137	2000-01-02 01:25:37	1015	Frank     	0.623	0.48325333
5138	2000-01-02 01:25:38	1016	Ray       	0.884	-0.619529903
5139	2000-01-02 01:25:39	997	George    	0.129	0.45298174
5140	2000-01-02 01:25:40	1028	Kevin     	-0.713	0.907579422
5141	2000-01-02 01:25:41	981	Dan       	-0.032	-0.711233914
5142	2000-01-02 01:25:42	998	Hannah    	-0.952	-0.116924696
5143	2000-01-02 01:25:43	1025	Charlie   	0.498	-0.468533754
5144	2000-01-02 01:25:44	1051	Kevin     	0.118	0.676865339
5145	2000-01-02 01:25:45	963	Ingrid    	-0.976	0.628902495
5146	2000-01-02 01:25:46	1050	Frank     	0.662	-0.548571408
5147	2000-01-02 01:25:47	929	Laura     	0.782	0.926016629
5148	2000-01-02 01:25:48	999	Dan       	0.179	-0.902352154
5149	2000-01-02 01:25:49	979	Alice     	0.569	-0.00646099821
5150	2000-01-02 01:25:50	998	George    	0.368	-0.418009371
5151	2000-01-02 01:25:51	1001	Ingrid    	-0.078	-0.0333675593
5152	2000-01-02 01:25:52	971	Wendy     	0.013	-0.267994583
5153	2000-01-02 01:25:53	1082	Alice     	-0.697	0.808572352
5154	2000-01-02 01:25:54	1000	Alice     	0.502	0.915431857
5155	2000-01-02 01:25:55	1075	Norbert   	0.469	0.146380603
5156	2000-01-02 01:25:56	996	Michael   	-0.599	-0.673191965
5157	2000-01-02 01:25:57	1058	Xavier    	0.450	-0.284612268
5158	2000-01-02 01:25:58	1028	George    	-0.939	-0.566447556
5159	2000-01-02 01:25:59	1084	Ursula    	0.104	-0.545440614
5160	2000-01-02 01:26:00	973	Xavier    	-0.519	0.229639992
5161	2000-01-02 01:26:01	1002	Alice     	0.115	-0.553125262
5162	2000-01-02 01:26:02	1005	Tim       	-0.199	0.96352911
5163	2000-01-02 01:26:03	1012	Patricia  	-0.147	-0.207881749
5164	2000-01-02 01:26:04	985	George    	0.760	0.760846853
5165	2000-01-02 01:26:05	967	Tim       	-0.201	0.0314965844
5166	2000-01-02 01:26:06	968	Bob       	0.172	0.890801907
5167	2000-01-02 01:26:07	988	Quinn     	-0.153	0.244354576
5168	2000-01-02 01:26:08	1019	Patricia  	0.040	0.0814263374
5169	2000-01-02 01:26:09	1034	Quinn     	0.087	-0.433904916
5170	2000-01-02 01:26:10	983	Frank     	0.667	-0.940911114
5171	2000-01-02 01:26:11	975	Wendy     	0.777	-0.349499196
5172	2000-01-02 01:26:12	951	Ray       	-0.696	0.554613173
5173	2000-01-02 01:26:13	1018	Wendy     	0.250	-0.656166315
5174	2000-01-02 01:26:14	1023	Edith     	-0.094	0.784507632
5175	2000-01-02 01:26:15	990	Hannah    	-0.032	0.928380072
5176	2000-01-02 01:26:16	1029	Jerry     	-0.745	0.580843627
5177	2000-01-02 01:26:17	1021	Alice     	0.637	0.441505015
5178	2000-01-02 01:26:18	991	Ray       	-0.265	-0.980751097
5179	2000-01-02 01:26:19	960	Quinn     	0.577	-0.465826303
5180	2000-01-02 01:26:20	978	Ingrid    	-0.977	0.0552451387
5181	2000-01-02 01:26:21	989	Dan       	-0.006	0.639315426
5182	2000-01-02 01:26:22	1037	Jerry     	-0.545	-0.794356823
5183	2000-01-02 01:26:23	1001	Tim       	-0.787	-0.922979116
5184	2000-01-02 01:26:24	959	Xavier    	-0.698	-0.923533618
5185	2000-01-02 01:26:25	982	Norbert   	0.325	0.00663405983
5186	2000-01-02 01:26:26	1050	Xavier    	0.556	0.323260218
5187	2000-01-02 01:26:27	987	Xavier    	0.380	0.917327285
5188	2000-01-02 01:26:28	1003	Patricia  	-0.030	-0.965593159
5189	2000-01-02 01:26:29	962	Victor    	0.893	0.793228984
5190	2000-01-02 01:26:30	985	Ingrid    	0.755	0.802136779
5191	2000-01-02 01:26:31	1023	Ray       	-0.637	-0.497552484
5192	2000-01-02 01:26:32	995	Patricia  	-0.804	-0.070628427
5193	2000-01-02 01:26:33	962	Patricia  	-0.568	-0.699011564
5194	2000-01-02 01:26:34	1024	Frank     	-0.180	0.412791282
5195	2000-01-02 01:26:35	919	Jerry     	0.894	0.373511791
5196	2000-01-02 01:26:36	962	Quinn     	-0.186	-0.139883518
5197	2000-01-02 01:26:37	1019	Oliver    	0.142	0.151379079
5198	2000-01-02 01:26:38	958	Yvonne    	0.472	-0.80583638
5199	2000-01-02 01:26:39	1055	Ray       	0.624	0.0748948604
5200	2000-01-02 01:26:40	1028	Charlie   	-0.868	-0.213751793
5201	2000-01-02 01:26:41	976	Alice     	0.797	0.915431499
5202	2000-01-02 01:26:42	1036	Alice     	-0.544	-0.792134881
5203	2000-01-02 01:26:43	971	Victor    	0.477	0.134967074
5204	2000-01-02 01:26:44	974	Patricia  	-0.572	-0.961433947
5205	2000-01-02 01:26:45	1037	Hannah    	-0.994	-0.598710597
5206	2000-01-02 01:26:46	1064	Norbert   	-0.295	0.422236204
5207	2000-01-02 01:26:47	989	Hannah    	-0.422	-0.299656332
5208	2000-01-02 01:26:48	980	Sarah     	0.635	0.458250314
5209	2000-01-02 01:26:49	1022	Ursula    	-0.089	0.195387289
5210	2000-01-02 01:26:50	1025	Wendy     	0.800	-0.962334275
5211	2000-01-02 01:26:51	975	Dan       	0.362	0.133406073
5212	2000-01-02 01:26:52	1007	Xavier    	-0.598	-0.663385928
5213	2000-01-02 01:26:53	976	Sarah     	-0.816	-0.665599227
5214	2000-01-02 01:26:54	938	Zelda     	-0.683	0.138907999
5215	2000-01-02 01:26:55	993	Kevin     	0.563	-0.807404459
5216	2000-01-02 01:26:56	987	Tim       	0.471	-0.10927923
5217	2000-01-02 01:26:57	961	Ray       	-0.579	-0.623262107
5218	2000-01-02 01:26:58	986	Alice     	0.243	0.337742299
5219	2000-01-02 01:26:59	984	Ray       	0.595	-0.570256531
5220	2000-01-02 01:27:00	1004	George    	0.327	0.929504335
5221	2000-01-02 01:27:01	941	Ingrid    	-0.122	-0.749406278
5222	2000-01-02 01:27:02	991	Ray       	0.773	0.26070559
5223	2000-01-02 01:27:03	963	Michael   	0.794	0.499408931
5224	2000-01-02 01:27:04	965	Norbert   	0.663	0.218087226
5225	2000-01-02 01:27:05	1013	Tim       	-0.933	-0.323237836
5226	2000-01-02 01:27:06	1066	Frank     	-0.405	-0.262365013
5227	2000-01-02 01:27:07	1007	Alice     	-0.732	-0.132545426
5228	2000-01-02 01:27:08	1023	Sarah     	0.095	0.360215634
5229	2000-01-02 01:27:09	980	Patricia  	-0.367	-0.381064892
5230	2000-01-02 01:27:10	977	Victor    	-0.624	-0.561745226
5231	2000-01-02 01:27:11	958	Kevin     	0.979	-0.749957263
5232	2000-01-02 01:27:12	996	Oliver    	0.289	-0.447920412
5233	2000-01-02 01:27:13	1016	Yvonne    	0.209	0.590001822
5234	2000-01-02 01:27:14	972	Kevin     	0.975	-0.383887619
5235	2000-01-02 01:27:15	1017	Alice     	0.656	-0.735041559
5236	2000-01-02 01:27:16	1017	Michael   	-0.057	-0.158840448
5237	2000-01-02 01:27:17	973	Michael   	-0.220	0.393741846
5238	2000-01-02 01:27:18	1029	Oliver    	-0.364	-0.121538505
5239	2000-01-02 01:27:19	1017	Michael   	-0.378	-0.219899014
5240	2000-01-02 01:27:20	1004	Ray       	0.888	0.355330974
5241	2000-01-02 01:27:21	1025	Tim       	0.542	-0.727325141
5242	2000-01-02 01:27:22	1014	Yvonne    	-0.451	0.929057419
5243	2000-01-02 01:27:23	973	Ursula    	0.350	0.0586784333
5244	2000-01-02 01:27:24	1029	George    	0.826	-0.998508632
5245	2000-01-02 01:27:25	977	Zelda     	0.746	-0.909494162
5246	2000-01-02 01:27:26	974	Wendy     	-0.564	0.575568855
5247	2000-01-02 01:27:27	958	Victor    	0.956	-0.0651759729
5248	2000-01-02 01:27:28	1004	Michael   	-0.694	-0.91619575
5249	2000-01-02 01:27:29	957	Wendy     	-0.383	-0.348817497
5250	2000-01-02 01:27:30	990	Edith     	0.241	0.928400457
5251	2000-01-02 01:27:31	1000	Michael   	0.234	0.811915278
5252	2000-01-02 01:27:32	992	Quinn     	-0.771	0.896885037
5253	2000-01-02 01:27:33	1009	Jerry     	0.577	0.017170636
5254	2000-01-02 01:27:34	986	Hannah    	0.019	0.908460379
5255	2000-01-02 01:27:35	1015	Hannah    	0.024	-0.835600138
5256	2000-01-02 01:27:36	965	Victor    	0.685	-0.344441772
5257	2000-01-02 01:27:37	991	Michael   	0.026	0.826847792
5258	2000-01-02 01:27:38	969	Ingrid    	0.494	-0.751250565
5259	2000-01-02 01:27:39	1000	Jerry     	-0.742	0.281360745
5260	2000-01-02 01:27:40	1006	Sarah     	-0.822	-0.844566166
5261	2000-01-02 01:27:41	1008	Michael   	-0.015	0.680095255
5262	2000-01-02 01:27:42	996	Oliver    	-0.892	0.885323524
5263	2000-01-02 01:27:43	986	Jerry     	0.139	0.856944501
5264	2000-01-02 01:27:44	1025	Xavier    	0.508	-0.590222955
5265	2000-01-02 01:27:45	1028	Bob       	-0.042	0.675839543
5266	2000-01-02 01:27:46	1014	Ray       	-0.638	0.960881948
5267	2000-01-02 01:27:47	987	Kevin     	0.257	-0.876715362
5268	2000-01-02 01:27:48	1000	Sarah     	-0.518	0.0117312483
5269	2000-01-02 01:27:49	987	Michael   	-0.820	0.3205598
5270	2000-01-02 01:27:50	943	Edith     	-0.282	-0.589600682
5271	2000-01-02 01:27:51	1028	Laura     	0.929	0.727619946
5272	2000-01-02 01:27:52	942	Ingrid    	0.614	0.891301095
5273	2000-01-02 01:27:53	1008	Quinn     	-0.927	-0.490384758
5274	2000-01-02 01:27:54	957	Victor    	0.963	-0.561723948
5275	2000-01-02 01:27:55	1001	Quinn     	0.995	-0.590194046
5276	2000-01-02 01:27:56	962	Jerry     	0.602	-0.693137467
5277	2000-01-02 01:27:57	1041	Hannah    	-0.096	0.119905911
5278	2000-01-02 01:27:58	985	Alice     	-0.805	0.966932416
5279	2000-01-02 01:27:59	960	Sarah     	-0.215	0.148520604
5280	2000-01-02 01:28:00	1049	Ursula    	0.235	0.143939808
5281	2000-01-02 01:28:01	995	Wendy     	0.938	-0.383603483
5282	2000-01-02 01:28:02	915	Patricia  	0.516	0.469020814
5283	2000-01-02 01:28:03	998	Tim       	0.627	0.477717966
5284	2000-01-02 01:28:04	1016	Frank     	-0.324	0.941691816
5285	2000-01-02 01:28:05	1072	Hannah    	0.479	-0.865292311
5286	2000-01-02 01:28:06	1002	Victor    	-0.687	0.457860798
5287	2000-01-02 01:28:07	1007	Kevin     	0.147	0.711090028
5288	2000-01-02 01:28:08	963	Frank     	-0.150	-0.639476717
5289	2000-01-02 01:28:09	1004	Ingrid    	0.135	0.583794534
5290	2000-01-02 01:28:10	977	Dan       	-0.702	-0.254527628
5291	2000-01-02 01:28:11	995	Ingrid    	0.422	0.421350062
5292	2000-01-02 01:28:12	963	Charlie   	-0.791	-0.815536857
5293	2000-01-02 01:28:13	958	Victor    	0.851	0.850051939
5294	2000-01-02 01:28:14	1004	Hannah    	0.431	-0.340722263
5295	2000-01-02 01:28:15	980	Victor    	0.680	-0.557976663
5296	2000-01-02 01:28:16	1006	Sarah     	0.276	-0.568295717
5297	2000-01-02 01:28:17	966	George    	-0.639	0.0914402083
5298	2000-01-02 01:28:18	971	Dan       	-0.126	0.682183206
5299	2000-01-02 01:28:19	1008	Norbert   	-0.918	-0.425244272
5300	2000-01-02 01:28:20	978	Norbert   	-0.043	-0.067545414
5301	2000-01-02 01:28:21	1053	George    	0.597	-0.895556331
5302	2000-01-02 01:28:22	982	Alice     	-0.784	0.170274839
5303	2000-01-02 01:28:23	955	Quinn     	0.973	0.0912070274
5304	2000-01-02 01:28:24	1004	Kevin     	-0.019	0.803371727
5305	2000-01-02 01:28:25	1027	Frank     	-0.994	0.670175254
5306	2000-01-02 01:28:26	1021	Edith     	0.217	0.664143384
5307	2000-01-02 01:28:27	978	Sarah     	-0.375	-0.0186705813
5308	2000-01-02 01:28:28	999	Edith     	0.145	-0.211670458
5309	2000-01-02 01:28:29	1088	Patricia  	-0.168	0.859791994
5310	2000-01-02 01:28:30	1030	Ray       	-0.435	0.941409588
5311	2000-01-02 01:28:31	973	Charlie   	0.245	-0.0164245833
5312	2000-01-02 01:28:32	995	Yvonne    	0.487	-0.208601132
5313	2000-01-02 01:28:33	1078	Michael   	-0.873	0.618806005
5314	2000-01-02 01:28:34	988	Wendy     	-0.077	-0.230836049
5315	2000-01-02 01:28:35	1016	Edith     	0.673	0.666763067
5316	2000-01-02 01:28:36	966	Yvonne    	0.613	0.355209649
5317	2000-01-02 01:28:37	985	Yvonne    	-0.385	-0.442403167
5318	2000-01-02 01:28:38	1009	Bob       	0.840	-0.0822184607
5319	2000-01-02 01:28:39	988	Quinn     	0.370	0.911940396
5320	2000-01-02 01:28:40	1059	Ursula    	-0.258	0.685010314
5321	2000-01-02 01:28:41	995	Yvonne    	-0.721	-0.44737646
5322	2000-01-02 01:28:42	1013	Norbert   	0.165	0.690889001
5323	2000-01-02 01:28:43	922	Quinn     	0.454	-0.935959101
5324	2000-01-02 01:28:44	939	Victor    	0.273	0.584224999
5325	2000-01-02 01:28:45	981	Zelda     	-0.806	-0.442878515
5326	2000-01-02 01:28:46	1003	Zelda     	-0.157	-0.466210932
5327	2000-01-02 01:28:47	978	Bob       	-0.686	0.526651144
5328	2000-01-02 01:28:48	1014	Bob       	0.201	0.0748708248
5329	2000-01-02 01:28:49	1026	Zelda     	0.333	0.341193616
5330	2000-01-02 01:28:50	1005	Ray       	0.381	-0.348433405
5331	2000-01-02 01:28:51	1003	Alice     	-0.621	-0.103604816
5332	2000-01-02 01:28:52	895	Ingrid    	0.714	-0.527650893
5333	2000-01-02 01:28:53	1042	Jerry     	0.334	-0.116800822
5334	2000-01-02 01:28:54	984	Yvonne    	-0.338	-0.14624843
5335	2000-01-02 01:28:55	1012	Wendy     	-0.723	-0.498947233
5336	2000-01-02 01:28:56	1013	Wendy     	0.303	0.828305423
5337	2000-01-02 01:28:57	956	Ray       	0.669	0.818712413
5338	2000-01-02 01:28:58	1000	Edith     	-0.075	0.313035965
5339	2000-01-02 01:28:59	1016	Jerry     	-0.443	-0.113698006
5340	2000-01-02 01:29:00	1046	Quinn     	0.839	0.544003367
5341	2000-01-02 01:29:01	978	Edith     	0.047	0.0139636388
5342	2000-01-02 01:29:02	989	Kevin     	0.874	-0.493826598
5343	2000-01-02 01:29:03	1004	Edith     	-0.256	-0.873275518
5344	2000-01-02 01:29:04	984	Michael   	-0.285	-0.320495427
5345	2000-01-02 01:29:05	996	Hannah    	-0.036	0.982410431
5346	2000-01-02 01:29:06	986	Charlie   	0.111	0.857038379
5347	2000-01-02 01:29:07	959	Yvonne    	0.954	-0.947405577
5348	2000-01-02 01:29:08	936	George    	-0.095	0.0934772417
5349	2000-01-02 01:29:09	989	Yvonne    	-0.912	0.686803341
5350	2000-01-02 01:29:10	1053	Dan       	0.376	-0.496441603
5351	2000-01-02 01:29:11	959	Michael   	0.079	0.0258537978
5352	2000-01-02 01:29:12	1017	Oliver    	0.947	-0.0389057994
5353	2000-01-02 01:29:13	1015	Ursula    	-0.272	-0.622192681
5354	2000-01-02 01:29:14	1014	Dan       	0.970	-0.441660732
5355	2000-01-02 01:29:15	1012	Wendy     	-0.251	0.236800119
5356	2000-01-02 01:29:16	1045	Ray       	-0.928	-0.414561749
5357	2000-01-02 01:29:17	1012	Quinn     	-0.576	0.0893924162
5358	2000-01-02 01:29:18	997	Patricia  	-0.888	-0.664937437
5359	2000-01-02 01:29:19	1032	George    	-0.952	-0.0634722859
5360	2000-01-02 01:29:20	1011	Patricia  	0.978	-0.871067882
5361	2000-01-02 01:29:21	954	Sarah     	0.739	0.282028437
5362	2000-01-02 01:29:22	1030	Victor    	-0.535	0.896402001
5363	2000-01-02 01:29:23	976	Patricia  	-0.086	-0.0369226001
5364	2000-01-02 01:29:24	991	Frank     	-0.141	-0.427051872
5365	2000-01-02 01:29:25	1040	Xavier    	0.513	0.632190526
5366	2000-01-02 01:29:26	984	Victor    	0.416	0.589207888
5367	2000-01-02 01:29:27	1006	Dan       	0.029	0.785742223
5368	2000-01-02 01:29:28	1044	Dan       	0.214	-0.728705943
5369	2000-01-02 01:29:29	1067	Laura     	-0.823	0.132029921
5370	2000-01-02 01:29:30	998	Quinn     	0.338	0.717974424
5371	2000-01-02 01:29:31	979	Kevin     	-0.171	-0.0656740814
5372	2000-01-02 01:29:32	1010	Kevin     	0.555	0.667268097
5373	2000-01-02 01:29:33	1032	Norbert   	0.800	-0.140795618
5374	2000-01-02 01:29:34	1001	Yvonne    	-0.054	-0.570322454
5375	2000-01-02 01:29:35	1028	Tim       	0.133	0.599451423
5376	2000-01-02 01:29:36	1012	Kevin     	-0.308	-0.397186965
5377	2000-01-02 01:29:37	987	Jerry     	0.332	-0.0516954176
5378	2000-01-02 01:29:38	1041	George    	0.958	0.907087386
5379	2000-01-02 01:29:39	1034	Ray       	0.348	0.147951677
5380	2000-01-02 01:29:40	988	Edith     	0.657	0.377623498
5381	2000-01-02 01:29:41	997	George    	-0.803	0.60948056
5382	2000-01-02 01:29:42	1071	Quinn     	0.287	-0.782850206
5383	2000-01-02 01:29:43	972	Zelda     	0.288	0.567318201
5384	2000-01-02 01:29:44	958	Ray       	0.196	0.2553747
5385	2000-01-02 01:29:45	1008	Laura     	0.686	0.0916099548
5386	2000-01-02 01:29:46	941	Dan       	-0.409	0.590135932
5387	2000-01-02 01:29:47	1039	Michael   	0.618	-0.250939101
5388	2000-01-02 01:29:48	952	Ingrid    	-0.075	0.430557221
5389	2000-01-02 01:29:49	1027	Victor    	-0.614	-0.948105872
5390	2000-01-02 01:29:50	1068	Wendy     	-0.495	0.686974883
5391	2000-01-02 01:29:51	1029	Zelda     	-0.119	0.806388378
5392	2000-01-02 01:29:52	1030	Ursula    	-0.238	-0.000692190893
5393	2000-01-02 01:29:53	990	Michael   	0.584	-0.0472755283
5394	2000-01-02 01:29:54	973	Patricia  	0.077	-0.842866302
5395	2000-01-02 01:29:55	996	Zelda     	0.541	0.174949661
5396	2000-01-02 01:29:56	972	Charlie   	0.157	-0.638197243
5397	2000-01-02 01:29:57	975	Ingrid    	0.359	0.926342189
5398	2000-01-02 01:29:58	1006	Victor    	-0.873	0.651160836
5399	2000-01-02 01:29:59	1019	Hannah    	0.818	-0.30956772
5400	2000-01-02 01:30:00	1028	Wendy     	-0.211	0.44135505
5401	2000-01-02 01:30:01	1046	Wendy     	0.397	-0.484455764
5402	2000-01-02 01:30:02	1050	Frank     	0.015	0.717749596
5403	2000-01-02 01:30:03	1025	Wendy     	0.570	0.739015996
5404	2000-01-02 01:30:04	1045	Charlie   	0.921	0.198432624
5405	2000-01-02 01:30:05	974	Xavier    	-0.961	0.113133296
5406	2000-01-02 01:30:06	1032	Laura     	0.437	0.735431969
5407	2000-01-02 01:30:07	1027	George    	-0.504	0.294021279
5408	2000-01-02 01:30:08	988	Dan       	0.286	-0.292996854
5409	2000-01-02 01:30:09	967	Hannah    	-0.632	0.740942121
5410	2000-01-02 01:30:10	982	Zelda     	0.590	-0.342353761
5411	2000-01-02 01:30:11	1024	Yvonne    	-0.716	0.449583411
5412	2000-01-02 01:30:12	965	Patricia  	0.721	0.110867888
5413	2000-01-02 01:30:13	1040	Alice     	0.667	0.00738569722
5414	2000-01-02 01:30:14	992	Oliver    	0.005	0.549331248
5415	2000-01-02 01:30:15	988	Wendy     	0.966	-0.926711202
5416	2000-01-02 01:30:16	990	Ingrid    	-0.678	-0.938889742
5417	2000-01-02 01:30:17	1041	Oliver    	0.807	-0.366665065
5418	2000-01-02 01:30:18	1021	Kevin     	-0.127	-0.129913241
5419	2000-01-02 01:30:19	1043	Bob       	-0.024	-0.275957733
5420	2000-01-02 01:30:20	968	Quinn     	-0.438	0.681038499
5421	2000-01-02 01:30:21	991	Quinn     	-0.142	-0.606772423
5422	2000-01-02 01:30:22	915	Kevin     	0.193	-0.767639518
5423	2000-01-02 01:30:23	960	Xavier    	-0.738	0.58431071
5424	2000-01-02 01:30:24	1058	Charlie   	-0.962	-0.795336664
5425	2000-01-02 01:30:25	962	Sarah     	0.891	0.256003529
5426	2000-01-02 01:30:26	936	Ray       	0.400	0.795619428
5427	2000-01-02 01:30:27	1028	Edith     	-0.240	-0.352595598
5428	2000-01-02 01:30:28	1019	Frank     	0.325	-0.200963885
5429	2000-01-02 01:30:29	992	Victor    	0.522	-0.0648154244
5430	2000-01-02 01:30:30	964	Kevin     	0.060	-0.847099304
5431	2000-01-02 01:30:31	1013	Zelda     	-0.421	-0.460089177
5432	2000-01-02 01:30:32	1026	Jerry     	0.593	-0.918982208
5433	2000-01-02 01:30:33	996	George    	-0.872	-0.48359099
5434	2000-01-02 01:30:34	995	Frank     	-0.753	-0.0648701712
5435	2000-01-02 01:30:35	1021	Hannah    	-0.617	-0.646401048
5436	2000-01-02 01:30:36	1025	Victor    	0.990	-0.132926702
5437	2000-01-02 01:30:37	1031	Bob       	-0.414	-0.1496021
5438	2000-01-02 01:30:38	994	Yvonne    	0.040	0.330776453
5439	2000-01-02 01:30:39	1027	Kevin     	-0.832	-0.217450276
5440	2000-01-02 01:30:40	960	Frank     	-0.412	0.479691684
5441	2000-01-02 01:30:41	987	Xavier    	-0.874	-0.926401734
5442	2000-01-02 01:30:42	938	Kevin     	0.993	-0.729007185
5443	2000-01-02 01:30:43	991	Hannah    	0.253	-0.849684119
5444	2000-01-02 01:30:44	998	Bob       	0.666	-0.419974476
5445	2000-01-02 01:30:45	1052	Michael   	-0.756	0.85349375
5446	2000-01-02 01:30:46	1022	Xavier    	-0.376	0.956823587
5447	2000-01-02 01:30:47	977	Quinn     	-0.249	0.778290868
5448	2000-01-02 01:30:48	998	Sarah     	0.348	0.463559777
5449	2000-01-02 01:30:49	1015	Dan       	-0.894	-0.917895436
5450	2000-01-02 01:30:50	1006	Charlie   	0.169	-0.285297215
5451	2000-01-02 01:30:51	998	George    	0.173	0.113384046
5452	2000-01-02 01:30:52	964	Kevin     	0.523	-0.82291913
5453	2000-01-02 01:30:53	1032	Yvonne    	-0.497	0.502613008
5454	2000-01-02 01:30:54	992	Hannah    	-0.354	-0.887363851
5455	2000-01-02 01:30:55	1036	Norbert   	-0.213	-0.145687371
5456	2000-01-02 01:30:56	962	Jerry     	-0.317	-0.560588956
5457	2000-01-02 01:30:57	968	Xavier    	-0.979	-0.213247642
5458	2000-01-02 01:30:58	1019	Yvonne    	-0.317	-0.76780647
5459	2000-01-02 01:30:59	1011	Patricia  	0.800	-0.159717217
5460	2000-01-02 01:31:00	1014	Ray       	-0.833	-0.100426294
5461	2000-01-02 01:31:01	1010	Quinn     	0.100	0.719729602
5462	2000-01-02 01:31:02	989	Dan       	0.371	0.0540631637
5463	2000-01-02 01:31:03	1050	Ingrid    	0.838	-0.0367981307
5464	2000-01-02 01:31:04	992	Kevin     	0.657	0.385749847
5465	2000-01-02 01:31:05	983	Dan       	0.106	0.771153331
5466	2000-01-02 01:31:06	1063	Ingrid    	-0.213	-0.241501063
5467	2000-01-02 01:31:07	1009	Michael   	0.928	0.534899294
5468	2000-01-02 01:31:08	1035	Xavier    	-0.634	0.398386329
5469	2000-01-02 01:31:09	991	Norbert   	0.419	0.603219509
5470	2000-01-02 01:31:10	957	Michael   	0.209	-0.829880416
5471	2000-01-02 01:31:11	1041	Ray       	0.560	0.639601529
5472	2000-01-02 01:31:12	1066	Kevin     	0.604	-0.921363831
5473	2000-01-02 01:31:13	987	Alice     	-0.848	-0.532623231
5474	2000-01-02 01:31:14	1010	Laura     	-0.195	-0.574117422
5475	2000-01-02 01:31:15	995	Kevin     	0.346	0.686672688
5476	2000-01-02 01:31:16	1040	Sarah     	-0.649	-0.615440607
5477	2000-01-02 01:31:17	987	Laura     	-0.399	0.182164297
5478	2000-01-02 01:31:18	965	George    	0.219	-0.625095308
5479	2000-01-02 01:31:19	1000	Hannah    	0.630	0.254226059
5480	2000-01-02 01:31:20	1031	George    	0.123	0.140351504
5481	2000-01-02 01:31:21	939	Jerry     	0.380	0.926334381
5482	2000-01-02 01:31:22	1007	Norbert   	-0.585	-0.747295082
5483	2000-01-02 01:31:23	962	Edith     	-0.206	0.81097883
5484	2000-01-02 01:31:24	1100	Alice     	-0.206	-0.232272714
5485	2000-01-02 01:31:25	1024	Frank     	0.209	0.379664779
5486	2000-01-02 01:31:26	927	Yvonne    	0.855	-0.980876982
5487	2000-01-02 01:31:27	1020	Sarah     	-0.344	-0.969350934
5488	2000-01-02 01:31:28	955	Oliver    	0.594	-0.961872458
5489	2000-01-02 01:31:29	1002	Bob       	-0.688	0.975860596
5490	2000-01-02 01:31:30	1026	George    	0.241	0.959488034
5491	2000-01-02 01:31:31	1075	George    	0.272	-0.445888132
5492	2000-01-02 01:31:32	992	Hannah    	-0.845	-0.635476649
5493	2000-01-02 01:31:33	1029	Yvonne    	0.975	0.0829724446
5494	2000-01-02 01:31:34	970	Michael   	0.670	0.117086209
5495	2000-01-02 01:31:35	987	Zelda     	-0.704	0.106616944
5496	2000-01-02 01:31:36	983	Ursula    	0.351	-0.669314384
5497	2000-01-02 01:31:37	1041	Quinn     	-0.116	-0.568641603
5498	2000-01-02 01:31:38	1009	Xavier    	-0.288	0.360143393
5499	2000-01-02 01:31:39	962	Victor    	-0.171	0.609708607
5500	2000-01-02 01:31:40	1020	George    	0.177	0.868543029
5501	2000-01-02 01:31:41	1046	Norbert   	-0.778	0.533023775
5502	2000-01-02 01:31:42	1021	George    	0.451	-0.111058846
5503	2000-01-02 01:31:43	1039	Alice     	-0.599	0.867652357
5504	2000-01-02 01:31:44	976	Tim       	-0.102	0.362198532
5505	2000-01-02 01:31:45	1034	Frank     	0.487	0.511640012
5506	2000-01-02 01:31:46	1028	Jerry     	0.700	-0.643491566
5507	2000-01-02 01:31:47	1008	Sarah     	-0.443	0.83113426
5508	2000-01-02 01:31:48	1035	Wendy     	0.683	0.951128721
5509	2000-01-02 01:31:49	975	Tim       	0.697	-0.606189668
5510	2000-01-02 01:31:50	988	Michael   	-0.763	-0.132726729
5511	2000-01-02 01:31:51	1006	Sarah     	0.949	0.390440315
5512	2000-01-02 01:31:52	1010	Laura     	0.871	-0.249677271
5513	2000-01-02 01:31:53	1010	Frank     	-0.588	-0.491265535
5514	2000-01-02 01:31:54	946	Alice     	0.299	0.653177381
5515	2000-01-02 01:31:55	1016	Sarah     	0.419	0.388608903
5516	2000-01-02 01:31:56	957	Tim       	-0.437	0.395251513
5517	2000-01-02 01:31:57	977	Oliver    	0.056	0.0121543584
5518	2000-01-02 01:31:58	1001	Sarah     	0.779	-0.748925388
5519	2000-01-02 01:31:59	937	Yvonne    	0.967	-0.566435397
5520	2000-01-02 01:32:00	994	Xavier    	-0.990	0.90917021
5521	2000-01-02 01:32:01	995	Edith     	-0.235	-0.454701841
5522	2000-01-02 01:32:02	983	Laura     	-0.665	-0.326685399
5523	2000-01-02 01:32:03	978	Tim       	0.190	0.687103152
5524	2000-01-02 01:32:04	1003	Jerry     	-0.768	-0.131429374
5525	2000-01-02 01:32:05	1048	Bob       	0.582	0.102453165
5526	2000-01-02 01:32:06	1013	Kevin     	-0.922	0.570715547
5527	2000-01-02 01:32:07	1005	Hannah    	0.435	0.194477946
5528	2000-01-02 01:32:08	988	Charlie   	0.967	0.833049178
5529	2000-01-02 01:32:09	995	Frank     	-0.390	-0.482809871
5530	2000-01-02 01:32:10	986	Sarah     	0.975	-0.824884892
5531	2000-01-02 01:32:11	979	Xavier    	-0.023	-0.273792207
5532	2000-01-02 01:32:12	931	Kevin     	0.549	0.810841858
5533	2000-01-02 01:32:13	1020	Oliver    	0.376	0.118393831
5534	2000-01-02 01:32:14	974	Alice     	-0.580	-0.884135306
5535	2000-01-02 01:32:15	1016	Charlie   	-0.394	-0.58819145
5536	2000-01-02 01:32:16	969	Frank     	-0.928	0.0730050653
5537	2000-01-02 01:32:17	1022	Zelda     	0.605	0.681407392
5538	2000-01-02 01:32:18	989	Victor    	-0.630	-0.574574232
5539	2000-01-02 01:32:19	960	Alice     	0.867	0.573423386
5540	2000-01-02 01:32:20	1012	Ray       	0.609	-0.586828649
5541	2000-01-02 01:32:21	964	Ursula    	0.540	0.227983668
5542	2000-01-02 01:32:22	1030	Edith     	0.105	0.74611032
5543	2000-01-02 01:32:23	996	Bob       	-0.362	-0.479683816
5544	2000-01-02 01:32:24	982	Norbert   	0.682	-0.142683074
5545	2000-01-02 01:32:25	1004	Laura     	0.122	0.619255066
5546	2000-01-02 01:32:26	1029	Laura     	-0.213	-0.468041509
5547	2000-01-02 01:32:27	1008	Ursula    	0.377	-0.684978962
5548	2000-01-02 01:32:28	969	Hannah    	0.750	0.75120157
5549	2000-01-02 01:32:29	1015	Charlie   	-0.327	0.320080191
5550	2000-01-02 01:32:30	986	Victor    	0.334	-0.5997684
5551	2000-01-02 01:32:31	1014	Frank     	0.273	-0.963645518
5552	2000-01-02 01:32:32	1042	Laura     	0.088	0.843081355
5553	2000-01-02 01:32:33	970	Quinn     	-0.857	-0.997784615
5554	2000-01-02 01:32:34	980	Tim       	0.942	0.0182037447
5555	2000-01-02 01:32:35	1010	Tim       	-0.626	-0.0791848972
5556	2000-01-02 01:32:36	1018	Yvonne    	-0.448	0.658215642
5557	2000-01-02 01:32:37	1020	Ingrid    	-0.611	-0.642730176
5558	2000-01-02 01:32:38	976	Edith     	-0.520	-0.374916047
5559	2000-01-02 01:32:39	975	Yvonne    	-0.240	0.724842191
5560	2000-01-02 01:32:40	1033	Ingrid    	0.525	-0.214492694
5561	2000-01-02 01:32:41	1055	Patricia  	0.958	-0.392947376
5562	2000-01-02 01:32:42	984	Charlie   	-0.455	-0.22653462
5563	2000-01-02 01:32:43	1017	Alice     	0.550	0.0392390899
5564	2000-01-02 01:32:44	984	George    	-0.988	-0.905928195
5565	2000-01-02 01:32:45	1054	Wendy     	-0.189	0.254169792
5566	2000-01-02 01:32:46	1003	Alice     	-0.058	-0.0101306271
5567	2000-01-02 01:32:47	932	Kevin     	-0.390	0.0258276369
5568	2000-01-02 01:32:48	1069	Tim       	0.933	-0.486649513
5569	2000-01-02 01:32:49	1022	Hannah    	-0.425	0.541667581
5570	2000-01-02 01:32:50	1014	Oliver    	1.000	0.0934775621
5571	2000-01-02 01:32:51	994	Yvonne    	-0.396	-0.24825643
5572	2000-01-02 01:32:52	969	Patricia  	0.622	-0.917453051
5573	2000-01-02 01:32:53	1014	Quinn     	0.739	0.768495142
5574	2000-01-02 01:32:54	1029	Oliver    	0.522	-0.371586114
5575	2000-01-02 01:32:55	1035	Quinn     	0.528	0.513922215
5576	2000-01-02 01:32:56	1024	Michael   	-0.640	-0.366556495
5577	2000-01-02 01:32:57	984	Edith     	0.755	-0.348198563
5578	2000-01-02 01:32:58	996	Yvonne    	0.739	0.20195964
5579	2000-01-02 01:32:59	968	Jerry     	-0.864	-0.600536883
5580	2000-01-02 01:33:00	989	Patricia  	0.785	0.556246936
5581	2000-01-02 01:33:01	1007	Frank     	0.451	0.8397035
5582	2000-01-02 01:33:02	963	Frank     	0.764	0.9040398
5583	2000-01-02 01:33:03	1006	Michael   	-0.809	0.0469050556
5584	2000-01-02 01:33:04	962	Wendy     	0.155	0.678964257
5585	2000-01-02 01:33:05	1024	Michael   	-0.978	0.442922771
5586	2000-01-02 01:33:06	1017	Wendy     	-0.499	-0.950093567
5587	2000-01-02 01:33:07	974	Laura     	0.260	-0.981688142
5588	2000-01-02 01:33:08	1073	Zelda     	0.688	-0.204997331
5589	2000-01-02 01:33:09	1002	Sarah     	0.923	0.301413774
5590	2000-01-02 01:33:10	1044	Norbert   	0.901	-0.591662943
5591	2000-01-02 01:33:11	1014	Quinn     	0.877	-0.834383905
5592	2000-01-02 01:33:12	1010	George    	-0.385	-0.59383148
5593	2000-01-02 01:33:13	921	Frank     	-0.387	-0.0221515521
5594	2000-01-02 01:33:14	994	Zelda     	-0.166	-0.201796681
5595	2000-01-02 01:33:15	982	Bob       	0.444	-0.464249104
5596	2000-01-02 01:33:16	980	Norbert   	0.293	-0.541443586
5597	2000-01-02 01:33:17	978	George    	0.650	0.53825587
5598	2000-01-02 01:33:18	1002	Sarah     	-0.095	0.509820282
5599	2000-01-02 01:33:19	967	Norbert   	0.738	0.84503001
5600	2000-01-02 01:33:20	955	Victor    	-0.996	0.806651056
5601	2000-01-02 01:33:21	952	Frank     	0.039	0.278510153
5602	2000-01-02 01:33:22	1003	Patricia  	-0.386	-0.211313307
5603	2000-01-02 01:33:23	982	Alice     	0.212	0.0861179531
5604	2000-01-02 01:33:24	995	Ray       	0.098	-0.534434736
5605	2000-01-02 01:33:25	949	Kevin     	-0.618	0.306452185
5606	2000-01-02 01:33:26	941	Hannah    	0.405	-0.83243221
5607	2000-01-02 01:33:27	1032	Sarah     	-0.106	-0.192151174
5608	2000-01-02 01:33:28	956	Bob       	0.564	-0.802083731
5609	2000-01-02 01:33:29	1001	Ursula    	-0.170	0.588141501
5610	2000-01-02 01:33:30	1078	Charlie   	-0.235	-0.636697948
5611	2000-01-02 01:33:31	957	Sarah     	0.136	-0.498871803
5612	2000-01-02 01:33:32	1021	George    	0.222	0.386677772
5613	2000-01-02 01:33:33	1023	Hannah    	0.641	-0.265463293
5614	2000-01-02 01:33:34	1000	Kevin     	0.884	0.16225192
5615	2000-01-02 01:33:35	965	Dan       	0.123	0.100248478
5616	2000-01-02 01:33:36	987	Xavier    	-0.088	-0.696487546
5617	2000-01-02 01:33:37	1029	Xavier    	-0.336	0.2066558
5618	2000-01-02 01:33:38	1040	Kevin     	0.229	-0.0530885793
5619	2000-01-02 01:33:39	990	Sarah     	-0.258	-0.858377695
5620	2000-01-02 01:33:40	986	Bob       	0.939	0.0380469598
5621	2000-01-02 01:33:41	1048	Tim       	-0.315	0.928352177
5622	2000-01-02 01:33:42	1039	Wendy     	0.478	-0.684940696
5623	2000-01-02 01:33:43	1013	Zelda     	0.003	0.920807719
5624	2000-01-02 01:33:44	1021	Oliver    	0.671	-0.633879006
5625	2000-01-02 01:33:45	1037	Ursula    	0.557	0.604333639
5626	2000-01-02 01:33:46	980	Norbert   	0.759	0.214281142
5627	2000-01-02 01:33:47	1040	George    	0.091	0.0360360146
5628	2000-01-02 01:33:48	996	Norbert   	-0.429	0.546501875
5629	2000-01-02 01:33:49	1023	Patricia  	0.275	-0.655437529
5630	2000-01-02 01:33:50	976	George    	0.542	0.161885738
5631	2000-01-02 01:33:51	980	Frank     	0.188	-0.575524747
5632	2000-01-02 01:33:52	958	Zelda     	-0.853	0.883489072
5633	2000-01-02 01:33:53	953	Wendy     	-0.303	0.13662906
5634	2000-01-02 01:33:54	987	Dan       	0.519	0.0194279719
5635	2000-01-02 01:33:55	995	Oliver    	-0.241	0.117862828
5636	2000-01-02 01:33:56	1020	Frank     	-0.091	-0.519404709
5637	2000-01-02 01:33:57	1027	Laura     	0.246	0.179829508
5638	2000-01-02 01:33:58	981	Tim       	-0.337	-0.595840216
5639	2000-01-02 01:33:59	1068	Quinn     	-0.517	-0.367538065
5640	2000-01-02 01:34:00	1011	Oliver    	0.792	0.554705083
5641	2000-01-02 01:34:01	1006	Bob       	0.614	0.71953702
5642	2000-01-02 01:34:02	1034	Tim       	0.181	0.31611383
5643	2000-01-02 01:34:03	997	Wendy     	-0.420	-0.673607588
5644	2000-01-02 01:34:04	1044	Kevin     	0.271	0.727250755
5645	2000-01-02 01:34:05	942	Wendy     	-0.430	0.437617093
5646	2000-01-02 01:34:06	983	Quinn     	0.396	0.702309251
5647	2000-01-02 01:34:07	947	Michael   	0.047	0.0976566076
5648	2000-01-02 01:34:08	977	Yvonne    	-0.154	0.0336745642
5649	2000-01-02 01:34:09	973	Victor    	0.666	0.379675955
5650	2000-01-02 01:34:10	970	Wendy     	0.511	0.72111243
5651	2000-01-02 01:34:11	1060	Wendy     	0.612	0.735507607
5652	2000-01-02 01:34:12	927	Bob       	0.595	0.057211712
5653	2000-01-02 01:34:13	965	Zelda     	0.244	0.35519433
5654	2000-01-02 01:34:14	1000	Oliver    	-0.068	0.989742637
5655	2000-01-02 01:34:15	1047	Ingrid    	-0.320	-0.324321717
5656	2000-01-02 01:34:16	1016	Wendy     	0.541	0.944863617
5657	2000-01-02 01:34:17	994	Oliver    	0.583	0.668477297
5658	2000-01-02 01:34:18	983	Xavier    	-0.290	-0.58946681
5659	2000-01-02 01:34:19	959	Charlie   	0.758	0.27657038
5660	2000-01-02 01:34:20	1001	Frank     	-0.149	0.507829905
5661	2000-01-02 01:34:21	1014	Yvonne    	-0.179	0.00160850689
5662	2000-01-02 01:34:22	999	George    	0.375	0.272437572
5663	2000-01-02 01:34:23	988	Patricia  	0.642	-0.868275702
5664	2000-01-02 01:34:24	1027	Tim       	0.241	0.456484288
5665	2000-01-02 01:34:25	1046	Bob       	0.540	0.646235228
5666	2000-01-02 01:34:26	1053	Ingrid    	0.509	-0.845487177
5667	2000-01-02 01:34:27	969	Bob       	-0.978	0.707705259
5668	2000-01-02 01:34:28	967	Patricia  	0.316	-0.391780913
5669	2000-01-02 01:34:29	944	Ursula    	0.791	0.0624926724
5670	2000-01-02 01:34:30	992	Zelda     	0.952	0.347360373
5671	2000-01-02 01:34:31	1066	Yvonne    	0.439	0.714692235
5672	2000-01-02 01:34:32	1016	Jerry     	0.057	-0.834062636
5673	2000-01-02 01:34:33	955	Hannah    	-0.497	0.652959287
5674	2000-01-02 01:34:34	1004	Tim       	0.170	-0.767298937
5675	2000-01-02 01:34:35	1060	Hannah    	0.550	-0.171030194
5676	2000-01-02 01:34:36	1041	Charlie   	-0.587	0.206868693
5677	2000-01-02 01:34:37	1017	Ray       	0.311	0.256217927
5678	2000-01-02 01:34:38	1036	Yvonne    	0.409	0.535841107
\.


--
-- Data for Name: missing; Type: TABLE DATA; Schema: public; Owner: cleaning
--

COPY public.missing (a, b) FROM stdin;
NaN	Not number
1.23000002	A number  
\N	A null    
3.45000005	Santiago  
6.78000021	          
9.01000023	\N
\.


--
-- Data for Name: test; Type: TABLE DATA; Schema: public; Owner: cleaning
--

COPY public.test (c1, c2) FROM stdin;
123	123
\.


--
-- Name: ix_dask_sample_index; Type: INDEX; Schema: public; Owner: cleaning
--

CREATE INDEX ix_dask_sample_index ON public.dask_sample USING btree (index);


--
-- PostgreSQL database dump complete
--

